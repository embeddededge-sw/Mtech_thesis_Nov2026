vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xilinx_vip
vlib modelsim_lib/msim/xpm
vlib modelsim_lib/msim/axi_infrastructure_v1_1_0
vlib modelsim_lib/msim/axi_vip_v1_1_17
vlib modelsim_lib/msim/zynq_ultra_ps_e_vip_v1_0_17
vlib modelsim_lib/msim/xil_defaultlib
vlib modelsim_lib/msim/blk_mem_gen_v8_4_8
vlib modelsim_lib/msim/axi_bram_ctrl_v4_1_10
vlib modelsim_lib/msim/generic_baseblocks_v2_1_2
vlib modelsim_lib/msim/axi_register_slice_v2_1_31
vlib modelsim_lib/msim/fifo_generator_v13_2_10
vlib modelsim_lib/msim/axi_data_fifo_v2_1_30
vlib modelsim_lib/msim/axi_crossbar_v2_1_32
vlib modelsim_lib/msim/lib_cdc_v1_0_3
vlib modelsim_lib/msim/proc_sys_reset_v5_0_15
vlib modelsim_lib/msim/axi_protocol_converter_v2_1_31
vlib modelsim_lib/msim/axi_clock_converter_v2_1_30
vlib modelsim_lib/msim/axi_dwidth_converter_v2_1_31

vmap xilinx_vip modelsim_lib/msim/xilinx_vip
vmap xpm modelsim_lib/msim/xpm
vmap axi_infrastructure_v1_1_0 modelsim_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_17 modelsim_lib/msim/axi_vip_v1_1_17
vmap zynq_ultra_ps_e_vip_v1_0_17 modelsim_lib/msim/zynq_ultra_ps_e_vip_v1_0_17
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib
vmap blk_mem_gen_v8_4_8 modelsim_lib/msim/blk_mem_gen_v8_4_8
vmap axi_bram_ctrl_v4_1_10 modelsim_lib/msim/axi_bram_ctrl_v4_1_10
vmap generic_baseblocks_v2_1_2 modelsim_lib/msim/generic_baseblocks_v2_1_2
vmap axi_register_slice_v2_1_31 modelsim_lib/msim/axi_register_slice_v2_1_31
vmap fifo_generator_v13_2_10 modelsim_lib/msim/fifo_generator_v13_2_10
vmap axi_data_fifo_v2_1_30 modelsim_lib/msim/axi_data_fifo_v2_1_30
vmap axi_crossbar_v2_1_32 modelsim_lib/msim/axi_crossbar_v2_1_32
vmap lib_cdc_v1_0_3 modelsim_lib/msim/lib_cdc_v1_0_3
vmap proc_sys_reset_v5_0_15 modelsim_lib/msim/proc_sys_reset_v5_0_15
vmap axi_protocol_converter_v2_1_31 modelsim_lib/msim/axi_protocol_converter_v2_1_31
vmap axi_clock_converter_v2_1_30 modelsim_lib/msim/axi_clock_converter_v2_1_30
vmap axi_dwidth_converter_v2_1_31 modelsim_lib/msim/axi_dwidth_converter_v2_1_31

vlog -work xilinx_vip -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -64 -93  \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_17 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/4d04/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work zynq_ultra_ps_e_vip_v1_0_17 -64 -incr -mfcu  -sv -L axi_vip_v1_1_17 -L zynq_ultra_ps_e_vip_v1_0_17 -L xilinx_vip "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl/zynq_ultra_ps_e_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/design_1/ip/design_1_zynq_ultra_ps_e_0_0/sim/design_1_zynq_ultra_ps_e_0_0_vip_wrapper.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_am_addmul_5ns_13ns_15ns_29_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_detect.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_3_channel_pad_1_loop_for_channel_pad_1_loop_for_weight_pad.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_3_channel_pad_2_loop_for_channel_pad_2_loop_for_weight_pad.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_ap2D_0.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_ap2D_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_b_Dense_0.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_channel_pad_0_loop_for_weight_pad_0.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_loop_for_fc_2_loop_for_fb_2_loop_for_fa_2.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_7_1_VITIS_LOOP_9_2_VITIS_LOOP_10_3.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_25_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_29_2.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_30_1_VITIS_LOOP_32_2_VITIS_LOOP_33_3.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_34_3.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_53_1_VITIS_LOOP_55_2_VITIS_LOOP_56_3.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_74_1_VITIS_LOOP_75_2_VITIS_LOOP_76_3.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_control_r_s_axi.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_control_s_axi.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_conv2d_1_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_conv2d_2_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_conv2d_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_exp_33_17_s.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_exp_33_17_s_exp_x_msb_1_table_ROM_AUTO_1R.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_exp_33_17_s_f_x_msb_2_table_ROM_AUTO_1R.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_exp_33_17_s_f_x_msb_3_table_ROM_AUTO_1R.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_flow_control_loop_pipe_sequential_init.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_gmem0_m_axi.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_gmem1_m_axi.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_6ns_5ns_6ns_10_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_6ns_5ns_7ns_10_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_7ns_5ns_3ns_11_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_7ns_5ns_4ns_11_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_7ns_5ns_7ns_11_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_8ns_3ns_8ns_11_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mac_muladd_8ns_3ns_9ns_11_4_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_max_pooling2d_1_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_max_pooling2d_2_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_max_pooling2d_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_3ns_11ns_13_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_5ns_7ns_10_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_10ns_12ns_21_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_13ns_15ns_27_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_32s_32s_48_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_50ns_47ns_97_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_mul_50ns_50ns_100_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_out_Dense_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_OutPadConv0_RAM_1WNR_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_OutPadConv1_RAM_1WNR_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_OutPadConv2_RAM_AUTO_1R1W.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_sdiv_49ns_32s_32_53_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_sparsemux_11_3_32_1_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_sparsemux_11_3_32_1_1_x.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_urem_10ns_4ns_3_14_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_urem_10ns_4ns_3_14_seq_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN_urem_13ns_4ns_3_17_1.v" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9fb8/hdl/verilog/CNN.v" \
"../../../bd/design_1/ip/design_1_CNN_0_0/sim/design_1_CNN_0_0.v" \

vlog -work blk_mem_gen_v8_4_8 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/09bd/simulation/blk_mem_gen_v8_4.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/design_1/ip/design_1_blk_mem_gen_0_0/sim/design_1_blk_mem_gen_0_0.v" \
"../../../bd/design_1/ip/design_1_blk_mem_gen_0_1/sim/design_1_blk_mem_gen_0_1.v" \

vcom -work axi_bram_ctrl_v4_1_10 -64 -93  \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/14fa/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/design_1/ip/design_1_axi_bram_ctrl_0_0/sim/design_1_axi_bram_ctrl_0_0.vhd" \
"../../../bd/design_1/ip/design_1_axi_bram_ctrl_1_0/sim/design_1_axi_bram_ctrl_1_0.vhd" \

vlog -work generic_baseblocks_v2_1_2 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/0c28/hdl/generic_baseblocks_v2_1_vl_rfs.v" \

vlog -work axi_register_slice_v2_1_31 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/92b2/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work fifo_generator_v13_2_10 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/1443/simulation/fifo_generator_vlog_beh.v" \

vcom -work fifo_generator_v13_2_10 -64 -93  \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/1443/hdl/fifo_generator_v13_2_rfs.vhd" \

vlog -work fifo_generator_v13_2_10 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/1443/hdl/fifo_generator_v13_2_rfs.v" \

vlog -work axi_data_fifo_v2_1_30 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/9692/hdl/axi_data_fifo_v2_1_vl_rfs.v" \

vlog -work axi_crossbar_v2_1_32 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/e9d8/hdl/axi_crossbar_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/design_1/ip/design_1_xbar_0/sim/design_1_xbar_0.v" \

vcom -work lib_cdc_v1_0_3 -64 -93  \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/2a4f/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_15 -64 -93  \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/3a26/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/design_1/ip/design_1_rst_ps8_0_99M_0/sim/design_1_rst_ps8_0_99M_0.vhd" \

vlog -work axi_protocol_converter_v2_1_31 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/3c06/hdl/axi_protocol_converter_v2_1_vl_rfs.v" \

vlog -work axi_clock_converter_v2_1_30 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/80bf/hdl/axi_clock_converter_v2_1_vl_rfs.v" \

vlog -work axi_dwidth_converter_v2_1_31 -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/14b9/hdl/axi_dwidth_converter_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../VGG_Cnn.gen/sources_1/bd/design_1/ip/design_1_CNN_0_0/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" \
"../../../bd/design_1/ip/design_1_auto_us_0/sim/design_1_auto_us_0.v" \
"../../../bd/design_1/ip/design_1_auto_us_1/sim/design_1_auto_us_1.v" \
"../../../bd/design_1/ip/design_1_auto_ds_0/sim/design_1_auto_ds_0.v" \
"../../../bd/design_1/ip/design_1_auto_pc_0/sim/design_1_auto_pc_0.v" \
"../../../bd/design_1/ip/design_1_auto_ds_1/sim/design_1_auto_ds_1.v" \
"../../../bd/design_1/ip/design_1_auto_pc_1/sim/design_1_auto_pc_1.v" \
"../../../bd/design_1/ip/design_1_auto_ds_2/sim/design_1_auto_ds_2.v" \
"../../../bd/design_1/ip/design_1_auto_ds_3/sim/design_1_auto_ds_3.v" \
"../../../bd/design_1/sim/design_1.v" \

vlog -work xil_defaultlib \
"glbl.v"

