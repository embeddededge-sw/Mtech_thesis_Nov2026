`timescale 1ns / 1ps

/*------------------------------------------------------------------------
 *  Module: cnn_mnist_mm
 *  Description: AXI4 memory-mapped wrapper for RTL CNN MNIST accelerator.
 *
 *  IMPORTANT: axis_cnn_mnist uses a rising-edge detector on s_axis_tvalid
 *  to start a free-running counter. After the first rising edge, the core
 *  reads s_axis_tdata every cycle for 784 cycles with NO gaps allowed.
 *  Therefore we use a two-phase approach:
 *    Phase 1 (FETCH): Read 784 pixels from BRAM via AXI master, buffer locally
 *    Phase 2 (FEED):  Stream 784 pixels to core in consecutive cycles
 *
 *  Interface (matches HLS LeNet IP):
 *    s_axi_control   : AP_CTRL (0x00), OUTMODEL0 (0x10)
 *    s_axi_control_r : inmodel pointer (0x10/0x14)
 *    m_axi_gmem1     : AXI4 master to read image from BRAM
 *------------------------------------------------------------------------*/

module cnn_mnist_mm (
    input  wire        ap_clk,
    input  wire        ap_rst_n,

    // s_axi_control: control registers
    input  wire [4:0]  s_axi_control_AWADDR,
    input  wire        s_axi_control_AWVALID,
    output wire        s_axi_control_AWREADY,
    input  wire [31:0] s_axi_control_WDATA,
    input  wire [3:0]  s_axi_control_WSTRB,
    input  wire        s_axi_control_WVALID,
    output wire        s_axi_control_WREADY,
    output wire [1:0]  s_axi_control_BRESP,
    output wire        s_axi_control_BVALID,
    input  wire        s_axi_control_BREADY,
    input  wire [4:0]  s_axi_control_ARADDR,
    input  wire        s_axi_control_ARVALID,
    output wire        s_axi_control_ARREADY,
    output wire [31:0] s_axi_control_RDATA,
    output wire [1:0]  s_axi_control_RRESP,
    output wire        s_axi_control_RVALID,
    input  wire        s_axi_control_RREADY,
    output wire        interrupt,

    // s_axi_control_r: pointer registers
    input  wire [5:0]  s_axi_control_r_AWADDR,
    input  wire        s_axi_control_r_AWVALID,
    output wire        s_axi_control_r_AWREADY,
    input  wire [31:0] s_axi_control_r_WDATA,
    input  wire [3:0]  s_axi_control_r_WSTRB,
    input  wire        s_axi_control_r_WVALID,
    output wire        s_axi_control_r_WREADY,
    output wire [1:0]  s_axi_control_r_BRESP,
    output wire        s_axi_control_r_BVALID,
    input  wire        s_axi_control_r_BREADY,
    input  wire [5:0]  s_axi_control_r_ARADDR,
    input  wire        s_axi_control_r_ARVALID,
    output wire        s_axi_control_r_ARREADY,
    output wire [31:0] s_axi_control_r_RDATA,
    output wire [1:0]  s_axi_control_r_RRESP,
    output wire        s_axi_control_r_RVALID,
    input  wire        s_axi_control_r_RREADY,

    // m_axi_gmem1: AXI4 master (read-only, write channels tied off)
    output wire [63:0] m_axi_gmem1_AWADDR,
    output wire [0:0]  m_axi_gmem1_AWID,
    output wire [7:0]  m_axi_gmem1_AWLEN,
    output wire [2:0]  m_axi_gmem1_AWSIZE,
    output wire [1:0]  m_axi_gmem1_AWBURST,
    output wire [1:0]  m_axi_gmem1_AWLOCK,
    output wire [3:0]  m_axi_gmem1_AWCACHE,
    output wire [2:0]  m_axi_gmem1_AWPROT,
    output wire [3:0]  m_axi_gmem1_AWQOS,
    output wire [3:0]  m_axi_gmem1_AWREGION,
    output wire [0:0]  m_axi_gmem1_AWUSER,
    output wire        m_axi_gmem1_AWVALID,
    input  wire        m_axi_gmem1_AWREADY,
    output wire [31:0] m_axi_gmem1_WDATA,
    output wire [3:0]  m_axi_gmem1_WSTRB,
    output wire        m_axi_gmem1_WLAST,
    output wire [0:0]  m_axi_gmem1_WID,
    output wire [0:0]  m_axi_gmem1_WUSER,
    output wire        m_axi_gmem1_WVALID,
    input  wire        m_axi_gmem1_WREADY,
    input  wire [0:0]  m_axi_gmem1_BID,
    input  wire [1:0]  m_axi_gmem1_BRESP,
    input  wire [0:0]  m_axi_gmem1_BUSER,
    input  wire        m_axi_gmem1_BVALID,
    output wire        m_axi_gmem1_BREADY,
    output wire [63:0] m_axi_gmem1_ARADDR,
    output wire [0:0]  m_axi_gmem1_ARID,
    output wire [7:0]  m_axi_gmem1_ARLEN,
    output wire [2:0]  m_axi_gmem1_ARSIZE,
    output wire [1:0]  m_axi_gmem1_ARBURST,
    output wire [1:0]  m_axi_gmem1_ARLOCK,
    output wire [3:0]  m_axi_gmem1_ARCACHE,
    output wire [2:0]  m_axi_gmem1_ARPROT,
    output wire [3:0]  m_axi_gmem1_ARQOS,
    output wire [3:0]  m_axi_gmem1_ARREGION,
    output wire [0:0]  m_axi_gmem1_ARUSER,
    output wire        m_axi_gmem1_ARVALID,
    input  wire        m_axi_gmem1_ARREADY,
    input  wire [31:0] m_axi_gmem1_RDATA,
    input  wire [0:0]  m_axi_gmem1_RID,
    input  wire [1:0]  m_axi_gmem1_RRESP,
    input  wire        m_axi_gmem1_RLAST,
    input  wire [0:0]  m_axi_gmem1_RUSER,
    input  wire        m_axi_gmem1_RVALID,
    output wire        m_axi_gmem1_RREADY
);

    // ---------------------------------------------------------------
    // Tie off AXI write channel (read-only master)
    // ---------------------------------------------------------------
    assign m_axi_gmem1_AWADDR   = 64'd0;
    assign m_axi_gmem1_AWID     = 1'd0;
    assign m_axi_gmem1_AWLEN    = 8'd0;
    assign m_axi_gmem1_AWSIZE   = 3'd0;
    assign m_axi_gmem1_AWBURST  = 2'd0;
    assign m_axi_gmem1_AWLOCK   = 2'd0;
    assign m_axi_gmem1_AWCACHE  = 4'd0;
    assign m_axi_gmem1_AWPROT   = 3'd0;
    assign m_axi_gmem1_AWQOS    = 4'd0;
    assign m_axi_gmem1_AWREGION = 4'd0;
    assign m_axi_gmem1_AWUSER   = 1'd0;
    assign m_axi_gmem1_AWVALID  = 1'b0;
    assign m_axi_gmem1_WDATA    = 32'd0;
    assign m_axi_gmem1_WSTRB    = 4'd0;
    assign m_axi_gmem1_WLAST    = 1'b0;
    assign m_axi_gmem1_WID      = 1'd0;
    assign m_axi_gmem1_WUSER    = 1'd0;
    assign m_axi_gmem1_WVALID   = 1'b0;
    assign m_axi_gmem1_BREADY   = 1'b0;

    // ---------------------------------------------------------------
    // AXI read channel constants
    // ---------------------------------------------------------------
    assign m_axi_gmem1_ARID     = 1'd0;
    assign m_axi_gmem1_ARSIZE   = 3'd2;    // 4 bytes per beat
    assign m_axi_gmem1_ARBURST  = 2'd1;    // INCR
    assign m_axi_gmem1_ARLOCK   = 2'd0;
    assign m_axi_gmem1_ARCACHE  = 4'd3;    // bufferable
    assign m_axi_gmem1_ARPROT   = 3'd0;
    assign m_axi_gmem1_ARQOS    = 4'd0;
    assign m_axi_gmem1_ARREGION = 4'd0;
    assign m_axi_gmem1_ARUSER   = 1'd0;

    // ---------------------------------------------------------------
    // Control registers
    // ---------------------------------------------------------------
    reg [31:0] reg_in_low, reg_in_high, reg_out;
    reg        ap_start, ap_done;
    wire [31:0] reg_ctrl = {29'd0, ~ap_start, ap_done, ap_start};
    assign interrupt = ap_done;

    // ---------------------------------------------------------------
    // Local pixel buffer: 784 pixels, 1 pixel per 32-bit word
    // (matches LeNet software: Xil_Out32(addr+i, pixel) writes
    //  one pixel in the low byte of each 32-bit word)
    // ---------------------------------------------------------------
    reg [7:0]  pixel_buf [0:783];
    reg [9:0]  wr_pixel_addr;  // write address (0..783)

    // Read port for streaming phase
    reg [9:0]  rd_pixel_addr;  // read address (0..783)


    // ---------------------------------------------------------------
    // CNN core signals
    // ---------------------------------------------------------------
    reg  [7:0]  core_tdata;
    reg         core_tvalid;
    wire        core_tready;
    wire [7:0]  core_m_tdata;
    wire        core_m_tvalid;
    wire        core_m_tlast;
    reg         core_rst_n;

    axis_cnn_mnist core (
        .aclk(ap_clk),
        .aresetn(core_rst_n),
        .s_axis_tready(core_tready),
        .s_axis_tdata(core_tdata),
        .s_axis_tvalid(core_tvalid),
        .m_axis_tready(1'b1),
        .m_axis_tdata(core_m_tdata),
        .m_axis_tvalid(core_m_tvalid),
        .m_axis_tlast(core_m_tlast)
    );

    // ---------------------------------------------------------------
    // s_axi_control write channel
    // ---------------------------------------------------------------
    reg        aw_done_ctrl, w_done_ctrl;
    reg [4:0]  awaddr_ctrl;

    assign s_axi_control_AWREADY = !aw_done_ctrl;
    assign s_axi_control_WREADY  = !w_done_ctrl;
    assign s_axi_control_BVALID  = aw_done_ctrl && w_done_ctrl;
    assign s_axi_control_BRESP   = 2'b00;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            aw_done_ctrl <= 0;
            w_done_ctrl  <= 0;
            awaddr_ctrl  <= 0;
        end else begin
            if (s_axi_control_AWVALID && s_axi_control_AWREADY) begin
                aw_done_ctrl <= 1;
                awaddr_ctrl  <= s_axi_control_AWADDR;
            end
            if (s_axi_control_WVALID && s_axi_control_WREADY)
                w_done_ctrl <= 1;
            if (s_axi_control_BVALID && s_axi_control_BREADY) begin
                aw_done_ctrl <= 0;
                w_done_ctrl  <= 0;
            end
        end
    end

    // ---------------------------------------------------------------
    // s_axi_control read channel
    // ---------------------------------------------------------------
    reg        ar_pending_ctrl;
    reg [4:0]  araddr_ctrl;
    reg [31:0] rdata_ctrl;
    reg        rvalid_ctrl;

    assign s_axi_control_ARREADY = !ar_pending_ctrl && !rvalid_ctrl;
    assign s_axi_control_RDATA   = rdata_ctrl;
    assign s_axi_control_RRESP   = 2'b00;
    assign s_axi_control_RVALID  = rvalid_ctrl;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            ar_pending_ctrl <= 0;
            rvalid_ctrl     <= 0;
            rdata_ctrl      <= 0;
            araddr_ctrl     <= 0;
        end else begin
            if (s_axi_control_ARVALID && s_axi_control_ARREADY) begin
                ar_pending_ctrl <= 1;
                araddr_ctrl     <= s_axi_control_ARADDR;
            end
            if (ar_pending_ctrl) begin
                ar_pending_ctrl <= 0;
                rvalid_ctrl     <= 1;
                case (araddr_ctrl)
                    5'h00:   rdata_ctrl <= reg_ctrl;
                    5'h10:   rdata_ctrl <= reg_out;
                    default: rdata_ctrl <= 32'd0;
                endcase
            end
            if (rvalid_ctrl && s_axi_control_RREADY)
                rvalid_ctrl <= 0;
        end
    end

    // ---------------------------------------------------------------
    // s_axi_control_r write channel
    // ---------------------------------------------------------------
    reg        aw_done_ctrl_r, w_done_ctrl_r;
    reg [5:0]  awaddr_ctrl_r;

    assign s_axi_control_r_AWREADY = !aw_done_ctrl_r;
    assign s_axi_control_r_WREADY  = !w_done_ctrl_r;
    assign s_axi_control_r_BVALID  = aw_done_ctrl_r && w_done_ctrl_r;
    assign s_axi_control_r_BRESP   = 2'b00;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            aw_done_ctrl_r <= 0;
            w_done_ctrl_r  <= 0;
            awaddr_ctrl_r  <= 0;
        end else begin
            if (s_axi_control_r_AWVALID && s_axi_control_r_AWREADY) begin
                aw_done_ctrl_r <= 1;
                awaddr_ctrl_r  <= s_axi_control_r_AWADDR;
            end
            if (s_axi_control_r_WVALID && s_axi_control_r_WREADY)
                w_done_ctrl_r <= 1;
            if (s_axi_control_r_BVALID && s_axi_control_r_BREADY) begin
                aw_done_ctrl_r <= 0;
                w_done_ctrl_r  <= 0;
            end
        end
    end

    // ---------------------------------------------------------------
    // s_axi_control_r read channel
    // ---------------------------------------------------------------
    reg        ar_pending_ctrl_r;
    reg [5:0]  araddr_ctrl_r;
    reg [31:0] rdata_ctrl_r;
    reg        rvalid_ctrl_r;

    assign s_axi_control_r_ARREADY = !ar_pending_ctrl_r && !rvalid_ctrl_r;
    assign s_axi_control_r_RDATA   = rdata_ctrl_r;
    assign s_axi_control_r_RRESP   = 2'b00;
    assign s_axi_control_r_RVALID  = rvalid_ctrl_r;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            ar_pending_ctrl_r <= 0;
            rvalid_ctrl_r     <= 0;
            rdata_ctrl_r      <= 0;
            araddr_ctrl_r     <= 0;
        end else begin
            if (s_axi_control_r_ARVALID && s_axi_control_r_ARREADY) begin
                ar_pending_ctrl_r <= 1;
                araddr_ctrl_r     <= s_axi_control_r_ARADDR;
            end
            if (ar_pending_ctrl_r) begin
                ar_pending_ctrl_r <= 0;
                rvalid_ctrl_r     <= 1;
                case (araddr_ctrl_r)
                    6'h10:   rdata_ctrl_r <= reg_in_low;
                    6'h14:   rdata_ctrl_r <= reg_in_high;
                    default: rdata_ctrl_r <= 32'd0;
                endcase
            end
            if (rvalid_ctrl_r && s_axi_control_r_RREADY)
                rvalid_ctrl_r <= 0;
        end
    end

    // ---------------------------------------------------------------
    // Main FSM
    // ---------------------------------------------------------------
    // Phase 1 (FETCH): 784 words (1 pixel per word) = 49 bursts of 16
    // Phase 2 (FEED):  Stream 784 pixels in 784 consecutive cycles

    localparam S_IDLE    = 3'd0,
               S_RESET   = 3'd1,
               S_AR      = 3'd2,  // issue AXI read address
               S_R       = 3'd3,  // receive AXI data into pixel_buf
               S_FEED    = 3'd4,  // stream pixels to core (no gaps)
               S_WAIT    = 3'd5,  // wait for CNN result
               S_DONE    = 3'd6;

    reg [2:0]  state;
    reg [5:0]  burst_num;       // 0..48
    reg [4:0]  beat_cnt;        // 0..15 within burst
    reg [9:0]  pixel_cnt;       // total pixels streamed (0..783)
    reg [3:0]  reset_cnt;
    reg [10:0] wait_cnt;

    // 784 words = 49 bursts of 16 beats each
    // (49 * 16 = 784 words exactly)
    wire [4:0] cur_burst_last = 5'd15;

    // AXI AR channel: each burst reads 16 words = 64 bytes
    assign m_axi_gmem1_ARADDR  = {reg_in_high, reg_in_low} + {burst_num, 6'd0};
    assign m_axi_gmem1_ARLEN   = 8'd15;
    assign m_axi_gmem1_ARVALID = (state == S_AR);
    assign m_axi_gmem1_RREADY  = (state == S_R);

    // ---------------------------------------------------------------
    // ap_start / pointer register handling
    // ---------------------------------------------------------------
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            ap_start    <= 0;
            reg_in_low  <= 0;
            reg_in_high <= 0;
        end else begin
            if (s_axi_control_WVALID && s_axi_control_WREADY && awaddr_ctrl == 5'h00) begin
                if (s_axi_control_WDATA[0] && state == S_IDLE)
                    ap_start <= 1;
            end
            if (state == S_DONE && ap_done)
                ap_start <= 0;

            if (s_axi_control_r_WVALID && s_axi_control_r_WREADY) begin
                if (awaddr_ctrl_r == 6'h10) reg_in_low  <= s_axi_control_r_WDATA;
                if (awaddr_ctrl_r == 6'h14) reg_in_high <= s_axi_control_r_WDATA;
            end
        end
    end

    // ---------------------------------------------------------------
    // Output capture
    // ---------------------------------------------------------------
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            reg_out <= 0;
            ap_done <= 0;
        end else begin
            if (state == S_RESET)
                ap_done <= 0;
            if (core_m_tvalid && !ap_done) begin
                reg_out <= {12'd0, core_m_tdata[3:0], 16'd0};
                ap_done <= 1;
            end
        end
    end

    // ---------------------------------------------------------------
    // Pixel buffer read (for FEED phase)
    // Combinational read - no latency
    // ---------------------------------------------------------------
    wire [7:0] rd_pixel = pixel_buf[rd_pixel_addr];

    // ---------------------------------------------------------------
    // Main state machine
    // ---------------------------------------------------------------
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            state        <= S_IDLE;
            core_rst_n   <= 0;
            core_tvalid  <= 0;
            core_tdata   <= 0;
            burst_num     <= 0;
            beat_cnt      <= 0;
            rd_pixel_addr <= 0;
            pixel_cnt     <= 0;
            reset_cnt     <= 0;
            wait_cnt      <= 0;
            wr_pixel_addr <= 0;
        end else begin
            case (state)
                // ---- Wait for ap_start ----
                S_IDLE: begin
                    core_tvalid <= 0;
                    if (ap_start) begin
                        state      <= S_RESET;
                        core_rst_n <= 0;
                        reset_cnt  <= 0;
                    end
                end

                // ---- Hold core in reset ----
                S_RESET: begin
                    reset_cnt <= reset_cnt + 1;
                    if (reset_cnt == 4'd7) begin
                        core_rst_n    <= 1;
                        state         <= S_AR;
                        burst_num     <= 0;
                        beat_cnt      <= 0;
                        wr_pixel_addr <= 0;
                    end
                end

                // ---- Phase 1: Issue AXI read address ----
                S_AR: begin
                    if (m_axi_gmem1_ARREADY) begin
                        state    <= S_R;
                        beat_cnt <= 0;
                    end
                end

                // ---- Phase 1: Receive AXI data into pixel_buf ----
                // Each 32-bit AXI word has 1 pixel in low byte
                S_R: begin
                    if (m_axi_gmem1_RVALID) begin
                        pixel_buf[wr_pixel_addr] <= m_axi_gmem1_RDATA[7:0];
                        wr_pixel_addr <= wr_pixel_addr + 1;

                        if (beat_cnt == cur_burst_last) begin
                            if (burst_num == 6'd48) begin
                                // All 784 pixels fetched, start streaming
                                state         <= S_FEED;
                                rd_pixel_addr <= 0;
                                pixel_cnt     <= 0;
                            end else begin
                                burst_num <= burst_num + 1;
                                state     <= S_AR;
                            end
                        end else begin
                            beat_cnt <= beat_cnt + 1;
                        end
                    end
                end

                // ---- Phase 2: Stream 784 pixels with NO gaps ----
                // Combinational read: rd_pixel available same cycle
                // pixel_cnt 0..783 = output 784 pixels
                S_FEED: begin
                    if (pixel_cnt < 10'd784) begin
                        core_tvalid   <= 1;
                        core_tdata    <= rd_pixel;
                        pixel_cnt     <= pixel_cnt + 1;
                        rd_pixel_addr <= rd_pixel_addr + 1;
                    end else begin
                        core_tvalid <= 0;
                        state       <= S_WAIT;
                        wait_cnt    <= 0;
                    end
                end

                // ---- Wait for CNN pipeline result ----
                S_WAIT: begin
                    core_tvalid <= 0;
                    wait_cnt    <= wait_cnt + 1;
                    if (ap_done || wait_cnt >= 11'd1500)
                        state <= S_DONE;
                end

                // ---- Done ----
                S_DONE: begin
                    core_tvalid <= 0;
                    if (!ap_start) begin
                        state      <= S_IDLE;
                        core_rst_n <= 0;
                    end
                end
            endcase
        end
    end

endmodule
