`timescale 1ns / 1ps

module cnn_mnist_mm (
    input  wire        ap_clk,
    input  wire        ap_rst_n,

    // AXI4-Lite Control (Matches LeNet)
    input  wire [4:0]  s_axi_control_AWADDR,
    input  wire        s_axi_control_AWVALID,
    output wire        s_axi_control_AWREADY,
    input  wire [31:0] s_axi_control_WDATA,
    input  wire [3:0]  s_axi_control_WSTRB,
    input  wire        s_axi_control_WVALID,
    output wire        s_axi_control_WREADY,
    output wire [1:0]  s_axi_control_BRESP,
    output wire        s_axi_control_BVALID,
    input  wire        s_axi_control_BREADY,
    input  wire [4:0]  s_axi_control_ARADDR,
    input  wire        s_axi_control_ARVALID,
    output wire        s_axi_control_ARREADY,
    output wire [31:0] s_axi_control_RDATA,
    output wire [1:0]  s_axi_control_RRESP,
    output wire        s_axi_control_RVALID,
    input  wire        s_axi_control_RREADY,
    output wire        interrupt,

    // AXI4-Lite Control_R (For InModel Address)
    input  wire [5:0]  s_axi_control_r_AWADDR,
    input  wire        s_axi_control_r_AWVALID,
    output wire        s_axi_control_r_AWREADY,
    input  wire [31:0] s_axi_control_r_WDATA,
    input  wire [3:0]  s_axi_control_r_WSTRB,
    input  wire        s_axi_control_r_WVALID,
    output wire        s_axi_control_r_WREADY,
    output wire [1:0]  s_axi_control_r_BRESP,
    output wire        s_axi_control_r_BVALID,
    input  wire        s_axi_control_r_BREADY,
    input  wire [5:0]  s_axi_control_r_ARADDR,
    input  wire        s_axi_control_r_ARVALID,
    output wire        s_axi_control_r_ARREADY,
    output wire [31:0] s_axi_control_r_RDATA,
    output wire [1:0]  s_axi_control_r_RRESP,
    output wire        s_axi_control_r_RVALID,
    input  wire        s_axi_control_r_RREADY,

    // AXI4 Master gmem1 (Read Image)
    output wire [63:0] m_axi_gmem1_AWADDR,
    output wire [0:0]  m_axi_gmem1_AWID,
    output wire [7:0]  m_axi_gmem1_AWLEN,
    output wire [2:0]  m_axi_gmem1_AWSIZE,
    output wire [1:0]  m_axi_gmem1_AWBURST,
    output wire [1:0]  m_axi_gmem1_AWLOCK,
    output wire [3:0]  m_axi_gmem1_AWCACHE,
    output wire [2:0]  m_axi_gmem1_AWPROT,
    output wire [3:0]  m_axi_gmem1_AWQOS,
    output wire [3:0]  m_axi_gmem1_AWREGION,
    output wire [0:0]  m_axi_gmem1_AWUSER,
    output wire        m_axi_gmem1_AWVALID,
    input  wire        m_axi_gmem1_AWREADY,
    output wire [31:0] m_axi_gmem1_WDATA,
    output wire [3:0]  m_axi_gmem1_WSTRB,
    output wire        m_axi_gmem1_WLAST,
    output wire [0:0]  m_axi_gmem1_WID,
    output wire [0:0]  m_axi_gmem1_WUSER,
    output wire        m_axi_gmem1_WVALID,
    input  wire        m_axi_gmem1_WREADY,
    input  wire [0:0]  m_axi_gmem1_BID,
    input  wire [1:0]  m_axi_gmem1_BRESP,
    input  wire [0:0]  m_axi_gmem1_BUSER,
    input  wire        m_axi_gmem1_BVALID,
    output wire        m_axi_gmem1_BREADY,
    output wire [63:0] m_axi_gmem1_ARADDR,
    output wire [0:0]  m_axi_gmem1_ARID,
    output wire [7:0]  m_axi_gmem1_ARLEN,
    output wire [2:0]  m_axi_gmem1_ARSIZE,
    output wire [1:0]  m_axi_gmem1_ARBURST,
    output wire [1:0]  m_axi_gmem1_ARLOCK,
    output wire [3:0]  m_axi_gmem1_ARCACHE,
    output wire [2:0]  m_axi_gmem1_ARPROT,
    output wire [3:0]  m_axi_gmem1_ARQOS,
    output wire [3:0]  m_axi_gmem1_ARREGION,
    output wire [0:0]  m_axi_gmem1_ARUSER,
    output wire        m_axi_gmem1_ARVALID,
    input  wire        m_axi_gmem1_ARREADY,
    input  wire [31:0] m_axi_gmem1_RDATA,
    input  wire [0:0]  m_axi_gmem1_RID,
    input  wire [1:0]  m_axi_gmem1_RRESP,
    input  wire        m_axi_gmem1_RLAST,
    input  wire [0:0]  m_axi_gmem1_RUSER,
    input  wire        m_axi_gmem1_RVALID,
    output wire        m_axi_gmem1_RREADY
);

    // Tie off unused Write ports
    assign m_axi_gmem1_AWADDR = 64'd0; assign m_axi_gmem1_AWID = 1'd0; assign m_axi_gmem1_AWLEN = 8'd0;
    assign m_axi_gmem1_AWSIZE = 3'd0; assign m_axi_gmem1_AWBURST = 2'd0; assign m_axi_gmem1_AWLOCK = 2'd0;
    assign m_axi_gmem1_AWCACHE = 4'd0; assign m_axi_gmem1_AWPROT = 3'd0; assign m_axi_gmem1_AWQOS = 4'd0;
    assign m_axi_gmem1_AWREGION = 4'd0; assign m_axi_gmem1_AWUSER = 1'd0; assign m_axi_gmem1_AWVALID = 1'b0;
    assign m_axi_gmem1_WDATA = 32'd0; assign m_axi_gmem1_WSTRB = 4'd0; assign m_axi_gmem1_WLAST = 1'b0;
    assign m_axi_gmem1_WID = 1'd0; assign m_axi_gmem1_WUSER = 1'd0; assign m_axi_gmem1_WVALID = 1'b0;
    assign m_axi_gmem1_BREADY = 1'b0;

    reg [31:0] reg_ctrl;     // 0x00
    reg [31:0] reg_in_low;   // 0x10
    reg [31:0] reg_in_high;  // 0x14
    reg [31:0] reg_out;      // 0x10 (s_axi_control)
    
    reg  [7:0]  core_s_axis_tdata;
    reg         core_s_axis_tvalid;
    wire        core_s_axis_tready;
    wire [7:0]  core_m_axis_tdata;
    wire        core_m_axis_tvalid;
    wire        core_m_axis_tlast;

    axis_cnn_mnist core (
        .aclk(ap_clk),
        .aresetn(ap_rst_n),
        .s_axis_tready(core_s_axis_tready),
        .s_axis_tdata(core_s_axis_tdata),
        .s_axis_tvalid(core_s_axis_tvalid),
        .m_axis_tready(1'b1),
        .m_axis_tdata(core_m_axis_tdata),
        .m_axis_tvalid(core_m_axis_tvalid),
        .m_axis_tlast(core_m_axis_tlast)
    );

    localparam IDLE = 2'd0, AR = 2'd1, R = 2'd2, DONE = 2'd3;
    reg [1:0] state;
    reg [8:0] word_count;
    reg [1:0] byte_count;
    reg [31:0] rdata_buf;

    assign m_axi_gmem1_ARADDR = {reg_in_high, reg_in_low};
    assign m_axi_gmem1_ARLEN = 8'd195;
    assign m_axi_gmem1_ARSIZE = 3'd2;
    assign m_axi_gmem1_ARBURST = 2'd1;
    assign m_axi_gmem1_ARID = 1'd0; assign m_axi_gmem1_ARLOCK = 2'd0; assign m_axi_gmem1_ARCACHE = 4'd0;
    assign m_axi_gmem1_ARPROT = 3'd0; assign m_axi_gmem1_ARQOS = 4'd0; assign m_axi_gmem1_ARREGION = 4'd0;
    assign m_axi_gmem1_ARUSER = 1'd0;

    reg arvalid_reg, rready_reg;
    assign m_axi_gmem1_ARVALID = arvalid_reg;
    assign m_axi_gmem1_RREADY = rready_reg;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            state <= IDLE; arvalid_reg <= 0; rready_reg <= 0;
            core_s_axis_tvalid <= 0; core_s_axis_tdata <= 0;
            word_count <= 0; byte_count <= 0; reg_ctrl <= 0;
        end else begin
            case (state)
                IDLE: begin
                    if (reg_ctrl[0]) begin
                        state <= AR; arvalid_reg <= 1; word_count <= 0; byte_count <= 0;
                    end
                end
                AR: begin
                    if (m_axi_gmem1_ARREADY) begin
                        arvalid_reg <= 0; rready_reg <= 1; state <= R;
                    end
                end
                R: begin
                    if (m_axi_gmem1_RVALID && core_s_axis_tready) begin
                        core_s_axis_tdata <= m_axi_gmem1_RDATA[8*byte_count +: 8];
                        core_s_axis_tvalid <= 1;
                        if (byte_count == 3) begin
                            byte_count <= 0;
                            word_count <= word_count + 1;
                            if (word_count == 195) begin
                                state <= DONE;
                            end
                        end else begin
                            byte_count <= byte_count + 1;
                        end
                    end
                end
                DONE: begin
                    core_s_axis_tvalid <= 0; rready_reg <= 0;
                    if (core_m_axis_tvalid) begin
                        reg_out <= {28'd0, core_m_axis_tdata[3:0]};
                        reg_ctrl[1] <= 1;
                        reg_ctrl[0] <= 0;
                        state <= IDLE;
                    end
                end
            endcase
        end
    end

    assign s_axi_control_AWREADY = 1; assign s_axi_control_WREADY = 1;
    assign s_axi_control_BRESP = 0; assign s_axi_control_BVALID = s_axi_control_AWVALID & s_axi_control_WVALID;
    assign s_axi_control_ARREADY = 1; assign s_axi_control_RRESP = 0; assign s_axi_control_RVALID = s_axi_control_ARVALID;
    assign s_axi_control_RDATA = (s_axi_control_ARADDR == 5'h00) ? reg_ctrl : (s_axi_control_ARADDR == 5'h10) ? reg_out : 32'd0;
    assign interrupt = reg_ctrl[1];

    always @(posedge ap_clk) begin
        if (s_axi_control_AWVALID && s_axi_control_WVALID && s_axi_control_AWADDR == 5'h00)
            reg_ctrl[0] <= s_axi_control_WDATA[0];
    end

    assign s_axi_control_r_AWREADY = 1; assign s_axi_control_r_WREADY = 1;
    assign s_axi_control_r_BRESP = 0; assign s_axi_control_r_BVALID = s_axi_control_r_AWVALID & s_axi_control_r_WVALID;
    assign s_axi_control_r_ARREADY = 1; assign s_axi_control_r_RRESP = 0; assign s_axi_control_r_RVALID = s_axi_control_r_ARVALID;
    assign s_axi_control_r_RDATA = (s_axi_control_r_ARADDR == 6'h10) ? reg_in_low : (s_axi_control_r_ARADDR == 6'h14) ? reg_in_high : 32'd0;

    always @(posedge ap_clk) begin
        if (s_axi_control_r_AWVALID && s_axi_control_r_WVALID) begin
            if (s_axi_control_r_AWADDR == 6'h10) reg_in_low <= s_axi_control_r_WDATA;
            if (s_axi_control_r_AWADDR == 6'h14) reg_in_high <= s_axi_control_r_WDATA;
        end
    end
endmodule