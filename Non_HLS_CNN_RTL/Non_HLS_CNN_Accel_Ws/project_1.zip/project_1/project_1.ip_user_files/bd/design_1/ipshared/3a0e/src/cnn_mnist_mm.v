`timescale 1ns / 1ps

module cnn_mnist_mm (
    input  wire        ap_clk,
    input  wire        ap_rst_n,

    input  wire [4:0]  s_axi_control_AWADDR,
    input  wire        s_axi_control_AWVALID,
    output wire        s_axi_control_AWREADY,
    input  wire [31:0] s_axi_control_WDATA,
    input  wire [3:0]  s_axi_control_WSTRB,
    input  wire        s_axi_control_WVALID,
    output wire        s_axi_control_WREADY,
    output wire [1:0]  s_axi_control_BRESP,
    output wire        s_axi_control_BVALID,
    input  wire        s_axi_control_BREADY,
    input  wire [4:0]  s_axi_control_ARADDR,
    input  wire        s_axi_control_ARVALID,
    output wire        s_axi_control_ARREADY,
    output wire [31:0] s_axi_control_RDATA,
    output wire [1:0]  s_axi_control_RRESP,
    output wire        s_axi_control_RVALID,
    input  wire        s_axi_control_RREADY,
    output wire        interrupt,

    input  wire [5:0]  s_axi_control_r_AWADDR,
    input  wire        s_axi_control_r_AWVALID,
    output wire        s_axi_control_r_AWREADY,
    input  wire [31:0] s_axi_control_r_WDATA,
    input  wire [3:0]  s_axi_control_r_WSTRB,
    input  wire        s_axi_control_r_WVALID,
    output wire        s_axi_control_r_WREADY,
    output wire [1:0]  s_axi_control_r_BRESP,
    output wire        s_axi_control_r_BVALID,
    input  wire        s_axi_control_r_BREADY,
    input  wire [5:0]  s_axi_control_r_ARADDR,
    input  wire        s_axi_control_r_ARVALID,
    output wire        s_axi_control_r_ARREADY,
    output wire [31:0] s_axi_control_r_RDATA,
    output wire [1:0]  s_axi_control_r_RRESP,
    output wire        s_axi_control_r_RVALID,
    input  wire        s_axi_control_r_RREADY,

    output wire [63:0] m_axi_gmem1_AWADDR, output wire [0:0] m_axi_gmem1_AWID, output wire [7:0] m_axi_gmem1_AWLEN,
    output wire [2:0] m_axi_gmem1_AWSIZE, output wire [1:0] m_axi_gmem1_AWBURST, output wire [1:0] m_axi_gmem1_AWLOCK,
    output wire [3:0] m_axi_gmem1_AWCACHE, output wire [2:0] m_axi_gmem1_AWPROT, output wire [3:0] m_axi_gmem1_AWQOS,
    output wire [3:0] m_axi_gmem1_AWREGION, output wire [0:0] m_axi_gmem1_AWUSER, output wire m_axi_gmem1_AWVALID,
    input  wire m_axi_gmem1_AWREADY, output wire [31:0] m_axi_gmem1_WDATA, output wire [3:0] m_axi_gmem1_WSTRB,
    output wire m_axi_gmem1_WLAST, output wire [0:0] m_axi_gmem1_WID, output wire [0:0] m_axi_gmem1_WUSER,
    output wire m_axi_gmem1_WVALID, input  wire m_axi_gmem1_WREADY, input  wire [0:0] m_axi_gmem1_BID,
    input  wire [1:0] m_axi_gmem1_BRESP, input  wire [0:0] m_axi_gmem1_BUSER, input  wire m_axi_gmem1_BVALID,
    output wire m_axi_gmem1_BREADY, output wire [63:0] m_axi_gmem1_ARADDR, output wire [0:0] m_axi_gmem1_ARID,
    output wire [7:0] m_axi_gmem1_ARLEN, output wire [2:0] m_axi_gmem1_ARSIZE, output wire [1:0] m_axi_gmem1_ARBURST,
    output wire [1:0] m_axi_gmem1_ARLOCK, output wire [3:0] m_axi_gmem1_ARCACHE, output wire [2:0] m_axi_gmem1_ARPROT,
    output wire [3:0] m_axi_gmem1_ARQOS, output wire [3:0] m_axi_gmem1_ARREGION, output wire [0:0] m_axi_gmem1_ARUSER,
    output wire m_axi_gmem1_ARVALID, input  wire m_axi_gmem1_ARREADY, input  wire [31:0] m_axi_gmem1_RDATA,
    input  wire [0:0] m_axi_gmem1_RID, input  wire [1:0] m_axi_gmem1_RRESP, input  wire m_axi_gmem1_RLAST,
    input  wire [0:0] m_axi_gmem1_RUSER, input  wire m_axi_gmem1_RVALID, output wire m_axi_gmem1_RREADY
);

    assign m_axi_gmem1_AWADDR = 64'd0; assign m_axi_gmem1_AWID = 1'd0; assign m_axi_gmem1_AWLEN = 8'd0;
    assign m_axi_gmem1_AWSIZE = 3'd0; assign m_axi_gmem1_AWBURST = 2'd0; assign m_axi_gmem1_AWLOCK = 2'd0;
    assign m_axi_gmem1_AWCACHE = 4'd0; assign m_axi_gmem1_AWPROT = 3'd0; assign m_axi_gmem1_AWQOS = 4'd0;
    assign m_axi_gmem1_AWREGION = 4'd0; assign m_axi_gmem1_AWUSER = 1'd0; assign m_axi_gmem1_AWVALID = 1'b0;
    assign m_axi_gmem1_WDATA = 32'd0; assign m_axi_gmem1_WSTRB = 4'd0; assign m_axi_gmem1_WLAST = 1'b0;
    assign m_axi_gmem1_WID = 1'd0; assign m_axi_gmem1_WUSER = 1'd0; assign m_axi_gmem1_WVALID = 1'b0;
    assign m_axi_gmem1_BREADY = 1'b0;

    reg [31:0] reg_in_low;
    reg [31:0] reg_in_high;
    reg [31:0] reg_out;
    reg [31:0] reg_debug;

    reg ap_start;
    reg ap_done;
    assign interrupt = ap_done;
    wire [31:0] reg_ctrl = {30'd0, ap_done, ap_start};

    reg  [7:0]  core_s_axis_tdata;
    reg         core_s_axis_tvalid;
    wire        core_s_axis_tready;
    wire [7:0]  core_m_axis_tdata;
    wire        core_m_axis_tvalid;
    wire        core_m_axis_tlast;

    reg [3:0] rst_cnt;
    reg core_rst_n;

    axis_cnn_mnist core (
        .aclk(ap_clk),
        .aresetn(core_rst_n),
        .s_axis_tready(core_s_axis_tready),
        .s_axis_tdata(core_s_axis_tdata),
        .s_axis_tvalid(core_s_axis_tvalid),
        .m_axis_tready(1'b1),
        .m_axis_tdata(core_m_axis_tdata),
        .m_axis_tvalid(core_m_axis_tvalid),
        .m_axis_tlast(core_m_axis_tlast)
    );

    reg [7:0] burst_cnt;
    reg [4:0] beat_cnt;
    reg [1:0] byte_cnt;

    reg [31:0] rdata_buf;
    reg        rdata_valid;
    reg        cnn_fed;

    assign m_axi_gmem1_ARADDR = {reg_in_high, reg_in_low} + (burst_cnt * 64);
    assign m_axi_gmem1_ARLEN = 8'd15;
    assign m_axi_gmem1_ARSIZE = 3'd2;
    assign m_axi_gmem1_ARBURST = 2'd1;
    assign m_axi_gmem1_ARID = 1'd0; assign m_axi_gmem1_ARLOCK = 2'd0; assign m_axi_gmem1_ARCACHE = 4'd0;
    assign m_axi_gmem1_ARPROT = 3'd0; assign m_axi_gmem1_ARQOS = 4'd0; assign m_axi_gmem1_ARREGION = 4'd0;
    assign m_axi_gmem1_ARUSER = 1'd0;

    reg aw_done_ctrl, w_done_ctrl;
    reg [4:0] awaddr_ctrl;
    assign s_axi_control_AWREADY = !aw_done_ctrl;
    assign s_axi_control_WREADY  = !w_done_ctrl;
    assign s_axi_control_BVALID  = aw_done_ctrl && w_done_ctrl;
    assign s_axi_control_BRESP   = 2'b00;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            aw_done_ctrl <= 1'b0; w_done_ctrl <= 1'b0;
        end else begin
            if (s_axi_control_AWVALID && s_axi_control_AWREADY) begin aw_done_ctrl <= 1'b1; awaddr_ctrl <= s_axi_control_AWADDR; end
            if (s_axi_control_WVALID && s_axi_control_WREADY) w_done_ctrl <= 1'b1;
            if (s_axi_control_BVALID && s_axi_control_BREADY) begin aw_done_ctrl <= 1'b0; w_done_ctrl <= 1'b0; end
        end
    end

    reg aw_done_ctrl_r, w_done_ctrl_r;
    reg [5:0] awaddr_ctrl_r;
    assign s_axi_control_r_AWREADY = !aw_done_ctrl_r;
    assign s_axi_control_r_WREADY  = !w_done_ctrl_r;
    assign s_axi_control_r_BVALID  = aw_done_ctrl_r && w_done_ctrl_r;
    assign s_axi_control_r_BRESP   = 2'b00;

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            aw_done_ctrl_r <= 1'b0; w_done_ctrl_r <= 1'b0;
        end else begin
            if (s_axi_control_r_AWVALID && s_axi_control_r_AWREADY) begin aw_done_ctrl_r <= 1'b1; awaddr_ctrl_r <= s_axi_control_r_AWADDR; end
            if (s_axi_control_r_WVALID && s_axi_control_r_WREADY) w_done_ctrl_r <= 1'b1;
            if (s_axi_control_r_BVALID && s_axi_control_r_BREADY) begin aw_done_ctrl_r <= 1'b0; w_done_ctrl_r <= 1'b0; end
        end
    end

    assign s_axi_control_ARREADY = 1'b1;
    assign s_axi_control_RRESP = 2'b00;
    assign s_axi_control_RVALID = s_axi_control_ARVALID;
    assign s_axi_control_RDATA = (s_axi_control_ARADDR == 5'h00) ? reg_ctrl :
                                 (s_axi_control_ARADDR == 5'h10) ? reg_out :
                                 (s_axi_control_ARADDR == 5'h14) ? reg_debug : 32'd0;

    assign s_axi_control_r_ARREADY = 1'b1;
    assign s_axi_control_r_RRESP = 2'b00;
    assign s_axi_control_r_RVALID = s_axi_control_r_ARVALID;
    assign s_axi_control_r_RDATA = (s_axi_control_r_ARADDR == 6'h10) ? reg_in_low :
                                   (s_axi_control_r_ARADDR == 6'h14) ? reg_in_high : 32'd0;

    localparam IDLE = 3'd0, AR = 3'd1, R = 3'd2, FLUSH = 3'd3, DONE = 3'd4;
    reg [2:0] state;
    reg [9:0] flush_cnt;

    assign m_axi_gmem1_ARVALID = (state == AR);
    assign m_axi_gmem1_RREADY  = (state == R) && (!rdata_valid);

    // FIXED: capture core_m_axis_tvalid in ALL states, not only DONE.
    // The comparator emits a 1-cycle pulse; if it arrives during FLUSH or R,
    // the old code lost it and ap_done never asserted.
    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            reg_out  <= 32'd0;
            ap_done  <= 1'b0;
        end else begin
            if (state == IDLE && ap_start)
                ap_done <= 1'b0;

            if (core_m_axis_tvalid) begin
                reg_out <= {28'd0, core_m_axis_tdata[3:0]};
                ap_done <= 1'b1;
            end
        end
    end

    always @(posedge ap_clk) begin
        if (!ap_rst_n) begin
            state <= IDLE; core_s_axis_tvalid <= 1'b0; core_s_axis_tdata <= 8'd0;
            burst_cnt <= 8'd0; beat_cnt <= 5'd0; byte_cnt <= 2'd0;
            ap_start <= 1'b0;
            reg_in_low <= 32'd0; reg_in_high <= 32'd0;
            rst_cnt <= 4'd0; core_rst_n <= 1'b0; flush_cnt <= 10'd0;
            reg_debug <= 32'd0;
            rdata_buf <= 32'd0;
            rdata_valid <= 1'b0;
            cnn_fed <= 1'b0;
        end else begin
            reg_debug <= {3'd0, flush_cnt, rdata_valid, burst_cnt, beat_cnt, byte_cnt, state};

            if (s_axi_control_WVALID && s_axi_control_WREADY && awaddr_ctrl == 5'h00) begin
                if (state == IDLE) ap_start <= s_axi_control_WDATA[0];
            end
            if (s_axi_control_r_WVALID && s_axi_control_r_WREADY) begin
                if (awaddr_ctrl_r == 6'h10) reg_in_low  <= s_axi_control_r_WDATA;
                if (awaddr_ctrl_r == 6'h14) reg_in_high <= s_axi_control_r_WDATA;
            end

            if (state == IDLE && ap_start) begin rst_cnt <= 4'd4; core_rst_n <= 1'b0; end
            else if (rst_cnt > 0) begin rst_cnt <= rst_cnt - 1; core_rst_n <= 1'b0; end
            else core_rst_n <= 1'b1;

            case (state)
                IDLE: begin
                    if (ap_start) begin
                        state <= AR;
                        burst_cnt <= 8'd0; beat_cnt <= 5'd0; byte_cnt <= 2'd0;
                        rdata_valid <= 1'b0;
                        cnn_fed <= 1'b0;
                    end
                end
                AR: begin
                    if (m_axi_gmem1_ARREADY) begin
                        state <= R;
                        beat_cnt <= 5'd0;
                        byte_cnt <= 2'd0;
                        rdata_valid <= 1'b0;
                    end
                end
                R: begin
                    if (!rdata_valid) begin
                        core_s_axis_tvalid <= 1'b0;
                        if (m_axi_gmem1_RVALID) begin
                            rdata_buf <= m_axi_gmem1_RDATA;
                            rdata_valid <= 1'b1;
                            byte_cnt <= 2'd0;
                        end
                    end else begin
                        if (!cnn_fed) begin
                            core_s_axis_tvalid <= 1'b1;
                            core_s_axis_tdata <= rdata_buf[8*byte_cnt +: 8];
                        end else begin
                            core_s_axis_tvalid <= 1'b0;
                        end

                        if (byte_cnt == 2'd3) begin
                            byte_cnt <= 2'd0;
                            rdata_valid <= 1'b0;

                            if (burst_cnt == 8'd12 && beat_cnt == 5'd3) begin
                                cnn_fed <= 1'b1;
                            end

                            if (burst_cnt == 8'd12) begin
                                if (beat_cnt == 5'd15) begin
                                    state <= FLUSH;
                                    flush_cnt <= 10'd0;
                                end else begin
                                    beat_cnt <= beat_cnt + 1'b1;
                                end
                            end else begin
                                if (beat_cnt == 5'd15) begin
                                    beat_cnt <= 5'd0;
                                    state <= AR;
                                    burst_cnt <= burst_cnt + 1'b1;
                                end else begin
                                    beat_cnt <= beat_cnt + 1'b1;
                                end
                            end
                        end else begin
                            byte_cnt <= byte_cnt + 1'b1;
                        end
                    end
                end
                FLUSH: begin
                    core_s_axis_tvalid <= 1'b1;
                    core_s_axis_tdata <= 8'd0;
                    if (flush_cnt == 10'd511) begin
                        state <= DONE;
                        core_s_axis_tvalid <= 1'b0;
                    end else begin
                        flush_cnt <= flush_cnt + 1'b1;
                    end
                end
                DONE: begin
                    core_s_axis_tvalid <= 1'b0;
                    if (ap_done) begin
                        ap_start <= 1'b0;
                        state <= IDLE;
                    end
                end
            endcase
        end
    end
endmodule