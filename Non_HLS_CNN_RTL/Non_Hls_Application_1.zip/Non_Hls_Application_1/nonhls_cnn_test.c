#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdint.h>

#include "cnn_accel_uapi.h"
#include "test_images.h"

#define DEV_PATH "/dev/cnn0"

int main(void)
{
    int fd, correct = 0, i;

    fd = open(DEV_PATH, O_RDWR);
    if (fd < 0) {
        perror("open " DEV_PATH);
        return 1;
    }

    printf("\n==================================================\n");
    printf("  Udemy RTL CNN Inference (No Weights)\n");
    printf("==================================================\n\n");

    printf("Running inference on %d test images...\n\n", 100); // Test 100 to save time

    int max_pixel = 0;

    for (i = 0; i < 100; i++) {
        struct cnn_inference_req req;
        req.input_size = CNN_INPUT_SIZE;

	// Extract raw 8-bit pixel from LeNet format 0x0000XXYY
	for (int j = 0; j < CNN_INPUT_SIZE; j++) {
	    req.image[j] = test_images_fixed[i][j] & 0xff; 

	    if (req.image[j] > max_pixel) max_pixel = req.image[j];
        }

	// Print the max pixel to verify (should be > 0 for real digits)
	if (i == 0) {
		printf("Image 0 -> Center Pixel: %d, Max Pixel: %d\n", req.image[400], max_pixel);
	}

        // Call the NEW Udemy IOCTL
        if (ioctl(fd, CNN_IOCTL_RUN_NONHLS, &req) < 0) {
            perror("ioctl RUN_UDEMY");
            close(fd);
            return 1;
       }

        int predicted = req.result;
        int expected = test_labels[i];

        printf("Image %d: ", i);
        if (predicted == expected) {
            printf("PASS - Predicted: %d, Expected: %d\n", predicted, expected);
            correct++;
        } else {
            printf("FAIL - Predicted: %d, Expected: %d\n", predicted, expected);
        }
    }

    printf("\n==================================================\n");
    printf("  RESULTS (First 100 images)\n");
    printf("==================================================\n");
    printf("Correct:      %d\n", correct);
    printf("Accuracy:     %.1f%%\n", (float)correct / 100.0f * 100.0f);
    printf("==================================================\n\n");

    close(fd);
    return 0;
}
