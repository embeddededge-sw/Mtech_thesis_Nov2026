// SPDX-License-Identifier: GPL-2.0
/*
 * cnn_common_test.c - Unified userspace test for CNN accelerator
 *
 * Supports both HLS and Non-HLS CNN models via command-line option.
 *
 * Build:
 *   gcc -o cnn_common_test cnn_common_test.c test_images.c weights_array.c -I. -lm
 *
 * Run:
 *   sudo ./cnn_common_test --mode hls                  # HLS, all 10000 images
 *   sudo ./cnn_common_test --mode nonhls               # Non-HLS, all 10000 images
 *   sudo ./cnn_common_test --mode hls --images 100     # HLS, first 100 images
 *   sudo ./cnn_common_test --mode nonhls --images 500  # Non-HLS, first 500 images
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdint.h>

#include "cnn_accel_uapi.h"
#include "weights_array.h"
#include "test_images.h"

#define DEV_PATH "/dev/cnn0"

enum cnn_mode {
    MODE_HLS,
    MODE_NONHLS,
};

static void print_usage(const char *prog)
{
    fprintf(stderr, "Usage: %s --mode <hls|nonhls> [--images <count>]\n", prog);
    fprintf(stderr, "  --mode    hls or nonhls (required)\n");
    fprintf(stderr, "  --images  number of test images, 1-%d (default: %d)\n",
            NUM_TEST_IMAGES, NUM_TEST_IMAGES);
}

static int load_weights(int fd)
{
    struct cnn_weight_data wd;

    wd.count = NUM_WEIGHTS;
    wd.data = (uint32_t *)weights_fixed;

    if (ioctl(fd, CNN_IOCTL_LOAD_WEIGHTS, &wd) < 0) {
        perror("ioctl LOAD_WEIGHTS");
        return -1;
    }
    return 0;
}

static int run_single_inference(int fd, const int32_t *image, enum cnn_mode mode)
{
    struct cnn_inference_req req;
    unsigned long ioctl_cmd;

    req.input_size = CNN_INPUT_SIZE;

    if (mode == MODE_HLS) {
        memcpy(req.image, image, CNN_INPUT_SIZE * sizeof(uint32_t));
        ioctl_cmd = CNN_IOCTL_RUN_INFERENCE;
    } else {
        for (int j = 0; j < CNN_INPUT_SIZE; j++)
            req.image[j] = image[j] & 0xff;
        ioctl_cmd = CNN_IOCTL_RUN_NONHLS;
    }

    if (ioctl(fd, ioctl_cmd, &req) < 0) {
        perror("ioctl RUN");
        return -1;
    }

    return req.result;
}

int main(int argc, char *argv[])
{
    enum cnn_mode mode = -1;
    const char *mode_str = NULL;
    int fd, correct = 0, i;
    int num_images = NUM_TEST_IMAGES;

    /* Parse command line */
    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--mode") == 0 && i + 1 < argc) {
            i++;
            if (strcmp(argv[i], "hls") == 0) {
                mode = MODE_HLS;
                mode_str = "HLS";
            } else if (strcmp(argv[i], "nonhls") == 0) {
                mode = MODE_NONHLS;
                mode_str = "Non-HLS";
            } else {
                fprintf(stderr, "Unknown mode: %s\n", argv[i]);
                print_usage(argv[0]);
                return 1;
            }
        } else if (strcmp(argv[i], "--images") == 0 && i + 1 < argc) {
            i++;
            num_images = atoi(argv[i]);
            if (num_images < 1 || num_images > NUM_TEST_IMAGES) {
                fprintf(stderr, "Invalid image count: %s (must be 1-%d)\n",
                        argv[i], NUM_TEST_IMAGES);
                return 1;
            }
        } else {
            print_usage(argv[0]);
            return 1;
        }
    }

    if (mode_str == NULL) {
        fprintf(stderr, "Error: --mode is required\n");
        print_usage(argv[0]);
        return 1;
    }

    fd = open(DEV_PATH, O_RDWR);
    if (fd < 0) {
        perror("open " DEV_PATH);
        return 1;
    }

    printf("\n============================================================\n");
    printf("  CNN MNIST Inference - Mode: %s\n", mode_str);
    printf("============================================================\n\n");

    /* Load weights only for HLS mode */
    if (mode == MODE_HLS) {
        printf("Loading weights...\n");
        if (load_weights(fd)) {
            close(fd);
            return 1;
        }
        printf("Weights loaded.\n");
    } else {
        printf("Skipping weight load (not needed for Non-HLS).\n");
    }

    printf("Running inference on %d test images...\n\n", num_images);

    for (i = 0; i < num_images; i++) {
        int predicted = run_single_inference(fd, test_images_fixed[i], mode);
        int expected  = test_labels[i];

        if (predicted < 0) {
            printf("Image %d: ERROR\n", i);
            continue;
        }

        printf("Image %d: ", i);
        if (predicted == expected) {
            printf("PASS - Predicted: %d, Expected: %d\n", predicted, expected);
            correct++;
        } else {
            printf("FAIL - Predicted: %d, Expected: %d\n", predicted, expected);
        }
    }

    printf("\n============================================================\n");
    printf("  RESULTS  [%s]\n", mode_str);
    printf("============================================================\n");
    printf("Total images: %d\n", num_images);
    printf("Correct:      %d\n", correct);
    printf("Accuracy:     %.1f%%\n",
           (float)correct / num_images * 100.0f);
    printf("============================================================\n\n");

    if (correct == num_images)
        printf("ALL TESTS PASSED!\n");
    else
        printf("Some tests failed.\n");

    close(fd);
    return 0;
}
