// SPDX-License-Identifier: GPL-2.0 */
#ifndef WEIGHTS_ARRAY_VGG_H
#define WEIGHTS_ARRAY_VGG_H

#include <stdint.h>

#define NUM_WEIGHTS_VGG		4710

extern const int32_t weights_fixed_vgg[NUM_WEIGHTS_VGG];

#endif /* WEIGHTS_ARRAY_VGG_H */
