// SPDX-License-Identifier: GPL-2.0 */
#ifndef WEIGHTS_ARRAY_LENET_H
#define WEIGHTS_ARRAY_LENET_H

#include <stdint.h>

#define NUM_WEIGHTS_LENET             5738

extern const int32_t weights_fixed_lenet[NUM_WEIGHTS_LENET];

#endif /* WEIGHTS_ARRAY_LENET_H */
