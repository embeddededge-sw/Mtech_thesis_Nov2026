// SPDX-License-Identifier: GPL-2.0
/*
 * cnn_common_test.c - Unified userspace test/driver for CNN accelerator
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <stdint.h>
#include <time.h>

#include "cnn_accel_uapi.h"
#include "weights_array_vgg.h"
#include "weights_array_lenet.h"
#include "test_images.h"

#define DEV_PATH "/dev/cnn0"

enum cnn_mode {
    MODE_NON_HLS,
    MODE_HLS_VGG,
    MODE_HLS_LENET,
};

/* ---------- helpers --------------------------------------------------- */

static uint64_t get_time_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}

static void print_usage(const char *prog)
{
    fprintf(stderr,
        "Usage:\n"
        "  %s --mode <lenet|vgg|nonhls> [--images <count>]\n"
        "  %s --mode <lenet|vgg|nonhls> --serve\n"
        "\n"
        "  --mode    lenet, vgg, or nonhls (required)\n"
        "  --images  batch size, 1-%d (default: %d)\n"
        "  --serve   load weights once, read 784-byte images from stdin,\n"
        "            write \"<digit>\\n\" to stdout per image\n",
        prog, prog, NUM_TEST_IMAGES, NUM_TEST_IMAGES);
}

static int load_weights_vgg(int fd)
{
    struct cnn_weight_data wd;
    wd.count = NUM_WEIGHTS_VGG;
    wd.data  = (uint32_t *)weights_fixed_vgg;
    if (ioctl(fd, CNN_IOCTL_LOAD_WEIGHTS, &wd) < 0) {
        perror("ioctl LOAD_WEIGHTS (vgg)");
        return -1;
    }
    return 0;
}

static int load_weights_lenet(int fd)
{
    struct cnn_weight_data wd;
    wd.count = NUM_WEIGHTS_LENET;
    wd.data  = (uint32_t *)weights_fixed_lenet;
    if (ioctl(fd, CNN_IOCTL_LOAD_WEIGHTS, &wd) < 0) {
        perror("ioctl LOAD_WEIGHTS (lenet)");
        return -1;
    }
    return 0;
}

static int load_weights_for_mode(int fd, enum cnn_mode mode)
{
    switch (mode) {
    case MODE_HLS_VGG:
        fprintf(stderr, "Loading VGG weights...\n");
        if (load_weights_vgg(fd)) return -1;
        fprintf(stderr, "VGG weights loaded.\n");
        return 0;
    case MODE_HLS_LENET:
        fprintf(stderr, "Loading LeNet weights...\n");
        if (load_weights_lenet(fd)) return -1;
        fprintf(stderr, "LeNet weights loaded.\n");
        return 0;
    case MODE_NON_HLS:
        fprintf(stderr, "Non-HLS mode: no weight load required.\n");
        return 0;
    }
    return -1;
}

static int run_single_inference(int fd, const uint32_t *image_bits, enum cnn_mode mode)
{
    struct cnn_inference_req req;
    unsigned long ioctl_cmd;

    // FIX: Zero out the request structure to prevent uninitialized memory 
    // from corrupting the ioctl payload.
    memset(&req, 0, sizeof(req)); 
    req.input_size = CNN_INPUT_SIZE;

    if (mode == MODE_HLS_VGG || mode == MODE_HLS_LENET) {
        memcpy(req.image, image_bits, CNN_INPUT_SIZE * sizeof(uint32_t));
        ioctl_cmd = CNN_IOCTL_RUN_INFERENCE;
    } else {
        for (int j = 0; j < CNN_INPUT_SIZE; j++)
            req.image[j] = image_bits[j] & 0xff;
        ioctl_cmd = CNN_IOCTL_RUN_NONHLS;
    }

    if (ioctl(fd, ioctl_cmd, &req) < 0) {
        perror("ioctl RUN");
        return -1;
    }
    return req.result;
}

static int read_full(int fd, uint8_t *buf, size_t n)
{
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(fd, buf + got, n - got);
        if (r < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (r == 0) {
            if (got == 0) return 1;   
            fprintf(stderr, "truncated frame: %zu/%zu bytes\n", got, n);
            return -1;
        }
        got += (size_t)r;
    }
    return 0;
}

static int run_batch(int fd, enum cnn_mode mode, int num_images)
{
    int correct = 0;
    uint64_t start, end;

    fprintf(stderr, "Running inference on %d test images...\n\n", num_images);
    start = get_time_ns();
    
    for (int i = 0; i < num_images; i++) {
        int predicted = run_single_inference(fd, (const uint32_t *)test_images_fixed[i], mode);
        int expected  = test_labels[i];

        if (predicted < 0) {
            printf("Image %d: ERROR\n", i);
            continue;
        }

        printf("Image %d: ", i);
        if (predicted == expected) {
            printf("PASS - Predicted: %d, Expected: %d\n", predicted, expected);
            correct++;
        } else {
            printf("FAIL - Predicted: %d, Expected: %d\n", predicted, expected);
        }
    }
    end = get_time_ns();

    printf("\n============================================================\n");
    printf("  Total images: %d\n", num_images);
    printf("  Correct:      %d\n", correct);
    printf("  Accuracy:     %.1f%%\n", (float)correct / num_images * 100.0f);
    printf("============================================================\n");
    return correct == num_images ? 0 : 2;
}

static int run_serve(int fd, enum cnn_mode mode)
{
    uint8_t raw[CNN_INPUT_SIZE];
    uint32_t img_bits[CNN_INPUT_SIZE];
    unsigned long n = 0;

    fprintf(stderr, "Serve mode: reading %d-byte frames from stdin...\n", CNN_INPUT_SIZE);

    for (;;) {
        int rc = read_full(STDIN_FILENO, raw, CNN_INPUT_SIZE);
        if (rc == 1) {
            fprintf(stderr, "EOF after %lu inferences.\n", n);
            return 0;
        }
        if (rc < 0) {
            fprintf(stderr, "read(stdin): %s\n", strerror(errno));
            return 1;
        }

        // Convert 0-255 integer to Q16.16 fixed-point (with proper rounding)
        for (int j = 0; j < CNN_INPUT_SIZE; j++) {
            float fval = (float)raw[j] / 255.0f;
            int32_t fixed_val = (int32_t)(fval * 65536.0f + 0.5f); // +0.5f for rounding
            img_bits[j] = (uint32_t)fixed_val;
        }

        int predicted = run_single_inference(fd, img_bits, mode);
        printf("%d\n", predicted);
        fflush(stdout);
        n++;
    }
}

int main(int argc, char *argv[])
{
    enum cnn_mode mode = -1;
    const char *mode_str = NULL;
    int serve = 0;
    int num_images = NUM_TEST_IMAGES;
    int fd;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--mode") == 0 && i + 1 < argc) {
            i++;
            if (strcmp(argv[i], "vgg") == 0) {
                mode = MODE_HLS_VGG;    mode_str = "VGG";
            } else if (strcmp(argv[i], "lenet") == 0) {
                mode = MODE_HLS_LENET;  mode_str = "LeNet";
            } else if (strcmp(argv[i], "nonhls") == 0) {
                mode = MODE_NON_HLS;    mode_str = "Non-HLS";
            } else {
                fprintf(stderr, "Unknown mode: %s\n", argv[i]);
                print_usage(argv[0]);
                return 1;
            }
        } else if (strcmp(argv[i], "--images") == 0 && i + 1 < argc) {
            i++;
            num_images = atoi(argv[i]);
            if (num_images < 1 || num_images > NUM_TEST_IMAGES) {
                fprintf(stderr, "Invalid image count: %s (must be 1-%d)\n", argv[i], NUM_TEST_IMAGES);
                return 1;
            }
        } else if (strcmp(argv[i], "--serve") == 0) {
            serve = 1;
        } else {
            print_usage(argv[0]);
            return 1;
        }
    }

    if (mode_str == NULL) {
        fprintf(stderr, "Error: --mode is required\n");
        print_usage(argv[0]);
        return 1;
    }

    fd = open(DEV_PATH, O_RDWR);
    if (fd < 0) {
        perror("open " DEV_PATH);
        return 1;
    }

    fprintf(stderr, "\n============================================================\n");
    fprintf(stderr, "  CNN MNIST  |  Mode: %s  |  %s\n", mode_str, serve ? "SERVE" : "BATCH");
    fprintf(stderr, "============================================================\n\n");

    if (load_weights_for_mode(fd, mode) < 0) {
        close(fd);
        return 1;
    }

    int rc = serve ? run_serve(fd, mode) : run_batch(fd, mode, num_images);
    close(fd);
    return rc;
}
