const express = require('express');
const { spawn } = require('child_process');
const Jimp = require('jimp');

const HOST = '10.42.0.34';
const PORT = 3001;

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static('public'));

const cnn = spawn('./main_cnn_accel_app', ['--mode', 'lenet', '--serve'], {
  stdio: ['pipe', 'pipe', 'inherit'],
});

let stdoutBuf = Buffer.alloc(0);
const pending = [];

cnn.stdout.on('data', (chunk) => {
  stdoutBuf = Buffer.concat([stdoutBuf, chunk]);
  let nl;
  while ((nl = stdoutBuf.indexOf(0x0a)) !== -1) {
    const line = stdoutBuf.slice(0, nl).toString().trim();
    stdoutBuf = stdoutBuf.slice(nl + 1);
    const waiter = pending.shift();
    if (waiter) {
      waiter.resolve(parseInt(line, 10));
    }
  }
});

// FORCE KILL THE C PROCESS ON EXIT OR CTRL+C
function cleanup() {
  console.log('\nShutting down gracefully...');
  try { cnn.kill('SIGKILL'); } catch (_) {}
  process.exit(0);
}

process.on('SIGINT', cleanup);   // Catches CTRL+C
process.on('SIGTERM', cleanup);  // Catches kill commands
process.on('exit', cleanup);     // Catches normal exits

app.post('/submit', async (req, res) => {
  const base64Data = (req.body.image || '').replace(/^data:image\/png;base64,/, '');
  if (!base64Data) return res.status(400).send('No image provided.');

  try {
    const image = await Jimp.read(Buffer.from(base64Data, 'base64'));
    
    // 1. Force a black background to handle transparent canvases
    image.background(0x000000ff);
    image.grayscale();

    const w = image.bitmap.width;
    const h = image.bitmap.height;
    const data = image.bitmap.data;

    // 2. Find the bounding box of the white stroke
    let minX = w, minY = h, maxX = -1, maxY = -1;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const idx = (y * w + x) * 4;
        if (data[idx] > 30) { // If pixel is bright/white
          if (x < minX) minX = x;
          if (x > maxX) maxX = x;
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
      }
    }

    const bytes = Buffer.alloc(784);

    if (maxX !== -1) {
      const cropW = maxX - minX + 1;
      const cropH = maxY - minY + 1;

      // 3. Crop and resize to 20x20 bounding box
      const cropped = image.clone().crop(minX, minY, cropW, cropH);
      const scale = 20 / Math.max(cropW, cropH);
      const newW = Math.max(1, Math.round(cropW * scale));
      const newH = Math.max(1, Math.round(cropH * scale));
      cropped.resize(newW, newH);

      // 4. Center inside 28x28 black canvas
      const finalImage = new Jimp(28, 28, 0x000000ff);
      const pasteX = Math.floor((28 - newW) / 2);
      const pasteY = Math.floor((28 - newH) / 2);
      finalImage.composite(cropped, pasteX, pasteY);

      // 5. Extract grayscale
      const finalData = finalImage.bitmap.data;
      for (let p = 0; p < 784; p++) {
        bytes[p] = finalData[p * 4]; 
      }
    }

    const digit = await new Promise((resolve) => {
      pending.push({ resolve });
      cnn.stdin.write(bytes);
    });

    res.send({ result: String(digit) });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).send('Error');
  }
});

app.listen(PORT, HOST, () => {
  console.log(`Server running at http://${HOST}:${PORT}`);
});
