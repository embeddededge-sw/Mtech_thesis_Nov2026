
## Download "node-v22.23.3-linux-arm64.tar.gz" on target
wget https://nodejs.org/dist/v22.23.3/node-v22.23.3-linux-arm64.tar.gz

sudo su
cd /home/petalinux/lenet_server
export PATH=/home/petalinux/lenet_server/node-v22.23.3-linux-arm64/bin:$PATH
# npm install --omit=dev
./run.sh

## Run below URL on web browser on HOST PC
http://10.42.0.34:3001/

Note: - PC and Target should be connected via LAN cable.
