#!/usr/bin/env python3
"""
Usage:
    sudo python3 benchmark_10000.py <bmp_folder> <num_inferences>

Example:
    sudo python3 benchmark_10000.py /home/ubuntu/udemy_cmnist/bmp 10000
"""
import argparse
import gc
import re
import sys
import time
from pathlib import Path
from collections import Counter

import numpy as np
from PIL import Image
from pynq import Overlay, allocate

# ---------------------------------------------------------------
# Fixed config (edit if your bitstream path differs)
# ---------------------------------------------------------------
BITSTREAM_PATH = "/home/ubuntu/udemy_cmnist/cnn_mnist.bit"
IMG_BYTES      = 784
WARMUP_RUNS    = 200

# ---------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------
def parse_args():
    ap = argparse.ArgumentParser(
        description="Benchmark CNN MNIST accelerator via AXI DMA.")
    ap.add_argument("bmp_folder", type=Path,
                    help="Path to folder containing BMPs and labels.txt")
    ap.add_argument("num_inferences", type=int,
                    help="Total number of inferences to run")
    args = ap.parse_args()

    if not args.bmp_folder.is_dir():
        sys.exit(f"ERROR: {args.bmp_folder} is not a directory")
    if args.num_inferences <= 0:
        sys.exit("ERROR: num_inferences must be positive")
    return args

# ---------------------------------------------------------------
# labels.txt parser
# ---------------------------------------------------------------
def parse_labels(path):
    """Return {filename: digit} from a labels.txt file."""
    pattern = re.compile(r'^\s*digit\s+(\d)\s*:\s*(.*)$', re.IGNORECASE)
    label_of = {}
    with open(path, "r") as f:
        for lineno, line in enumerate(f, 1):
            line = line.split('#', 1)[0].rstrip()
            if not line.strip():
                continue
            m = pattern.match(line)
            if not m:
                print(f"[warn] line {lineno} not recognized: {line!r}")
                continue
            digit = int(m.group(1))
            if not 0 <= digit <= 9:
                print(f"[warn] line {lineno}: digit {digit} out of range")
                continue
            for fn in m.group(2).split(','):
                fn = fn.strip()
                if not fn:
                    continue
                if fn in label_of and label_of[fn] != digit:
                    print(f"[warn] {fn} was digit {label_of[fn]}, now {digit}; overwriting")
                label_of[fn] = digit
    return label_of

# ---------------------------------------------------------------
# Main
# ---------------------------------------------------------------
def main():
    args = parse_args()
    bmp_dir = args.bmp_folder
    labels_txt = bmp_dir / "labels.txt"

    if not labels_txt.exists():
        sys.exit(f"ERROR: {labels_txt} not found — create it first")

    label_of = parse_labels(labels_txt)
    if not label_of:
        sys.exit(f"ERROR: no labeled files in {labels_txt}")
    print(f"Parsed {len(label_of)} labeled files from {labels_txt}")

    # ---------------- load overlay + buffers once ----------------
    print(f"Loading overlay from {BITSTREAM_PATH} ...")
    overlay  = Overlay(BITSTREAM_PATH)
    dma_send = overlay.axi_dma_0.sendchannel
    dma_recv = overlay.axi_dma_0.recvchannel

    input_buffer  = allocate(shape=(IMG_BYTES,), dtype=np.uint8)
    output_buffer = allocate(shape=(1,),         dtype=np.uint8)

    # ---------------- load BMPs ----------------
    samples = []
    for fn, label in label_of.items():
        p = bmp_dir / fn
        if not p.exists():
            print(f"[skip] {fn}: file not found")
            continue
        arr = np.array(Image.open(p).convert("L"), dtype=np.uint8).reshape(-1)
        if arr.size != IMG_BYTES:
            print(f"[skip] {fn}: {arr.size} pixels, expected {IMG_BYTES}")
            continue
        samples.append((arr, label, fn))

    if not samples:
        sys.exit("ERROR: no usable samples loaded")

    print(f"Loaded {len(samples)} samples; cycling to reach {args.num_inferences} inferences.")
    print("Label distribution:", dict(sorted(Counter(l for _, l, _ in samples).items())))

    # ---------------- warm-up ----------------
    print(f"Warming up ({WARMUP_RUNS} transfers) ...")
    for i in range(WARMUP_RUNS):
        input_buffer[:] = samples[i % len(samples)][0]
        dma_send.transfer(input_buffer)
        dma_recv.transfer(output_buffer)

    # ---------------- timed loop ----------------
    print(f"Running {args.num_inferences} inferences ...")
    gc.collect()

    results = np.empty(args.num_inferences,
                       dtype=[('idx','i4'), ('expected','i4'),
                              ('predicted','i4'), ('name','U64')])

    t_start = time.perf_counter_ns()
    for i in range(args.num_inferences):
        arr, expected, name = samples[i % len(samples)]
        input_buffer[:] = arr
        dma_send.transfer(input_buffer)
        dma_recv.transfer(output_buffer)
        results[i] = (i, expected, int(output_buffer[0]), name)
    t_end = time.perf_counter_ns()

    elapsed_ns = t_end - t_start
    elapsed_s  = elapsed_ns / 1_000_000_000

    # ---------------- per-inference printout ----------------
    correct = int((results['expected'] == results['predicted']).sum())
    print(f"\n{'idx':>6}  {'file':<24}  {'expected':>8}  {'predicted':>9}  status")
    print("-" * 64)
    for r in results:
        ok = r['expected'] == r['predicted']
        print(f"{r['idx']:>6}  {r['name']:<24}  {r['expected']:>8}  "
              f"{r['predicted']:>9}  {'OK' if ok else 'FAIL'}")

    # ---------------- summary ----------------
    accuracy = 100.0 * correct / args.num_inferences
    print("\n" + "=" * 64)
    print(f"Total inferences : {args.num_inferences}")
    print(f"Correct          : {correct}")
    print(f"Accuracy         : {accuracy:.2f} %")
    print(f"Elapsed time     : {elapsed_ns} ns")
    print(f"Elapsed time     : {elapsed_s:.9f} s")
    print("=" * 64)

    # ---------------- per-image breakdown ----------------
    print(f"\n{'file':<24}  {'label':>6}  {'runs':>6}  {'correct':>8}  {'acc %':>7}")
    print("-" * 64)
    for name in np.unique(results['name']):
        sel   = results[results['name'] == name]
        total = len(sel)
        good  = int((sel['expected'] == sel['predicted']).sum())
        print(f"{name:<24}  {sel['expected'][0]:>6}  {total:>6}  "
              f"{good:>8}  {100*good/total:>6.2f}")

if __name__ == "__main__":
    main()
