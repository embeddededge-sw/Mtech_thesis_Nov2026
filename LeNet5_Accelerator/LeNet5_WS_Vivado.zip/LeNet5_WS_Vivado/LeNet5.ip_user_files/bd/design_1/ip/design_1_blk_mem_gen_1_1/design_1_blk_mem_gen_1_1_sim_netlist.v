// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.1 (lin64) Build 5076996 Wed May 22 18:36:09 MDT 2024
// Date        : Tue Oct 20 14:00:25 2026
// Host        : mirfai-ThinkCentre-neo-50q-Gen-5 running 64-bit Ubuntu 24.04.4 LTS
// Command     : write_verilog -force -mode funcsim
//               /home/mirfai/Documents/Kria-KV260/Thesis_Option_4/LeNet5/LeNet5.gen/sources_1/bd/design_1/ip/design_1_blk_mem_gen_1_1/design_1_blk_mem_gen_1_1_sim_netlist.v
// Design      : design_1_blk_mem_gen_1_1
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xck26-sfvc784-2LV-c
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "design_1_blk_mem_gen_1_1,blk_mem_gen_v8_4_8,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_8,Vivado 2024.1" *) 
(* NotValidForBitStream *)
module design_1_blk_mem_gen_1_1
   (clka,
    rsta,
    ena,
    wea,
    addra,
    dina,
    douta,
    clkb,
    rstb,
    enb,
    web,
    addrb,
    dinb,
    doutb,
    rsta_busy,
    rstb_busy);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA RST" *) input rsta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA WE" *) input [3:0]wea;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [31:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DIN" *) input [31:0]dina;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB CLK" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTB, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE BRAM_CTRL, READ_WRITE_MODE READ_WRITE, READ_LATENCY 1" *) input clkb;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB RST" *) input rstb;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB EN" *) input enb;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB WE" *) input [3:0]web;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB ADDR" *) input [31:0]addrb;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB DIN" *) input [31:0]dinb;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTB DOUT" *) output [31:0]doutb;
  output rsta_busy;
  output rstb_busy;

  wire [31:0]addra;
  wire [31:0]addrb;
  wire clka;
  wire clkb;
  wire [31:0]dina;
  wire [31:0]dinb;
  wire [31:0]douta;
  wire [31:0]doutb;
  wire ena;
  wire enb;
  wire rsta;
  wire rsta_busy;
  wire rstb;
  wire rstb_busy;
  wire [3:0]wea;
  wire [3:0]web;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "32" *) 
  (* C_ADDRB_WIDTH = "32" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "8" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "2" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "0" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "1" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "1" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     5.860378 mW" *) 
  (* C_FAMILY = "zynquplus" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "1" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "1" *) 
  (* C_HAS_RSTB = "1" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "NONE" *) 
  (* C_INIT_FILE_NAME = "no_coe_file_loaded" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "0" *) 
  (* C_MEM_TYPE = "2" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "2048" *) 
  (* C_READ_DEPTH_B = "2048" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "1" *) 
  (* C_USE_BYTE_WEA = "1" *) 
  (* C_USE_BYTE_WEB = "1" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "4" *) 
  (* C_WEB_WIDTH = "4" *) 
  (* C_WRITE_DEPTH_A = "2048" *) 
  (* C_WRITE_DEPTH_B = "2048" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "zynquplus" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  design_1_blk_mem_gen_1_1_blk_mem_gen_v8_4_8 U0
       (.addra({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addra[12:2],1'b0,1'b0}),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,addrb[12:2],1'b0,1'b0}),
        .clka(clka),
        .clkb(clkb),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina(dina),
        .dinb(dinb),
        .douta(douta),
        .doutb(doutb),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(enb),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[31:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(rsta),
        .rsta_busy(rsta_busy),
        .rstb(rstb),
        .rstb_busy(rstb_busy),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[31:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(wea),
        .web(web));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2024.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
RSqbsRZSIb+QlYJMfFv1T7uHQ7PiCEXQkl687MHGm2LgPB15GIYcPmqKUSXgtkLsIFes91PTAyyB
9H9cyY4ZUxedcRg/9ZOB5pm3zPqAbcvGPmg1ivMhr/MlS19t5lYKM2tQo+0Yd+arJXlVZu2BMnvn
+I3G9t9tJuWUIWKjI+I=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
VRSQ05ZaB6bIhFIQ823mTvlJaG9+5iW5C3+KxGjq0sq9ziCshKOLpOGPDMmOWDqA4uBaxC5IKISr
w8+A8mqbYjXo5m1g8sGjNaETS0HKJsK+l5Y++tN4IEUs+DwxgrPR/+LWtChuOzVkfC7BG3LVUEMj
zM3GAyGcXGJ3sdBItZAfsevyiy7kr4Fw+nk2hWytGteu1NZk3VzPE7KQHLkOlHBPXf6P0j8LpKcr
2oNDgQ/WaEmg6OOvFeJuaWDaee8Sn6wKP/caMyoGdSeczsPtRrJeoSRlbNHlxhCv7zg+Cn2AgwrR
PTqGsMrkhv9U0sq+waS0CmwChsk4WB7RspGYUg==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
tNziOjCznlvIl4dadmB9r23Duf+HQHWOuHmupEU3PJxrazHVtZdNKspG9sRXhF9mjbpnSiKYCdFK
Jr9W/dxUid36faFIPKQazVTuOiE0hkzVQAGpYxXjT/ITB/9EFBvgvP5L3EAhHv32x6MA1vkFSI7x
HrZ09YNFEF6T7DPTZE4=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
QCYfxgkUHlX1cre1q9aS3sVDIOX36YBK4ZwJXAVUwA6f1OQ77XibjpWJHt5FK9F0PcYp/j21pqzO
BRdkDcFLVAjxER4J5t5iMVhoeMk+3fpiKfYrm4WFl1ygsJsfFJP0jqO1OkjC8iFBtm3n6b7CTl1o
cjBbcBp8UgW6E8rf5inXA0dRqybnyxKJSnMFYLinvpVU6QEc4OKO7mi/i/s9p/efiP+CdQf0yDRU
Fw7o7x0D7tjBv943g5L+4wGZ2JYU+ISqn4Ajxy/bWTTJDe6T/15evhngS61MC8Xjamzc4YLZBP8o
ShfSLoeZeO+Hk5n3xzJRghM0DQ6Sj7NqXFY68w==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Uy8FDDy3dZQGAnMQV0HBesEs+/oZdaq35Kj1PGhy9J/+EBZm0nhhQgYtku8tWABW2jKAC1GtNTvo
uReQyr1hteMxTbD5OIuqv86eb1hXZVENlZ7ichG8auUjkeHAkaSYNbHOuDLIhSqHEL67XbcZ9zPG
1JOY3+VONSww0KYPcQbGSo/2DaC5C0Y+mZODRfJ4+b0WXjce6UaJetilBc3VtqqmodIM2d3HDawF
R0xVJfHj86rXmUkY+SNUw60zsV6raCY6G3k/rXpei1d6zn8tCThkKG5fwiWY8zA7kRdTFIlVKP9h
fb6kfzRBRT/BgVQ8d4RgEcEVV8m3u/Mf4KIlTw==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2023_11", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Pk1GeRlkUK9lt6DVXYVdtOABlzDEWQDcBsP/p+Wo5HaglDLG5b8gk08xTP3IcJ1RKcfuARPMGO2s
/VqFbnVADV90T1rhjIuWMcBnzYQK/ALUvwv11Uju9Gn0fvPIz52l3QBnpjHI1nlsFB7WeqkzVfHZ
tg9gO9bPHjHLjVd9BzH6McrEWY5RkZ0UBy0Fmh/SownJX1b0YGE7LdwKydEMEpyvb28bwTOwfEv/
4RtsfYtEvTjo6e1ZBm66D9IQmKUu32wzTfn5bFZHdyjZg6+HcTzvHMtQX2+AggXfP6FsO2/83qkb
0bfj226fnLhr32dJxtsaJS5OR63GYtzDJ05ITA==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
LCfWqKmUoUSVOTKNAl5p8n1hfz7SMU2kDOUMBjsDncgSFqiu2zUy1I6GSDrVnF/2umJG5/mWcpvi
rQaFJOlrJ8DNctSuavdlopRAwTMsVi6dAlNGrAawSiDIxtI3tN3MDVdMiH5H+pJMqMt59yXneyCf
2RRSRz2sUQK/aj0lXlqKjVJzVbk8HaBQ8akBJF4iWSMK4foIzJ6iO1EupYovuW6uEiO7jQRWezlW
pbbDenOHHWbfinuX5cbkjpTKHGsEKct65q+ZXJp60m3sconSK3Y2eLQxusuJ1FHDJ4GGKO8mEzCv
3cfGdXX3pVL81OfGO/JD1aMs9H98CO5ssbHqlw==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
A4S1e3DHcTeWzaDVuWDRb3Yf1BjiEsR1RtAeL0BJ7J/oPWMNj96MeGsUiHtZoiYqteTZxqax2cyZ
PV0cMLoBK4Ya8CyM+BTnkFA2ablsGt5Es4TgG/nFS9VEhmeKxu8boAsqW5697aiqOATJf/LucQh5
GOnPXHAuPrDj0A/fu8N2QduqGyysWUSc1KsoJ0/0noJYvLJ2yOhFi4uIUYQfG5LOuOrca5P43pqA
iwUKW/RrFXal2acJdFeXIKffZpKanSV97urdzKyBvf9EPV/M8g9uPFJJ1z6aS+FbknhVPs0pt6eD
+J/qib4gVp/HGnRo4YlxauUMv6Yv9wxiaObY6ttDfYf5p3uzWZMlf3i7YOzZwcd4aS/6+vkD28LG
L9piBIpLx2dvQy74RdvCVdvaP1LC6RMju9RfuXJhuX4ZAmDxRi0zQyRda838ikzwYeOCSKLIvRPb
nuJ8Zx2ot8EFqSeGaaRFaEMU6Zf5SptCUuVMHvSkinBewcwrLB5uiJTJ

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
gj+uMxV+tK4Di7pgSOE82FOBeWmUB1A7OKFOSMUW3qrmQ4/YhryfHMlWPxfAq8avQL7tnBTnRFEg
czbErdIcNzYjrM7Qq00QC/mTqmeQX4/apbqGvN+rwK4RR5oj22wfTib/UQNEQX6fbpi6PtmAeUR9
eShsfq+YWcf7z2Zw4Q+o4+E6m4/3CzU68vglNpzNsJ8S9/8XpdIrvAA/WRAX6OEOC4wlNIKDZsq/
+zMbFgSzN1rP844I/CDmxYM0NIzBWWhYBkPfJyQyigmUoXb84lDip0/Dmnq4EHvu7D/tZNnDl5st
JpftRfEpT6S8e/5MBeKUuhbfg6etHo/oFZvPKQ==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
aWTy3xv6SqKsldtLS2gY4KrTS8U+KtFNRHS314f6EYZy1MHE9t7oICJ8eNB8up8A+odoE23N3fJb
1alhaadeRWU2GjlIiK1LjZ5PQw+jb1u1GWtRiY+TcTlD75XUlqwykVBrCDfm565DmgZjZle9T3/t
WEfLo+m/8GfBe8trVnoftsk/XI00BMFXRzw8doPGDhNECS1NUrLebryb9iO5Hf4A/40dtslTARsR
nicN0KoIIyiQ+QzliqyXU/8VjS45inON8R0Kv9Qx46EXUp7bds5uQ7QycRhpLG0IPnMIweudU67w
eQmpHJzvZKBCZks/R0OafZx44H6Jib2+QazBCw==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
UGdPiChIPj1lSozqzCQx17Bi+8FWSuMUMzXUkDLH5zcP1t8tZLzh4CU4WAR8lmJxn8gH763fLp5c
RYU6zA0yxHzl2ksc5YRU1XEfQQT9ha8fQnz+18wVKcsa5UIOfMbGDwnS9yfX59ntG8CB0uF8bJKE
y1CS6U/1Stfs1w2mF94iDxI2n2GJlb1UPtWpmxMBI88hY0GktTPXP2Y7JKl8zRl/Lq0wIF8pHwXk
B4nOgKm6hfzPj0xZ6E/TuER/JE3fy8RSm24IlL/CUgpReEslEOYjQ4EKKZRG9/fxg26utQWW9p+G
fWVU53qrFGzBhKQ96Paj1ROkv6hDHyUb6n7uSw==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 64480)
`pragma protect data_block
9NHCkx44QKBiGOpgtafpotxlBGyzI5DTkDt4N5XC6ECiCagJ47qkgrSCcxZoeNoAaJUBmHWnaS6h
SZHv1QbR0hWZQ2IXjlaC5/OC7/aX+UUa5M39SBEKhCN70/QeE4svSupsW6vh5xhBByqQ18Bj153G
23jeKFnW2KTBX6DB+cOTsqfz6oC0Ex2arrVBuJMcBYe1u8HWlAW+3hN6ePUeHYL5a3pTAt4rhMlR
W4iiMWk03GY+vXUFqUSr6HLrT4nU+oFZQmQkvqn+ciCZNPcK7bK1y+OU+paVHnNCBbLBVc8kkpt3
e6bDUg9Dhhcs18RFQ/bHa+4qp5GrOLWumhCnTWPFtNEayyCdIIXpDodM6MVML7045Lw0ppOx/yb+
esBZbiaUPKbh5KjdpkAWjs+ssS1zNcNOfZsyTDBna/NXuOHrmo/ZNmlOeaWT7KLmxkZTNsZVDo26
G3U2XtEonQU3zcEgFZKs58+Lf6ZzS87l7CfAMZZBjaq0pD53Jke9NZghQSOdF8i3IpL1GahDwmXQ
GYf59ssGIsoUVCAHqbJpQrJF4BsU+ky6eFDs9HhCvhvvJH/Uzbc69cOgtbg+R/hW0yz1d2cDPs6J
izxlZoIeltBKU5+64VUbiLrZA9DWVSKNtfpoYsMERlx2RBolt5jozylKn2U3FDuISmySgfcMEt3u
Ju2BwhisAHIidJUEdSsDeCFHEtCKS84RaZNwxBegRffEotzvrHzqSqCCqmQZKogFX+M2UDjgmdX+
vdjbkpmTqvsWYiLJ2UUCzMQjdSaPv4HWEFHhpZHLIZV9et7fuPfk3lfXsTpZqHvwdT6zQQ9UBbMy
SC3u8AouU01+cYVkP8XyoaDccMBJaE+39Gzj8SXKOAREdb9UazDS7adsOdUNDRfOLECsNHeg4/dU
ouWSwQD92jLdlZJ6x3FfCFfle8QG7d3Q2Kmt5zalkbKARyMOWZeC93oIBF67poa1guMj8BVslkKS
2NOg4JaLTYvhfF0yIS5dkd/p/rHtzRD9IF9e+Vp9gOE55g0QEmpe6gB8es3JglpPb5xVrdLBmNH8
SP8IOiywTdRXtCLvjOVBjMlRsGPRr9Cm5WcW6JXtNywxkRnv/iyk7x2CKhDP7V9Ka3byyfSs1UOw
YVv7WbHxUQYTTdAP5LIjRVkZUcEkAY6tewPZm3RTvkpKJc0Z+qKfDllqKLg4eIPhJ/fcVrj7aOU2
4cyqcxqg0GjbYPgSfONnp1Yvi6ofwUzWQHGemDnS47CbaGwMstmtvQQglLeP1cdCNh8AkL5+09iE
MwOBMDrFMZn9Nr9B3veL/jJkoHaG6UHdol61MmMSDzP+n7qjSmrfa0pHwnuZsJlFNUXs8wDg9rM/
s5vv09e25r+syd/6hHO0qSPrH3TI1a3+tfmTL7XIe/IYMjn0i9RufgMul1tzm+iC6+XnDhv/cIzV
z9T7a+KOBBqmMMg8IqZ1Dau8D/F2L6LwrP3dtY4eXKKHC9RNwSCxEZ8Tcsu/LYqOoc2VqCzGSZTJ
jetnbYMn+onoZJFWTYG8374mMltMZa0/uh8gicE23PoO8CDW8p13OptqFlbHrT6IsuR1hUO1kg84
x7jNq4uNLgQAFUS7wVAe9V763DSVRctnCUrMix0OVzvdVT0Fm/NIp96fksYE7LoawJaMlykgl47e
ZSeC3eCpzpSbUSMrMtBSBcBC+/kqvG/B8g+sJ9fOwExmJ+gXpn4Ix8bV/d+Hp5wXWkBRtMbklDKh
SGOiqmq6XRX1VNl6HE44at2Bhif5bfmrpweBYIEk5Yzn346yxhy7MjOj2dFnfLryw4uJ929jbbAK
Z3Mnh7qqpla7YrqQLSCWoHFXTxIWWCWwBHWFWqMmwe5U0B0JnRb8LPpsZFd4mvzEKpJUeRkKrNoX
5fy4ljE1pM4I4q1sM1pKeJrzQdZwImta2zYxQlwXknzGCUs8ZpCL6PYiNJe2nR94NALcn4UR9r68
xG5c+Qr5D3FwwxL1GU7p+q/ERmBfxUVjJ8nim3PIT9hdtCmILI/0JHpXPcgyG3KvK755aGwDiG8s
C1/BEnjLnaiA676ArMTvZY1fwe2qWKQC3l5afTJ2GeFYMr/ZQnSOFzjUJvwXCT+FxI//ookLFTFh
Fx8oaK2yqLLzY93zeFfPyH8j3HLM1qllHA+jAK5fSPWl/NtsnXHIRh6+3/YMw8byHmFPRhlxv6dh
hMN4VHvSpYy9Ia4VrCKEbb59V6xeZqZirELRT3wivywLRriOQlEPUdiGzYTkkmvd8DaXGEnd4BeJ
3+wYWmyUJXS2N1Nm2KlK1nUZB4sw0YfbUebSDM5xpuxhq+uSOfd1Ed3fV16aDOJ78JHiD1eKe+Bw
e90Vvd/K1pab4SCbln6bCzXeMhmWBojta5xS5KaerkWmC6H5D4B8zSbxKFBT69OpcqRuOc+vVGy2
GH8+rOYbXw4J6291feRCkeo4JEj0p1/yPHnqgQGbx5BjJ+R3RgEwXRE3zRmvlFjd2huQWw94a12o
F2hb9VqggBVyBz9qU1XB7DsflD3t2LoFzi4uXr/c76PtyPtzOx0FFnVX6H9GVFA39uq6FUPnYLOg
82wykJyeFpDV15ao4u6CKIdFI7c8ONj+Pbi6FHUm7jRQY7iKGtR21cSvVbRhgB0derwWm8Yx6B2h
xDh/viKXW9E/ZVbBbRHfde2vLwpJOCGGOIdRhjfg5Z9ZJJ4iTyegWfN+VH/8q0+aZyXVbOmRmN+X
pP8qxF9+/FX8cdjjdJ4Kh1OZfekB0eRNS3bYqCaZ6FR5dPGsfrVWCMFyptAWG+xKZzaQflWWImIO
SH8CRHPxQq2tkBEI+Jt/0Z33tcXOcdmhmOKh9FGhbCeg306RsIyEVSb/IH44HUUmIgHIZtXPjPtG
XxppTRERecjp3dS4SslKW4fa41y3pChL3ofwLw/010VTyP3WOAeE4tcfrAguG8crTvrUsUtayQ1A
LizwRk/7E71fBQ5LJ3gjiE6HsZnbB6fdzFecjGwGAO92YhihnovqXXOg8VZm/BVp7/FpKjMMa8bH
nxb45rESQ3cad+xgmg8y2zfEImGpgRt+LNtMmXYthPQCr523CJZVFekSZUt0Fix31bZ3r+crdS3g
8MAL/TMCOmhpDgfYzC5Z6jVUo6rrBRw2ZfAf4ozsY+aX8os0s+uuEYREPfvq+aoQyfw2A0Fltwd5
Lu5MFqf8dTeBgGtjI37QZYixkL4BM7o8neBVbbSIjwsyVbh6BVq3/dJQWjy2K+55Pq24vq4uyc8v
Dy0xUDgPxJ0+GJWaV06LtNXYe7lxvwdOSM5aI+YuGFPRz6spyh+PnOGiG/Z6/wOViXpr/w1/aOEk
Z3Z3vTjlaWXW3kkH0iNwakUgD5lIRbpe+K/PjF5RvaHtOlO+k8y9tTvFrYCNvVacnyHVvZ8UOadw
TpPyGrI9XzzT4vPSkLb60CGZ9oENESzrzJxtfienDWTFFJiqK5/MH/2ZeQimaZJEWRCL4LvSYvhA
ZrSIkBQy2T3HDU8PuETbxuMXl8+EY7jP7zEofWWTiD8n7WsWbZayGrJOL7szgbbRItuy8TYLj/zw
9ZAyH/k5FzN6QldYgI0O8xDiBck6conKGvnPHB5VYMmGuZAe6tMeCkRyv5hOqxwDbzHyWcd0/KTL
9aml4V14z8jBJbGPVCX5GDqPerOOHSbjRajD9RC0qO+jzXU68Jlb4RGRcZtcpmA/EHpa86+pel/7
WxKm5baYONkEe/+ZnHL/qpVjCRp1qKSIWZ0kE2eTUQqeBS0ykTcThVFOD7epwpLqV8WyGRSsIH5J
a9a6GNNj7Guu4yT+UUw9SINxWPXZ85Ro41I9AnTKE8+dtAvKRwV/htjdoWzFcLuy1TH7arLd8zK4
Gzzkw1vF34CT2mSa+WvohCQnQcrBwBWubCgjH4AWs18/f9BH/nFI4cba4R1Lov11UXvThemgjStf
asJEamaGYzv43HLfDEHeoGIAR+kkiltcW6Szrz5WS6KjVpSPrl3F9YvKg5n4xUTxuh/aSDJlpZf5
8WRulslAAyqgcNmMtYu0ll2iK7Msn7+JMZhJOiIfHNm4OgC9JZ2xTzYTiaCaM59Rdpufhmv/WXfq
EyR5SfCTK/3msOUuW/fFR5xv6xOpO1jQgzs2xdo7/E3DRoQ56+cNCueo+B6iWu1OsAXpywy8mL+p
ZzEznrXn23rC+Ko3epenXfnkJ7RSbeCSJH9CmShD8A++Vc1mPHGg04s5sM0jTmgaXCuQw5Kq+/wW
ko8McQSQ5hhyMNMp6q1gLZFufj4COrtzEjMfzC60zSOmUJD0fQgv9ylmpC8DbPn5IrYMlNdowPXn
3vTDQUt63j/f635EL3NdBAfsnB9qYGn2lbhnsC40ryZmm3WxZMntWxDivZ3H5ZC3qjj549yDvyP8
6+ooBmslT+NSrDdATzLOdjWOpzOsM5bFZwd8WcIZ3SidXofeKF9SCGxHlD8Iod38M/DLI3HRZeSq
LjhgFBFs8oCQcw2odEBvSlh/LvlQJ2YPjDzM3IIlD7DX/h2HxvNewdRrssfk5axEXafpVN9a06sg
E9DTtik08eZa4zgqwLQEhbtdmiejFks2CB/CLwkCvs7hg3Z0XEhdOFJ+Cwqp216mt3rBEENbpZKf
/ROkAfAfv0zywfM9sq5QG3a+Av52bx64bZPrGsVa+pFqVLcS9/WdczkBTlRldsL38EmWCo8xswsR
TsNbOnSx9s0FKbnlgfktjJk/VYil+LAe3oTvEcsLjlPwde9Pq9gBrMtALo2A9x+6keIbQwZCEgdx
9XVvxqtaOPEyRyXB3Jz9DZ1geQ+IYx/q4nxE0Z0z2DMTXUQbjeP7kC7w2BBJidgQIeDt1s8/RNQo
Cn1qoJSjGmkmJrgg7Snh8ZmtUPdM2JRtl7uxOtRlxiHjm4Yc0X9otcXBi7izsV0P1ZG15G+3j3r3
TOSq19QaQ1rHQdTdIkwU9o6dDbzsnaezroGJ9L6MnkjoEQc1+1neOFNoVJWYltD9cDs5MW4eOAed
h3btaMwLvKbCZnPN0lH/5AbJgGmzHnTium54QdAI9nNplU84kdT388I8r/mX3vj2yuZI3yk/zdi9
DDMin6nz+uyaCvo8JdPUXHEHrD9R+/50PwuoDbSWDwxzRdEOBAvfh3cpOUxU281OP0urVPp+Mnbq
Sz9ATdcs8ZRvA28ZBfFDaDoN/3s0ek+Kv0XUzFDuYvsCJ7E0pRQXRGbZgQ6deylH8UwlABKKMDOn
V74gCkc8KvG3Bkek5Ilp4zEvP9UGAQhHv0k5+HuHOIDCAU+QIXDvswSIlOfx8quLYchmDRHEfkJF
zjMdsuXo6JLDcrzB2S/WKBFML4Kz4QA3+07hKfYRjoJaJ6jeotakqPR6rLvcj2fb5d1jePZdrzgQ
HUawPYDcrKnETugn9g+k5+3wqEme3fE7EOV+BrhkNzOCQqzkLu19pRm4IhPZ6J4paHZPVFsTfk3X
SrIWWXf96Su3cM8SR2SrjCToyzLHxO++cEo/lyEQfztAsVN1m4XJsf/LfnE9JZxBmzna5egFNjUV
V1uNdr+VwwYsvvcGt+lzYzKvd15JVRjrJH38A9DZl6i57iAZFYp/oG+YuKBY7ztXNwF3Jb1fL5/e
5uQnHulvPLm+hUA3QxPYakpZqGz20gQcoRGQNz1H87YagiBZwfVe6Y2kP7lEzviKK0HzeJDcIQGz
8SscZz0PtpfBkM5BaUDJzk9yDzdca2P5vvE/KUmaBcMAK/UsrW4WYj8R/6dLKUNFpKemcz5DvmWi
+Ak7HlSWT1I22Jj/jVBuu9lDIgGpppDT7xPG/KT7DM+m50Jy63vMTKUF3M+13VHN4x72w6UGvVDM
Qy0PdjNH/Os4GilPs1Ecc/HIYIPu7iQDhO8zyDMfXLZZnm2iz0uidoD68PAee0YqZUQ2LuXMxEjS
0dnMChghhXU4X+CbLQreRDduuhO2d73TEtYPxBH5E5L6Fuv5vw6GJSlb7ZOHfp5uBslaniD4CUBT
9v9HORQzTT27sBavSp3n+zQAZRfH/nrUBhKj+FMzwiynkiZsvnwdnQLwcp0yDIfxTXP2a0MGdOwv
OH2Hc6+jBcR1L+raKDzzCuNn0ywnyxgV8DfogPOrbMde1qs8ZO7xMPhlBn1Te4ldiu2dtAf2dIQV
BZ2y8P5pPr2CUYbiGFYydIpIAoGTf8tx7abX7gueVdVVShGwLYxb9z9qsbrRWFLuDC+MU7mpBGBW
68mUGxGzEQuo4qddwS+1PJUrGq9Utw+8uQX3PMU4YF7dDor+Cbwsv0NagiW/cnsltKQr72dNA1hS
1p1fNeTy5X2B4l/v+V7bobUy9l2ClGkFSJDMPOZQyZ4x62uwGx497IMNL44AcFhZoRESurDt/VB+
HkjqYIE0oY0S13dl3B14a72fce3xGpzB3GWFUuqY7ujUJaT5qABD+fKH5FJ4OwMvXvstm8fvD7zA
DJVzuYUXxaWFi94wbQxpIM2Yk3eHeq+6+Abj5D9RkI061SIL+tKvBQjkY/Jya+hR6fEoeTLJHiEd
vIC1TXfzgy2cogMJ5OGR0pUVkoJLP/chLGn0esrMYGqijfZ1OZpnnc4gxbggSnlfzwRaHkZP7crZ
xYUycRF/JS3vcBpEg/7wCaIOnZhC0ycMwm15zheU9r6WqnGm+tUPW7gb6uxZXLIJI1vm6/0EbDyd
rp1hHku77I+7rYv3G6vUo+EzlQ+Hn78LgJXpTXhakvgVCkaQK8Tgs+hcfSbnPQKCL2n+ooisB4tM
vOYXYMC4LZOx3ikXiVVt0UIESL9H6JXRVSKa2REZd/2QhsPZ4Ij4onKkPoaDCchJRfKUMDNEqKJn
Pff9viGH5QCQltTOA3e6KAsKdjk8oZ+uXmiN+p2f04AzYXOaFy7jVxEuBYdc3RBV4LVPyteI0Yb9
GS1BUgz6ebTKnr9J32EyGhR9BfL3uGn+OXVaw8M17wll+e0MyJO6T5q7EHsGXGBRn/0Dyq3Faj1S
ZFW2l8QOnKFos8vwz+e3diBmL6DBwuOk6lv08ew4FEr6GjYtPjtP1Sd4z6gHH9DkUjxRpxjlOc7J
UvhXLfN0Umv7wTDIIR71+gcE8PdRi75Sw9M4aBooml7D7FuaJ3qsnSqaE1bQwJdEZ0lB8/NG2xzu
STzM3eBKzVIbnM1KbzR6ehil10tv3GG3tVSAK8HcFJVYxSPg3rVmpnM8OFH1MNbfhky9M239Ph2N
TOvltXnEwtRlADSZsQiNycGzZlgA8gIL5qsq5m0DyV05XkCP3hC800862llNrfoH97Y29BUpAs0V
txkIi4hPhW/x7A1zcr1oruVYWYDWi0cr+V/wbiQgfpC3fQMa8L5yq6LDs0twNau8A9b16G+TqlX+
ac+rqMor5w4h8Na1+E1s/UneRLBe30sP3ICnp7Bm1ve0oV9/pI3+a61OtW9IR2Z2EJeNWnvR5BLY
g6lGo4O6gR0X92Ppd0JkVeqwGaFk3rdbZKNLT4sYjobRDcNGOecSDthjU97ElBCO+bRCTKH3ErAA
nNDe8bacLAyJWXTelUlbmmNs6AU+TCh4q3jjcPl2RnNGCZIgQ5EMR44CdYoT+7EsUa4RgJLmdgwm
5q6uFpAey50NH+P5l87i3lVJAQPzlZPema4oeBSXKZkzaRCXfl4Je+wMV81TonQmNh9T4HjNu2wK
ZywJmCIrbaVnjQQUL/ul8099epZFJ6w1Eflqs3YkaGNT9Ylz9tFPYsLOcb57ruJ0zUOSnTkFLcHz
PVuCaodimCiQ7I/fnK/Tq0bYRD2/PX+qdlZI5vEkZ8gZxnGf4qY01KG8BoMnnXp6+MYyCwL+jtgE
YhPtth7nOXCA/ODKcj8ayB29K9u25anqDjhNAubw0kmWYdlsZKRQBEgryaNUoI+jCO4mFqj/RqxH
4zXX4LWAm+i2Xbq+6BiTGgzvc4MNFtW8gVOUW/m91/PjNkaekNLaWta5bo8E6hisuDIBmnP0RtqS
pFEw7z7qxL1hszn0klXK6QkqDx11Wuny6hLLfodDnxG2rWgKQ0k1F101JLPORmRpl4hRPJ3zy8k8
vjCS6AhPZI3tURfzkL55ZSYb7DmIgw0nuHPKvG1rzIthT6c9/4kyLGFut6IUiTjP6iPytYmaXcme
24R898cTmFKPRgvVVNFtjnbq0dK0QprJ4tIUAKAul91F6weNUdfY7rJ4rQ3S2CGO1S5y+FbMcoTX
Co1oSuZikEHEgLJ/Lw+f2G2h327b0i0VbWrs4+ozShTkSDQaTE5+jH19ISuw05s1AcoK/FsEk2Xv
56zIWtavMg6CG6MDMp+jDbmpp/dVeuC65ml1pcDlb1+jC7gJS3gxweKJtanvsB0IAoXhUbdPtakC
t+i9TVMn6OZdppQA3s7mLbjn+jth9Rduqf2GlnZJbxp+eq5BSB9jbF4ERdTRx8xOfjL9pBQOnryW
mCGRRylYRX1MD7vnjTyrANE/p9hiO5xDleCNogXd9+oBXyowXcFMwIthetLUbqrPoAJS5FADDgzi
Nk+LvQ7lHBTC2Fxs4wYXeXDaBKL0iJDWlQCG85aAyTFFd5spe6gbeFqe3Kr1pTF+TWTi2eMqEzE/
viTxiM78zYL4a4LrXFJn3jLOB23qUbEFUFYJTyVE/ELOfqSBiWdxL00Vk93egXKadvTjoUyWTP1/
VXBdUeMDD6iBzue4SBwbHi6jl8PqMmQ3cHHD7eLTJGh1ZoBeumQjBlDyzHNcfOaV027gNRA8+Kfe
oWMQNssaC/IJ4pFk2a+nq3cUZpilza6bbbKYY7Z79wvx0HmH/Os5lWXVzklqMC0Kr/qpjM8EVsR8
of4HdYx37XQ6clCvugDVUQLPmoYy0P2MlVJM/kZ84jwgRpsBzZL0mCsf6AqAsFs69GqjhM6f5z8M
yJhiEisUMhs2g6G0fxSZk8Ov6JNehpQKRgrBzlY8WIueyyJ8WbqoNCzlTNv2TLW4XC43gZvZ5+5r
DGdbYWnMBIvdclXEm/JCAt2/9MkiH+dCiVQLhSe8y3Jkzy9U4tfNuEfIdDny0n0QRPHaYahbnuKP
tMNEYFTa8/Obp9m57UXLmVmEBq5wh88AcAhWsfmn8NdywEiL6hKissdxCQXgX0ieGYrYVsul8Wnp
Y1GeyQn71MRWtpdr4vkDswPBAIQbRGKLwH5EE//UfWjAFYbDvLSbYuBgPS+Y4f73fCWXEseq5Epd
bP96VZcx7OHb1/x5VyOaWLf6yd6+ZARRM40ImkK8k9bYJ3RYUv9ZDlFrNjgki/weJEBslZq3XgxS
c78XfLPUdu5mrSduNTzvlyxqgGh86w+wmOPWy26L/z5s5A3UYeWUYSKxUdCoxDaZZutVWJGmHxay
uutpncIcQlkktaIaGmMwfaWMEFUW6y8oL47PX2+40ekBc0GdB4rRE3BejcciXeDBYSnTS2oHtAdj
Lgty8O3bT7yOtmzsYdrumzEbP5ISuaSj/l4Ozs/rlMZKL89F+4cHEAxXK6Bi/ylQcZWzAxUlQZVu
l232XizwqyLooHl88zHhc9+QCX4J6TBMjOEuFyeSf8sWC1VjI1gbmJ5g9xT9JlC32M/ubf1OACaz
W7+nlMZXLB9jKIuYbhgLnmXbxJ34Nlu3LsryjWHe2l9eA3+SyTuYbkDIlfdJfDABJEBJVPkmPFA2
tsi+PzlDRL8+3QUy+snGLcx2gQvPcAfS30u+xZUGsWRPc/b3vRFS0TKnhrM9KotrEzecVz+qBbMb
EPE4jeDfUdbQQ6iXsXhvXuDmOkmqpGffuo4mcgj8ktinlj+Sc8V5Hip3rIpYDm7qi8jJb7TOMJab
zSCAFBNxyJrAxgns0KqoaHZ8ANlEg5k9r+CV5Kh3SDSAwZWmUXI4JjLfKWi7+ywyKtUUzJVpp5Uy
vH3+Uo6GaejOcgV1/cvgTA/rjAJn2mgJ0fXP6XXFn/MpdznAFs5tBh9P0PxQAuRM918Fupadm9Th
8qPyjp7nGab8dsKleM/aRofSMZh79DiQRu7cVN+i2RhGm50HCQTs7PRvuj80SrGT4IFEKSpdgumu
ifmOk7P9Pl08w415FEZ/ioFK1MREvu+DaMSCCw3fUJorpsJDzwThhsGu4K03sA7v5A9wETkVqXog
gqee4R3x7iX5nMX/zcDne9PJRCjUUJUqy2epPAEip0TaOL/pms25utDUFA88jz/QWicSNDTi3oCD
8Wesrcxg++1/zE4EeHNEnk86TJJIQ9QKz+CPu5NyTnBKHTkP7T2IJ5IUHT2PKI5gK3Uh2jyFqSBX
859L6v+C9QKKXCV36Q4fCn129akENxoXRq/6CkBXFjGw4Yo2CYwD64LgOMx+JlEhWQWHVy8R0OPI
ZOM+Q53RHQiQLD1DVrrPIqVUQOC8Ji9oOImgpErMtwHXqnzAsPQAM47qjABbq7hJCPQs5RlYoqov
cGRkmrhaWvu7b2Ka3oZXl/J28bdDcJPW0w6mvKcy5LYTRybOlNPLliOjBg62GheFW+S+2/C9q5Zr
ZDmDt5+VnKnUVskUVL9ISxvFfmBRxOHfEZ5d0mGoZtrfbHUksqzusCCJiUbq1bx6PqK4om/mSbVb
i/e7b/HVX1kwdIpvnVJTTYlugrcMOP/hmjAZmlZ4va105Mai1SZ7tgr8xP5xru3SbtslTfRPjolL
PyHiH3ATkYrZT6mq/F921NeNbEMYpxLhY3PN1L4HtjFJPnBEKXz68G4CQofnUyHyWGZ6aTtM9Yw9
KdQI4l18iavhtlTksFheKS35Lk6MwH3icawQtZ+L23se3cOIETU/G/2CqndRaZaWR5Lu5NNadvdh
QmlVa1OnEX+lk6nfcaerO0K/JpCIP16XvoZ+HG5gJHShnqooLeCfj8AoDQIH+yCj3uRLp/M07Mwo
ZjyHfkfyrVPT2hNge4CSiHAw1Z1ROxUaIdWWqcLnjeURR+kK8I8gXAIpBgjJuWlQVWuL68hkXPGF
PT5hxB5Fb05oDDxcE2rbcugTrqKgZUa4RhNeZI+3v2bUGIoK1+oryEuey0nuT2htsbu8AHBYKFY9
vqCPttuGWYz66qkFqJOSpbYEo7b52sBAbht4nhduKnsMcuIiQ4Wi3gRtiD38N9X39Ye5Tw2ce7xN
z5Uw4+CxEnYr6FWaGRDgJynVn+bP1FPS+W+7KqNRamW95Hbz9Jo+c6qQrNmlDdeYppGLq8yU4w3M
FFaZudhHpRSIoOTO83Z0Vq79JAmE1mNT+4R3Dg3Z4MZJVHy44dBQG2f90yW/C/pTgI2GgsOpnXmQ
0ym2+6FRnW/zmFSF6m1UNFR4CbNZKJsZKLQaSU5yTKc54MlHbMH33U39EeGce9tjpYEpBKAb2AVu
+Zi+eFdqMpgQktDRFORSnNjErgHi/ArMmWTA3pQtMdsisgGkLdfj1gTFA4JvRFJCzPi2bY9Gn9UH
BvB5taOvxeKGSysExSvCH067EKNVijpW/DeIvCakZuPMUk/gv+hrWLRkIbdUNNy5YAfWNhDqp9sX
hHj3PuETca1LkLrnXMAKUXMABCa28rq3cIRHEAGU0AjqKFRGOWYzeEEC15+JUi5Yt1d+vmh0YB5L
o5d1UB1KuoVayC5a0dejNu0SN5pq5VdA+5C/X7ksn3yT+LhPTvKcjQJBvhGYzWbnfUheA6xTFg6E
KjXfV7CLC4inUuFtio/+ijNsgGl71yyB+MTbb35vhFXkDBKxjpYRVbOSXnx0b4L/QTgwPY6I6leL
xGas+UiokL+KGb7oaIRla1RBbemElu0daRxNU7TSTebiriMZmu2vaBiDODVchU82+FlHQiD0w/w2
jPIU5CM+SI5cIeupUQ1uvgR7hNJ7rqujgKZOZRBTmtgZFSE63PIoYPN9a1qsNo1ufxhbnXCa4WZ4
QORP5M22GalYi0qIq39mOOE7ZSiYJax1je7l87P3hEr5htxcQNvQeVG5RqEE609aFv4uAZ+wHk8f
jSrPoW+4qX3UGdLr3JC6kLIQxSpAJIYq0s0c6DnlXHNXVzcUT9SayykCyASMX9F0C6ymGPvd7vt7
PPRTN8qkbKySymPvTFnH1hOIguSSsZtRpWjAsr0urQa3sTsJSXSU6YyQ668LMqJUieDbVp9HfkEN
Rgx51iXL3LIHkCiMcj38SoNIfEUgQOSwq+yA+515v+Tziuvl+nW0Q/pSgoVsIyODrdb1IVt8I7Od
+XbhmOeeCHK9l42OFlW2AH8zV576GYZKyYG8ANS4A7oyaoMHjBL8z8JWSd5Zy73aXmsRgni8+D+Q
p6auVQypukUdnC9phsc3NHZCCqu3lZ3dLtjs0XTWng/jMZQPT1wxlUi3fvwWic9ZixBabJ4FBeOp
R3uiLi6TJ0wAndxDEnWsaxkPU5vewowKnGah1tFZdlqQG63/epMHHZpuCCWhfCYhlfnWTScNS3Dx
jYA7lrCNwWmUZXVfywPNnbxyI2IGis5s+R2kO7Ir9DZc0dUdOWs3iDOp2qfSndpk1WoDIAHuiw1i
W2o6/gOUxQ2itxmSiCha0FpJJ9hIp5aeZqFgceUjBY647GRH/EpD21OW167Vnqw7tMMaLi/K2ywi
wF8tS6LBskGh+PvWUu1X6LH4sRZG1wU1uTpDRMHnKF+7mSCmiF1zNkAUZ4I71AxVhv+sdTohtM3F
F8yLkPm9pMRbAZH+0rlyxsR5pT2w9tiJK132uCCtlL2B6Atri/n/Ti/huFpeEuLOxuEee+/MjceB
MGgjuIE9MhASa0aa/puG6XPNBoL7KMENk0tMpyeyu52b20M2POr3W+WfeVraqkaARwem3mAxDm6v
1CP6UKRn7IxEpQVlC9zbAR97O5P0oEpHYHv8HPlhUGF3iMoHOpw/ElQQPGGgtFeuVVJLyJONnp/o
xUlg6E6sCMgtnledj+g5WevZ1KzkvClwKscRfyglJM/88wSeXM/or2SzubBsaSPMxjfW+SbS4NZ9
XOW8TzyGpr8YwSNwDUr1yL2MGYggrBOCl6K7PdoeMVfOS8a2b+oJvRPdZwRPDLD0yYvN1SgWeOtK
zZfDW8SEq+r68X8JYGBvF9J+v8rs07vyO5uDZjxqCvAu/8+zKyPfbIm2tU4jc1HJa5wSX1DWbP4C
9SvEPd1ujqmCZX7KEcqmhZJqZEB9n7Pw2cffFqpy+/w77LYr/OgmmaqFkE4uOr5oufxkcCTBfgJ+
sLB/1fAnu6C5pFOs6yPdXq4sHY4lFgeyijlqSv5SdpYQCnsoNFxRFYk9OOJYHTy6Jm2zHO/ogwDv
mxB8o76apFSQQdecNITeaYX58faQGOB80cTIqVgoluoAsxgE0y6tWoGcx6IW6GV+7bMx4SC4eNsu
b7Y8ghxrdF5WX/2QHXsX7f1Vp3GEkNMy3DGKDE58CxGcVPOWUwERVJuHyHgn+6YGjdtmv2vgarpu
6i5Xt1ErArH8ejWka+D2qsOzN3GR94lzGQNjzOIKhoGQ3bb3T+5/UVIrbB0/SlcyHO8HVwC3wlbB
uZCpyQS7PbWx4hJrohhg4KhqeRcbq5yBtZH/AobjeA65FTA7SAlVpF5QwmvsdTEv/AL9xfB2oXX7
rwUS3d11iTXYZU3s0qXnMQemxgSQpq3/BkQmkWYvZdRJ7cbbMQDFHDaC+X9gpxng1sUbf8oYx9Ss
d0TPKGRqCQQT7Bphz1/uRQtNt5fHz1HhP5WXBY9NbtstBgKc1qnVOUrCJRXYGzwvvsjDPWKR6PJF
s47xQb2r8uzvUlFvReWevR8HQOawFD4VqfIq0p/Ow1Ne/Wp8z4vkabDaljxgR+C1aKDnH6/kwizo
P5DILMBh+vbGukk5nO17sOaogUaGdK4yezIkwgAZfrTAYDiMzF5fs+rkRhZD/uyYMMYP2TR/v5MG
Bks3tF6zw3ewTldjkCPJKO2o9jHngOWRTxuU63V7HnyI1g6v6Wlbl+3C4kDl1gMkO/zo4Hi6ZDhO
CE50oLrJe9NSWkU8/5z10RpqZNeiIQTZnEQX6RMr/ptV5CQXCaZxLQtRtM65WAl7h8GoAASw2QtO
RF14kWNSHpevmYtLXFWiiby+yg+NTzi+2SQSpgENWX+YYBnvygnCskPyjC3muLrqbHEs+VCaUX2z
zDf9Bx4fZ1+5oR9Oui96Xb44QmNpjjBvey9dNZct824d9jrbDzoZqR+Rm5Kd/AcFJrInu4cRi5w3
4pFH2n4MUjdB8audOUuB8m9J0u/7y6vJJ8oantjvBzI/kcp7OuYrK1JSsA4EvrSBwqrXldyWxFgI
jqh/P2rMq0ZJnstT7PjgpT5l8y4e7yK2G7O4k7KDko3BH8i3fJeqdvWC6/VvG4lcEh62FoS/tXI2
bFLCsv6DMODPn4Kgzh3sx4OXTOiQqk+stmxefKq4FHi1rHly2WvabZ+4rE0A9ne1pDk8foZaezjP
Hlb2pkx/hftSz8N7TEgAcKmblx8rsKPhEJMN8SNIdbKe+Si3AznX2cpoW3RI624OuQAKaQorESdo
gO6LTfMuzIP5YAIUt5UY+WMLka3jN34ZoqAJFXnmUBO4TFafwTBBowGG9kibgYL9de18ibir5G5O
dGD/Akz+emBjOM161auPylOlbqZ/RUVOEcBS5E5WsdDoZ465UUJUnMViKjFRETAK++XhsC5bMvlz
lYZ7blyjTRCFESR6RrpA4xvNqNLTTg7rjkHb52928gk7ovk/5ihNgmsQfQYkWNOvbPW9zgxiiWLM
Twt/j2ouHwfDqmTDh4z1mxxCE0SCgAGDpuEHDzdOMGZYCTlZ6aKnfOqmk0QBKTIRkeOzkGjDZQIa
YothI4JzNQP/OpRMB9jL/JkNuUxPR8lABhxl8hMNLND6E+VsCanDrws/pj6G5kIicvxBQEycPPuv
7Gi4VJlimVwBoXJMSW14tKPFw7gIgPlUK9t0VuL44vta01pcjipFRQMiGwjIeTTTdhd/HuE6JO0Z
JKmc2n8U3IAPdJl9rupO5VP9YswlYXVOj/ercokT+aLjB/pZFoOdJBa169cdPF/P36PAKSaQZZTw
dH3k1AvUjg/JhkxUNV/xk2/vXzgto85BSZXYEcyueo0AbpOMHo+A6pbE4j3x4lmtCC9A++6rqvxk
y8G/+72hTwN2zWxbTtsZwiMhe5gVq5nzci6Yv5Qp0cq0UpD7mgQQKXwdUYrDlXF23yioMmYues7Q
7Rd18EllMY9DSoS8zJ1CMGLpX+2d36d7EWNrKP2kGS6CCkzmm0xwd/DQJnEzvpMSRPbYUbuPg4nc
zp8vewNVQbARB32lOb9ApkM/6YAAvZKgQIMVxvMYug+YnEcCnv0pBgBzn24uA1I4QJ+BeiReR3cr
1tzGE2p4YYvDyPPfoKxW58KDxAj7OInGHRj0VY2+djuoFZ5l7ujR9cT0W5JwRmkcAPo+JYUQd96c
WbNfKW/l/5EIgs0LN5IX3IMBK/S70ZcNo8Ru8RoDAcQKeCaUiK4+f582z0sqUVK4wJaxnJKwyH4k
yYLzPGij0trTSELCYkUJIEHrAaiYuyPlKCf0ncWsokXoqnxvYBmBTh6/pd6HHWzhjS3iA3vM+Yk0
GmkJCHnXTKcuzS9o39vJQW02ocbtzkkAmBQe0MOi3DSldq/5G2lusPTL3LQNioefAJN5+NC7eaf8
xa5W5f/YicSXvJeKG2RCnG3emfVzxI8pyrbL6kgHDIsrcFthpwSF6vs0iemwyrxutUCUFyM+IhJw
ihxAcCTK6DVH+l2g/20AhStU5FjlcfvVeyp8JgH12Jvp0acCgekWRX9JC1JK39McqF+C0i3xhL8R
yDbfY9GfFIJAS07c4X+/iH1pxpKZZc5MIBy01uyDRDwGu3i2PFdZ9JXQxj9wFBUUDJeFJZdT72hG
bea2u94crrNAKJaqMnMd1tqNb3unsm7m+2i4jVRZrj8JOwwRnI0NhUCZAfrHe26oyoQbbNvZ8Jj/
Pq9llysDKiF37LdeyzV9szg5hrWmEhfTAIqP/KX6Apyzo+VJOt4xI63LwamJ/bFeJZEfXrLC5YxI
GIGcx8F24tSq7dZGtDgGZzVH3xQps3ED57pU+4mvDm547VU9wpXSmpI/Ux41O60x5gtblgMK51Zz
L17hFkup3ifSa+7Y3XCzeuUniZwG14fHkprY29O7+l6aPy7xPbu7ECiinObOr7iZNr9KJirndk0q
hkF3+p8cQX0Hw1pOBuweHPEuxcKoy9HyLdlfh0Bmu8m4vyjBN3gDbrOYAyY5uqJ0tiHt2HbIQ5Ru
b5e9AKDhDTGqgK2WaeaZGULlWWDeQEF5OdrfqoYZf1sV3GRQQN9/giPvC4S7NGQVclgvalZqljtz
htCYND/WyNQare3IaS/tl0zGTMdLo7zkKXk7o3qloJloAqXoZvZ7V8663wN894EeGL8eoRIY0tCg
qeBraOSSix8KV1dW/hmF1ntTR1fAII9hQRSs6c4lKAq4kyr8FFyTPFDtn5udW3ElrGaIfuujUf8G
D7QLEazFaR75ReWypkaxgbxKhYZM79S0vJFM75LoltPUnOqpturQP8ieFFWanvieQSU0b1dJ5ezi
ufP6w7NtpIrTddYZtdlbOj6qzxvem1A45yuDhJntkCtiY8X8St9bc6cX53ox66vvF8HkAsizXDsp
m6nPn5LZxN+aYeEXn4Cv4nFp//VFrwWxqoznsFO0q6766GlDQzKoJx1cc/8oONVi4UCLaqbs2ODS
ntIMRMUPIK1pWb1/CXep2ma5hBw4EmHO9DDG8t/Dio7RVEf+HC3MoNV0LWzco9B6vDElA6Oi+ZDu
o20YU8ioM9yAd+KqB0QPSjg5lvPHAnrhAUeiIXp0aUXQcSBkA5dcQX5ABToS54fF2QLyOSN0c66h
vrsdxdQQo8W+g2ylAsYOa1sirn2wJlLkGNh9MaFuejXkSh73Ny3FQj6nrTXxKKwPIJfqaRR9DMp9
etLUg1gfZ4okY9Nt/xVdOUguQI15rDFlEW1F6F0yBAxHmLqv1iAuum2srHxLO/BTXYtjp0viXBno
kbdD8CcUxY73tVplO0z6vnjYmh/vjylw3tHpzkzlKg5b3DSIkQjl7bAk6e+SgASJ01YJctNJjxTu
bPlzL3VsnZScMQ9kbvsY4KMHKXoEV8GYwXThlKF2WvUjIbwwBkZlulzC+ZjIzOR9myszqKP5GT5R
xXd/HBYmE5tSRCrJMOFAIsE2HnctsLH1svOJKAt7sfEdqMz3frRIC/0+E3vnN09hQ3SFj05DiZPf
qE5yDXi8uG7mR1Hn9MIpVVymGaCvsy4W1je91OwLsQrVfQh9Nw45cqdIWhRDsrVPyk9q+lFB+xCI
+vmEGEKZ+DHEneeLEB9k+vXapEPQ5AYhAfDbLvzVfYuBGNC/uzcKpKIshj073Uh0mfMNoQlv3hRh
8X5KLahoxr0kWPUifYrlmfZFjEr3N6HYGYJOT3koGb9SLypZQglgvGNAoqwiyL0Z+emeOqVK4HhL
MUZNjYb1VrcmiFnDFmgemzQDTamWdKsZ9I1b4mTfu7TrjBw+MZ4lzPkH6tbQtWdcFec/Spi9023S
brmhQ8k10Xp12Z8NAcxUuWpyA7HXDFKG2N5mRiRp/o4o0x2+02P5UyP3WX1sFcmylfgSvMojH6S0
Gb/FO5dIVpFIC1RBkBVdjogKeh9AAjYypwDjBwh7zQyLSzMnNrv9livTjckG2rM01rjTKJYysl9j
vHj6LrhCNHkLG1fs4cqGWRWR4sqskLN8vR/JtI5X+G6pM4aeUJrX9e94Zn7/kbGfBX9m9iO6cptn
8C25PVq6stveiwHyQzcpU5S2kvCLIcdpkis8agl4MT7sRgWDgeLkPLaWO7fq7XnB1CvcectT7wEs
DmqmMFFDW5C4xNYCM48x0c9PBvM9KQBhytCVPUafftniylDhKBQSywgQyXcLu2Lb8wxV82Jo/oTp
9OFl9urh5qo2OttT4n8PHhHVbSiTUsiQsl0Uhjgtm4zYWqQ3frINmZ8MP7ITMisRlX5J+UjqfvpT
gmVuWr5+gWBsDv9K2E49XPMLq10iy6z9L6iEnXtgmzmOQ7h4eLaVNYo9MCeVMWt2gUbFYZAsjg48
VrRFRLyGFTZRmu1LgSYu+ic47zpFvXjlF8dQ7WkgxDBv183HLyC6e3o0jf4wQRoGJuBy4OAxG0lJ
DzQ3voM04Sji6xPnwSCfq5yRkup2+SBybkFuhSedysplxqCevWnyE0QXsY1nHC/hUvETRvhYvche
u+tRLV3GlmSQQvTbYqg3o/xIslv8lV35l464SN587jPHZuwTaNsSf8m/pcVwf8vQ9Nq2R5agegt2
OxbCDT0ZwfjvO2gcTKuq4mq2Gzg0Df/uzkOMArUOBmbGWaF+VmDdekPrNUEMU/QAmdlQYNsx5W4e
Re9ekWNdoPvzDT3hgoeYZiOKKjEtx+ZErRFR/khVMlqWUEqe2eChMrl1kJedK5qeGm/3p7Jl4geD
48Lmf4NqOc3/2q9KG0L6XNq1mqCO6swn87BP71FD7R/YAgEYxgYTT/iHahR3QmUJiuD2dbj3wBqy
2njgSxvBU1f3xFksJst8zXARWhaeZN5RQXNJ0Q03NfxLjYWA++fwM9nA4/ZrVQRYXFvPFQrq5cNH
a5f+QGS9QfbBfnOQtObv2COKH265byEBkJqRrdYeq3XtvB956HX+tdD06bhQys/vOduhCJ6JsdEP
gVemrVX7PLjxvOBb8+Pr8DunQN/Xlp28Y3rMaPPIzRQGhxpcx3c1gKF1JDR8zGzo4Jw3bbd3OA6m
t7cJQxYhttdfGF0BQ96+W7th9Oq4KhaDKiruio9HTALJVz+89UIGKFUciLNaSQh2xgxQ+DipR9bN
Kx8MHCEs+Rvt3t97m2v5mG0uRmDpA8mk72WvBKEKhCQC92p7r0MrvEaK+3HpBmZzhX9lq51hWtB7
CGoI9RQP1ql7CAg3F2+Nba2lAgnRq4zrGuJ0RVsE+mfNJ6W+DJPBxrZLDPOInZSQpYLCRglzMAHf
/l3HROfOVEPZJF9KPpqcKVcjJ605y41zRHdaSuFIaLwFl93zKjW62kOyr460a4Btm+OXFhu/wULY
0Tu3SjM1VPP0bPEJ2Uzpyfg3OiqgR801pdnMkzBe6OFVfAOXTRtzdzIP/MkTQU5LGuxex+tj8h6Q
v4+RSUKejineYVvScX61LdNEebypiiWAnc9zNHrWXLhNm+SIrZBcA2IDD4zY0vUI+gcf98kyJH+h
doKL+2ThePPPUmg2awWJDztDCbk2em0+E2PGCfvt/Ss4f5za+tCUNRp/jOyrcMz1Q+WdZ/5uy23q
sxhbFnqfdn2p4sfCQY4uXtlT5oTI9OKYyO6aPpEn41/9zUnYVvl5TNzwBB5KDnNt5Mjg6Ejk/Usk
69u3PodEXV66OuymCLJglO6OKLwFm/S9NaVbP5B+87h8TqY1FAAcwXG1k1xasefbnJ4X2/V6LmOn
gN8RnLHGkSJXXiJVY/dy9Hrr0HbBiYH2zeEoCL06WUnnomZX0EP1bJzUhCXWdrEqaAylnpYMQ2D1
SGZAq/sxAhy0FUWW6Vba4v0JbcQM27t8PaR7X2iDctMajgu3FeNbu3lRhbioFrS//YnpnClDhSp9
HC3qRVr+4v1mrnJlasedP5V0dFqOIxYZPeOiVwOLTkv3QAa7Dp1bvBFf8/91En4voYfjbnod6/Y0
lBgIC2XudMYMuORXmt2hMfsR56CPSXTlu9PJRJsX+nuAg5vsm9HCdgf2YudMRxbi4K4ROShTjSZ+
NlsCOZT9KH1ak82RPp+h/cLIFrF1zI+2wxXG9Y2Jf8ijO4n/yilUxnW10RC/WkanUoBP2wEB5tNK
0p/BYFfe9i738j5826dw97s4Hp51XuyMm01gQ8PbDidk2kq0lW0Tjb+ThxpqeY35a0XeQ2uCG8zF
EeDsAqpNSQJBzqEatbF29M7uAnJAo7R7hvmNzSi6iPJwCMk2M3JPOd2YOi06Y2iG7ByVGEVTF6fR
+dM7lhMJTrXHt9xQ9C5OE6K+Ol3PfYNylJj3rX0MBMQCeUH6Ds9n9aYRSy0jn20gSZ5DwKIgMXuA
Q084Z3VDW6KkErsmOqejLh0sqmJukfimLGa9nazwebvyeNS4l6CLMMucsKg0lCPSkQhvgTV6tcKO
kTSarr/TnuyjM245jAz+M6oyTIjlGgWqTXIHue8PEdXp+JxsmXIvW2m9bKVcL8BVCkooY/UMAjm7
qK0CgGJxR0zso+i7atLctNLMusNvEKnwnJep6ne7kRNkVSeudISkZxFbEr5qA+R579ue1kQDBc0J
AgG/8BN+mBWKqv9mgKth5UwffU0wIzEv0PduQpQoM0RkLtFXH6N7GuwxE0dI0z0jSg44hgpVPb4V
/ruWpA5QNfudDYEMh0We7Sa1Ue5vtp9UOaDefHQ8KPnaRNC7Gdy6EY+fYoYqxCT4wtU/LrKHmBF2
CqaS2LqVDBP0bxXe13E0BleeLZn+qiF4upoy1QQugFfNpHsyE9IMMlwhXAmZU1Yq21VrBdP6/216
3JgN8ShmEQ88UNJ0dBfrbXh7aJ0PH3g9J9Dmy9MhFUrq1E99HhROBCTz3FdlGKw1GpQ9ny5+M5W7
3kR7HM3ogAYCejicAw8J0xDCTEcEcw7ZX5KuQRJpHwtXuZlzgY29uWjeDW/opfqA64fWaTJS/pZV
hX0xpOseWggRvU4huLIxKpl5S800e5KVdpChZu00YdDW7lY0R/LtZ6SghZY9URh9htnFIkhnQknJ
uu2Wg0gZyq8JEobI9Ck961vHDSrPbHRnsbkK7NEYaUmlr9n/Es//0IbCcpCEFQcppVbuVc4i6v/I
C3zFg4zidiDZkpbWFaVSV00y52PgiryB3idSq3yNE93k9fGQXUrUo7u6luptLhsE6cZ9Uc0IC7b8
XvKIwwrNfAHYrKCXbhL3NTK0dXXk2uE+r6p3++MjyWH1lIRWVQTOAkgr2Y/Qyk3wln7Jd6izuYrs
cr5e36Pa1C5n7PTER3vFW7ysOm+lvRF4lbADo51O4gEtAL6OfN7upVxlPSc8oPa0WHpioRbjKZIi
/yWlmemxV9223ltIFWEXyriMf2/4xAWW4e9Uj9JaJknYA+igflm83uR5xLtsKuqUNVhm6uQk+qh/
AiyYVs7/f6DehqBRZSX7Z5aAILy20+0OufNEa1IuTcBTkehdiPLn/+vx04Z4PTxFPUs2R8uSAOlM
a0WDipLnLo9/Z0kCxq9BtaW8cSjv14nwyqH/Yt26lHLz7he5N2aPy46/RfRd4Qj2M25lVFfiFw2D
twUwZ7rul9dFup80iTMEJ5yziJt9Dxa5BaFk1SG2stLbgeDoWxY+iMDBuG8AgcOk05E2zkRTF/QK
Is2FDXMdIS+ep1+IZHSNvm6yAQP2t8VWXAHOgpgP+q0VwOHI1W8O/KHjONGR1cFXIkHvUsPZGt99
dQZzXo80aEncAPnfyujt7QbAWLYF1YcaknQkAWtULe0+5feiY8JWhJiX8IhZAEotMzj4L/aH1MQ2
pwJwdQZn1lhJIXuJvpxPHLJvAXSjPst5XSLoPB7duta6uNgpyR+XwBwxjhynucuH+fgPW8eHKHop
0rJ88Gf/556ksLbhPZ6Iv4D/j8UiSWQZUvFyulZKaK8/UG9Cg+bCr0nQ0/x4GzEOrvFVW5hVe3hJ
cwx8ucil1FccQNtpwdq15MRuqmB88NLj24rCiPTC/20ibqVd6whL9R001BVEbB+VPQcxfTjgqXSj
ELghL5BIUYqaxa2eqRMfVUwth7bO3+hGlESEwAwzo579bKXKAVAhqOIxYm2fuFROeAt3S4QONjsF
YvcmyWlPTpATs5IVV1lG3oMTKg1ndMjZgBNSWXKmg5bPqeMR2imJRcjLqOo0F4TdvfZdTF52DiaU
w8QE9NRrByQP5sgbP92lQEspExkNm/EB3UDFRdg0LVirwNehsfIcQH+AhwdJYEZsurJLaf2eLDGI
SoO+SKAT0fqXuFFTkuzRI/X7yDic30060JKufZOdBkOF2XlniGPA0v4fRhJvyNN126n0kUsMBb1T
PSeCyzt3w0DZ1yPY5MuCMZEiBWgOG3yf39NIVfJtgo3VCTn5Oy2Z/IS8H4WFKzSdTWKwCO1iinSt
/yWozIicSvLCuRh1UgpJD2Rdnsf/VZsqbvA1kRoJmH2tRx8uBlT/oM7+ye6PacNt4CVM+6X6Vhmb
8spB+LvI0VFlqQsIEdv1X84PpUWkJhTU1T3vg247ijwrsfr6PMD/Vq81DAsvpTurbD1LbEIR3oic
VrOokbm2cVbr8kzAOz2RL0VvyhxKrU9AuTFg+VGfvFUPxEFDFKCqxK9sfLGX5Vvt+9n95KMI85M5
NjMYwqQRgvMfgDEvGV4fRJoxhPDObwnmiitSY24v6ARPzfn8DB5ZlHUQ5o/ZJxHbIGZqfvk9CiX6
NpgtaEmt9pdlefh31vLNEg3doSZ5uWBlPipjQCl3UfclqsWxkVYsgt89vzvLwK7Avx8HdboBw0y3
wk32bJ8AOhtL8TEHpXsp2ZAu9oSH2RavpR+t4MIMimjr+2u6y4nd7guug+exR3bt6ltktL44MS0L
WcFFYzPHChXEyjBgjl8MB8kF0LyVjTEbmau8m7C/rwMi1KLt8AhpxOv1N8RNzVIr+Vb2x3RsEhJY
Th+I7lFhLIteDSxM6vDrx9hzRWC6IocALTF63HckUA6N7NGJSVSksnIhUE55kOjvHyCeEj20DytZ
nrtsHtlHhpv5vikdZBsgKb293VXWEDFFvhHVbTKZbVesBpEoNgl7TvJv8r+f0JcFu7b1XI6IIMT5
BGA1Fo1R7EG0l/2H1qw4SdoKYfncFpsIYJOVg33rO3BiSyRmqSrnZSmoCZAyhCrEo7XsnmTvkDJ/
0CQdE8eP+8sLvlpFMlbQu+0+wR+VXdpCMdJ7fWzUfea0950kvFiapVHBiu+gEsC3nwpSLozYtDdh
rYhU3Haa6/uUbqlPaV1VHuDidxxn+d1JS7Ku1Uci5p/J4rtZgeflIPH17ugG+o+X6aSpSLnrbdp2
zIaA5MJwx110XcKZ4q9gJRq5mbByBqtx3j+G2XnvpIfcAHnSO8DJ4Z0e/a0UqpZHNyO5gyXx79/8
fLnAGKllTXHNV5lf2MJeakDkejnV0ZtU9KekbOOozxl7K5hz7uX2upoLjCRSvRHoYiLzqveQ70kJ
375b9V+M0OTI3D0aUXFbbjKR3WXGG2+1oO/IAMNGT4wc+umSxkQlfeHSdn1ijKnO3nynFKCPM+Oo
uBuiY6+W7CDzOIVdUi/N6ZBrxOGIxcpQqQ8l99RP0ljQvYemFh6aT8gGmukP1hyHf8SXUqzHk/Hn
gx6dn3NDI9FLhslkJ1Ksazhy6Hplhvy9Ez9KPDJRhqB99r+97gt/FGHga1j5jqBOi0fF0fDO90qg
p2WgpG1ns/pl9OZko7OHL5VHrggE8o+Veb4nFwQuA/vDoobn3IcN6LoyoKWIrbbNpWSK85LuC4qT
5alBHcemH12Z1WzwNQ/JwuZ3bL8R1iXEOxuwgMwjLgqvyeOiNTHtKsI8xyAQkk0C0bVfseVtEXJj
r88kw/9eqKHLUMOVSfYfzyehXKMzVP/m+/PGbC5pS1gTUr3WHPH6BC2rq6GAqdwH16q14StIyARr
Z9loU6XK5lq/UMvG033f2V3p/R1NsfYf27Y/7YUWi0SpCXDqnR5+pPIfdu8pz8UPnaerydKuezne
yziEzjQWMCGsr9yzSV3XWgdeazBF92vkmKnCQFQjPTN41p99NBPYh4BT303yGxJFR5Px5S1YY6Zy
BrAa+CaHwvSuEytGlZe0YeDXUneITvUmBWGkJ3qTU8wkS8VeKLcF0N1plob3cf1JMLJya0aGDQxf
hs648K8w9o8Gai/TOXOpoKFm2YddsqzG5efP2nLzQmZ16/YQ4wavHlz0pQtTHsb1a/87gdIx1dBg
CPItlSCFuXzW64X+fcGmXHyet1pyIFQpGEK1AWRHmnmK5hGcr7je6t0BSu7bSQpZcbjLEEwpx1UO
oqEkdukFmkmwVhrakJcUWA1rj57Wu/8UXf8wdO0faCQ3mqs4viddqIDx4Tf7zo5uEvXW8uuPahzE
Y1YdcCZ4pD5fqdFNUukjDz/cGtzxANllcDRslWaPJehaao/9w3CN2GwFbFNV8PryP8o50TOr8a8S
rhmUpUd20SjlqL/kAgAIIZdFdzDgEda/iPENlk+L/+ZEjNZhIlzCtpypVpQ7o00zxOhmRB4wz4Sq
Phrvbu5i/wiWSR+dgKWvUF7IXVy2WXSdYn+zB8aOLK052C7esET47vhnhJpgPPq618btO52q0Ytr
6fFmOm7l7bEcKCUZmJK8q+uAXFY7E8Knxw4dmKx8wvZt14t58dTCxGkfsmoDJhzATBMaxY0UxIKs
XrxO4DNZzW5C3eXqOQ8gIzeYjMJAFxvUoltodO6It1pv3d6gJIxnDEiLYaZZsm/W4uKNnaDwhP9s
LUK35uj7xM/i1h+yACEu6whAfs6/JGUZANLXwoO39gsi2RB3dYJ+DrJZAGst8n6qBdV/drDCi5zx
94RAwENm22lQSpVPHB7LjDP27gnXKcTH903a+BPXFmm3y26NekZ9u7Z6NrBCRwc1L3eND25kH3O2
ID2SyYxreYlYKQNN5YEGz76tRleDhHeKDzUnfpiK+cKlGYY8i2/dooZaGcVFuzirHQsXQ4Pr0gyv
B+5pu4EyLZDDNNMxr1Zr3M/tpKGc63Ksg6lH3IUZqTIuU0mkFFV3oV+yxiisQfRN3h1L7iG8TMg/
LqXqw9OQv2DZo0jG57IVQw5gxCffPGJEGXZ5skYR6NlI+3EWtFgDJwvRnnHMloJ+8BnrbSFjpXyV
sTFgvExIZ02KPj+FTUZ793lt1VE+NIou/U5WrMog4Ki53qIfXS2T+rNmwsAbuuU/nIXDasi/G19m
ofWQksQ851ziM99qPRszYW1R0M2GNY6vpLfT7bSmP4xDC/NVvCuHEvsvGKOda7ERzuotFXPjrPPA
b1T7fD6+L/NdEcg0FFfZ6L7pUMfcuy//MxRac94+1aIuyo9K9gbEEQdn0td0tn1yD7sGCu5RyVQd
maqlPq8wdva1Kp8Zj/CzWQVLW9DSEshrzM0pGjj6BmoB5Yw4u+EJwQiYpDdGboUhy5tKFkGKe3HP
Mjs9hA4EdlNDZrlDoNeJCNdnjRE0aRc1A4WGQXnclrXRyL+CXUgeS0mobIzfICMH5kc1LcRrxjqp
K2exLd1jGt0RQGQtB8Ynhh9lwqsvxh7CTaVakeeB2XPFbqopN6DcNo6BMaBgDuzUGPwpHSEqke2H
OV3eV39bJyOdADHVcCpexf4XR+Uq4dS2d07vO420yb/23MWqu9675mOpAvoSUZ2muRaGALAAE4+R
RwF0T4h8Bn5WVKAZzcYffJRroxDcoA5UUKwjNlrxCcTdV6DPCZUoJnznO9ouLf63ulZ8b2qS3Eqj
ghuc26yJF/1fhk8Z/CLqnnKQWrd1G4O53dW4wYeDaIwEIUDbtMJw14/cZ7nY+7xsTS6rz54G28vt
cSQcH10orfU9UY0NxFACIfcJvhSj3ybC8hXsBd9dTIo0ziL/gP41fp8fmxhGrJyIczhSJr8JC6Jq
pY9nQ2Tj+MCS29Vj5LHa1IqJ+i39KSFOalRwI1NU7jeRHIswdm72DpmRaPW/Li9OwBnVcWE3jZAc
CYU97ZBGA2mDe5Mn6MQefUEJH31bEkAJqysPWKcrBXkvNMdtBYVNt1KkFf5TFO2nnuk1JRJxYolL
63SohOcChleGjGXWSyinhzRbp+BmS/xVICgbRjmRzHhPaS4vYhKJ9/FxRdTRWek808vVLd0JV7Tf
SIxT2XCpIRlUYB3ELC0KSefLAINB4/lbNmIu+nAF2YJutbBCobLTm4gg749l5ukwI09Klg0hClJU
7S+SxxvBUpVagrmm47O7AFRjNeIl6XI5YklZ7QTx3v0NIQGjS2VeH/DBuqQPbHsxElBrXdmALenw
8VJpaKo1hezUAz/aSW/Kd1A30mDwFnJXKSQPyjWzIXqyUqTK/dlf6NsQCktiDfU3RN5x7FkMP/nx
3HeGoUM3F48Y3WGUPfRgZtnJeNRDbM9pC2/PWNHz4j2lhPEASLXiLvVA+WfO4kbjMUW34+JfBKUx
7fbOfDzh59Fsub9gYP102vKXjXfz+VCQek/qEVYdSv2O4L5t7hDR1KcEbHHb7lbOaabblkYlYKKQ
AlgRfYutpJBU+kDWshDYPki5A4mTpol0V0dmFuy/nA5c/IYjqCCrHBEBRYG555DLzeMEmmLfRHER
dJVIIUdIQpbkh9Jrz2BJ98+XobOJCO186MDTgROknJjUD/9k3sDfCkPnFuc+lA2qhuBQ+vXJ0hot
5vMx/quZ78pK2XNOlaPUSA0zUC+aiYnmQWMYcXn9ZoIQeKubDh+MK+Shi/q6c+MAIV5dOp3oiae1
JVH2xgaqVFe4m04JsgJeQZ1KQ/LgWuUWOXpd130gb41puoEK5Dwnd5UVOcTZay+Nq5WCpe19qvSA
3n+VtnmDCLw+TJTXYD6YYDCkcBaJ7NjUreiFxZq1qNqJNsPJGIV2gNYL29SIz3MaCWdmPVya5R1W
2qI+m0tkOrHxSPuIsj27Q9gtiDiyFxIubfXXhksNwy/1EYvdF6g/qiKWzl5v26XAUIBPNruBMdpO
o+qC19YNErvT4nb/IAS3VYyn6J4lTSdXSkJyBZpfrz1ru5wB2i1WHFSQf1OQIRpx0wF8WWLFjGwl
spZz/ySMqUBEtC3+U9sS3lku13gXg6+NpA3mwW+RCaCIoQ9IcTUSpf9WKvNnTb5k8yGPMwzEeaWp
xgqUGF+AZdvaZPc30aGCbEoOWep43SSFeHUFERgiFEE9Yki4cim4+mG9jwTb6Ng0QQvYIzeiWBeh
mTmzToG7183/1MUy5JhpPFFsc9EoViN6n4mabhepOv3wmkXTEn/m0Bx0u9stKtXV1uSdWM7/Fp2j
mD/Yg0QgeaNe3qN4MdGX+KyC6Od/C7yWgOu64UeHeaKctZhbufCX6QA/J7QsfSVsGj2RJa19pV0c
lnf0vpnAsvKjdVo63YwpbogLSRmaes+Z+6oP7/s3Q5n3UcRierhfH9L4O1PmnGraAChZ6BgV0G6e
/pTmkzegSuldLp8Yrf1+x4dH8S9mCEh9SmHY6msicdZWd2sTog8EzrzBj1sbs2dt0OOcyX7Gq15g
VyIVEheQNBon4bPUqFID1Ee/svUytcewo19Rz1MrY43CQVr4jSlYMNIr/LrMKWBehdokV1xXdwhm
p/lrp258yCmHdYocIYyvaOIrS6UtQthFqYKERruAprs/wM5exlL1iYeqLMugk4FRKavb2mt1H8P4
CS0yvpIwgNOd9aX/VcGV8Rejo6jJHktveUgNc4mk/1SgUrFDf/ih1v+dZI4Xhm0Ig6zLyYJtAZPi
Q2hDlfugR6tw2tIbRu4ZbtBs6WY6y+kyv6D6Al2ZUwHmzAWLmP4RtA50djmpk3MQDcJKhsRV7uWi
UNfKEKrnKGYZvrj36mK0v5q/c/REDfT53utdZGwd0N8EcQFxdM6HRwlCplnsIShhb1TvoUuYLDmw
WOd6zTZemGJ5SzQbabT6qSvswQkFQEa6v9OzeKJqyMwEalVa3/ZII0eV5+/rskVM1KMpmtjbZDfW
TcLIhAhN4rmm/OxzgU4GLlmsbF63IsZ480hklz3yRDu2nAv332Fi/T/sBRe5MENPYLVXboImF0Pi
PbdViqfk0VTGnihS8qj1OZBECa52NSx/88j/Znv83EYIOUCjipJVrbEOBXKA4tQgza0htCcDyDhv
hRr1C/kYfqEaZotPANC+z0rfuGrsEkMmCIl1eEKRttzZ18weQ0hr1JjVg/WXFBmMgetRw+e1yr6O
lbRtdmZbcnxvfJG8eeidd8DHETaZNi30Oh6DJBl1U5KDKsfOpfJHJEFYa9jLXp47FIrBvp1H9Mjv
MmBA6gdBnloOpRi7UVZQJq7cOczGhSQL/7+55kp8WlpoKR43K3sXHLtJ2HHzk42KukW33g+9go5G
5KHegXNLeOugH2UDsuU4lPv1gAm+urBeAbEqUrPcOcm9qTdx6SGyH96Qv6HJE1CBqw9hqEAhvF4P
HjJDV5gXaQa/naDI8RhmBkWEmC1pggdrYXkxVlHWjtc4mfqPjR6fzm1viuaT0/UFKzTNYGwOcy6f
lIHzs7yhIAmaUahJzK0Cd758lN8xttjoY3IfObKcj+8j62NGWv5dfvxtuk0whc6HgkpPQ1DBoem4
oXsS6pmVHj5FK6sbz2SwiztBMwDADtjRc3wuUFK8dngbDlGf8ZtfMZT0/i16x9CQfAjOTBQEUZJ2
f1aF8Yh2HTM3Dqv+C6sPOt3epAl8oE+5VStNPU7M5bmzpK4OKZHtNWOTmJD3ZFeO8A3eshp91oZj
1R/90CuInFHbxbAPIX87Wd89wC5ygWO/p07sg/ski3Ws6r4oURgsL1P7TuNbYcwReOMMn0WRIIoJ
kJACJQ0ybPTBJ1ftFoVrA0ORYGRmxfY5ZM0ii5YPXtV9hQHAO1s8TrKLSOCWJnXo/sR3mXwnTuPo
ParoI+lWPNIdZNLMwpm//EkVVfcTs2vZTppAPHks8ogqIe2DT073M50u9gh3emvxkGSyqaSt9eUH
pEcit/MxWQkotvMuHnejT4vDqZUAex6ajVD4AAguk+WHTwOtIENqwHr6ygave4NhFD7pH8JtYiMo
4t9VTUjLMTgvMHostAE/S9TS+eVQGGdztkKQ7GbzwN6z0kr00yq8TxRYzxjwnuXTVWoQ8G1PWHd4
uvzB/0c1X5QLxQjnQZ46hU4fTMhPLTTUUaM+C/us+HSt//yJVNhlRsa1EX0mcIHeeX3rLdTCXJBy
R4UqmCSLpyOgBptRHMPvxNyTcOF+o2HanYAnIYgnJRM57e4uaOBR1XcwNh2PHV92AwcjJ+J+9+wj
ZI2ojxVaqvM+jRy9R2hEixI9IcK8tbar5Oe5jJ7i4AKuow42MfyAzBKrUisLAPH1afRxVXiKsyax
/v36vJToCKJ+25+NSBZccKQgTawtyXHp8Q3uSpTiZ8O4Fq5Plz5bVthGqm4a+dhtpx2eQ3NvQiSW
rTnDEuKDm8HLp/dGd3AjBKU/DDwGNFUmrziGBWO8Suh2Vhcu4nwoMP4tght8Q0nq560JaVP036xJ
nrwC91u9Ozkstq0gcjDxSOz6HlVNRwvt1AcSAW/PUHHmbEmevw3P/vyHLU/5Ao+sQdzMSY65RZlB
QF1cvtwsjT4ejfEKqEMrFckDHErmeSHDcsRGbKMCM0d01X0i/H6Z3pLo1Fs8yWmkFPAnqp71yiID
heDamjW4dKRNPyNJEXCo56kOeYpW0FPkRsirhdG9jiqCRquWgwosB2uG+RZHQ8usTYug40Y5g8pS
dcmZajW/CorOp+xAo/GBGOJKe6vtHrLl0TiaVFQPeHjik7UzMvcDjDQXXnA28VdIAlwypRH31ZzF
BdvnKBKzsohdummkj5Y6mDHYzU25ymCapX8tUadQZQtj00UU8FuY+MaGj2mjpzHDgLy/12H88vml
eOryrULN7LLuGGj2NBI3ffRAmiSZ9CLjr1QO3a7S3k4vj1HwMq5cgSrm1Jn+RKwq36LKTCVzs6vH
YUsVFAsLwgWhCV9QYIWOlgILHeJ9LoOavy+3MEX3r4MF23Ud2Z7x2tcsltjRh7npjnHTtMZTrsET
YcUBUsjgEX6H/4M9dZ3Rir0k/PdGtGUmFhcafKcGDyT2GmiGwoOFFQu51r6L2rBFL2ajCI39OPvz
bFyEGkN6NkWAmaIRQis4W7igjG6quVpjHcQZvknYVvIZe8vSx3To78RFkMYVFhdDgpi4fQ2y4i8P
gj0PI8N8fZWdDJ19Fi7npZ74Lr7aiE74flKxan9dntaOxD956A6rK680CzjqodETlD/bwca8zZHt
yrS/iuM8KmEI+6cueUipWUJ51MUwYIfEjTzjsX2AAmy51LHqXgaPyV1zUK4A6FR3XDrgrpL5W8qE
Sg6KGvr+oCbPlyokUFXxNaTao1jtKjfsAaTg67sqGuQIE0HsmKgIywrgkQax52/x2RK4fh6VB502
FT8cEulM1vDDKuVGOef+Y1N9FRXFwwmw7JGmK7oyBWBw39SDdeXklTJXwGIZss6dlv51qPSbvKjB
ft9xZ1q86eZQscdGXPMiXWxB+h7khG5DmqIbw1Dz+PqOL24aBP0iPX7t7z9VsmvirRzuyH79LpKz
yF5LvEDVfn++W7oCSL+JEc6bZZyNO0u/yUvvZkU3tRLoKfnfbdTkx8pA1EUB8gScPnjziblcK6i3
qO2BXlYNzbbZ3yoj2dlbvhHHIElknKxAizh/yh/OqVyIVj3N8RG7abO+a3AENaFZGzzq/BXuv/CG
f8GoLIOaqBNEWvz+o+N48WvyO2pRsbS8D5pTPLcXFdty0tcEPtqWgaBx9T0+DhJafaM0tDC1c1IY
ZK9ApDEQCzlsv8ObnpJWXb0yLO8U/i9CPhXrQDa+ZlvZWGoCovimqk4gZ/RINFIjeZSXIklq9SOX
ugrWQ7yixX5nBGk/BkVZtKwPFaJ7viFjsZ9Pc1pTaaX8eSGCvBr4/+2vnb6C9xq9e1eaLy4j4FBM
NnercA3mcqd0lUqpVBe7S29yr5CF+pFK+Wgv2feuF5zJocqvakSdCaVoIAHNwmukpKs1bdYF5RuQ
exklIm7oj2YIBssdevvpmOWSZxXFFsInZQ8b8awT9imqY7Z9TMEq5ckUzRj+k9tk9BlHaOO94pEf
WySqE7EBl9/nlmfuLw59ghtsvO7msPZ9pngOeNWkemX7Mzr4Bki5e7/MHK6uz/jxJmA5ZFrVA5D/
sPswDUNWchO8cWu7otmPCancJtXJV/PWoscTAxkHt7lTJLznOjra9H5diO19fzfCxh2qlleZRd0V
BrWWCnTONxTj3hYPm3yMLn7QAZ8ljcl4IqB1VtepQfRgs5E4V1SabxEAZ1mNKlw0Gl3lekgyFjcc
QnXb/1q8KOBJhg+vS7x1fmHQIM5O7zIQVLe/9UOUnhGLZnNLbv3Qh4isxVRWs+W6MsMUrHSJH/w/
Qq4jBRf135n3oxJS4PPOj8WtXyo1Exya+Lq8VJm2igtPtgyt+hWadiU9NBYejr9Xe2edNI3s4GKY
I6hIrpLPCR4Utr1IUszu41TSoYR7BqeZ9UbbfgdI/X7TR8MRxsJN1xi29+yNbc53ljn1WnUVUR2t
VWRssaD3ICC4ieEySfoWnDJ9u8vkFDYuJJ5mEhv1e1D3DPD8jRm7U5UWBOHYjFWRlagazDLmNSwu
7DkfvPlB2Cn227xe54WdKFntFYO5TpM5jaYGoGM3tQVmILKiHpOVnpYtO3933FXUIyVFIsacLpgi
TLYfqw3mxdhA2jg2t1mKe1f+h3rkAnkEJQS5QsrT1fvimYLuZi928dvRSg8wZjJVD8cL2TCAmAC7
X0f7GXhqxnDeZO57GD/V5WEFSlfZx/klEIxJjc1sNECVaYquSiOPciI3HgiP+exNeS+2+PUYnpur
zgZKRm0WN3e6SuszobdJ2JWyPS/r/aUqt2nCZYsAKRHC4dkvKZ24quJs7QKr2UP28p8PwOqL8s6B
JSgzQhzasFpIdIb/vuR3yK9Q/P351wguzMVeXXvccUJfqjEnh/8g00t/ZMsF7fFb/UjCCHvdg2WA
bDfOHevyy5XobEmfOfdOb7JzVH9St8on/KMrDOS2a7pg0iVxrjEph4RfaxbMMtWhOAh5SQKVnw1Y
tPcRT2C8xnJ4VhnOyOTfFZiIRwiI3OvV5YdFb9E3RqNCWTHLkxkyqg54H0WB71Fb3dSbjrVR6D9h
Z7Pu9dZi4hKAeMwp2WBCWM/iJIMq2m+2tHAspOZ71aLKpJeii0eAC8HEnhTfXhtWNxO7+wvd31ga
z5WpLGLSZJ9wT8oe5oB/ep9Xmb24xlWpsVJnpxLZ3MmKR3m+rClAdL0nCRezhunXYJ9/0bn3wYgz
izr9GAekchXRJey9hLm9LZhMR4S9MJruKZWd/qZy2TVrZxbqdTUuzQEUKMGB4HSQKJ4ADO3fyHUG
fuEQAhwra16p3GyFvkU9CukpJJnQa9UxF6fDoDSXMuUOkJVNR18tkbISb2Mj/JQ40HvzQGAAB5ZP
xsnwrCVOu4DilwiKmk57SahXpsNo60muSPGNfWQmXo5Y+qiDxB4+i2+118vngjWfHBulO3m5Cy6w
47hG2LzO/583owlbOmEUoYDGwWeh+KoiqO7A/J+9uUWY2ZNA2wpLFa6a44I5s5PdvHpAcefihTr1
ZGikx6Z/hUrOdEfbnJEs48mOHVigyqfuioZOTmbc8BIqSQcnB6btc30KEMN8y5N4XtxH0a71Tv+N
LO+Z2xFswyNjyBCdeq4QhxFciTcc2f7wmKMBEPpHoFAFEpAySDqKeWqwf4Nnfl0BbyU7zkwK1wlV
Mty/IYvexHFeDzBTSk+Xy149IF3SheefGpsYtYw76Yhzm8VA4W5rA8TkgQaUxbdZ6N0F2o4H2JGX
OuG1RwXI470h7wfyTwm+HUSPscSl1yn21FCTjRr0u1F8qHfxglOd9sll+6lPzYO7XoXCfIiYb/Ln
0hJKpxM9YlKHYit4ulwScDh+L8K5pZtsBmnboefmeIbLuocnm0L2QV8vye+nksGegMqrg6wN7RmC
aF2FHx4L8GxqVI5e9TanEc6xwUJYATC2D1RqeDnod9B4l3yb9uW+q1fWBf9SonRTqac71MmAsjcA
ylGdm2qrJzKdf89A9k2kfSCzI01PM4U7MpBq2Nb1IICDSyKaudD9ya+mmUqU/eXlJghGcyB0IvJK
ANo9TJDCDuEyUxZ8RRyeGY0ixG1HOj0ESMjU0+zZEelqaenFqDG+b9TLjeTJwQhmLackEibBMe6K
vYkvidLdBaMX+YQGKdsgL7nCOJnQuwEwaRijL1GC5/erCgs/36Tw20ikSrAt/RB8wRSuA9XRUX4C
8tDRHv435WMrk9Zv92oFxZLYFm00wq8hV0RdmwyFjwYwALM0hy8/EICu14j/V4jC10rYu3nA9ih+
nRaZQcKywIp2jTeJN9bWVgFOcLbhFeclf0p4o4NdOQxMhRGKhdY5KF6GL2SvFt18ZoGJVjDK0gnu
H8OIOFp546F+Ea9kVF17uz/aO1KxS7d2h5hf3SITI01fqHBJlTduyOOlQqsOsWu0aB9EPzUpjamn
zAAU2AnULKQs8Q/OIvHtPxJ0qnuFSNF2nAY1IZDVwS2CYVED9uBIqyFVXisT3RZI2RPzg9rEwVJ6
PXKYlwi/RS93W3WHQzPG4KW/dUWUoQtWHvKORRojeUTkRrdMe1uMSsLUtns7OA/ym4KiLufOkUbC
ev4uA4Fgndl/YcMfmDvCvrdmBVWND5FTO7ta8YRSz+RborS1Ia5E0o7faZ6ROYQgFFKZEuFXLDkf
Od6q5g5toNz2SySeIG0kg9eP3Jozp1/blrX/jILF8JxzwWypZ5ehjyCUYDQPpP1eWV9wVBxANEQ4
LF1YZcxODwGyuSYdErEOESLYSQ8rSs/wTVum1j4V3CUo/Te91/1fi20+7b4RB+B23N82rspK92/L
73WNgAr/zKxPJ8mI174EwAaBXfkK9C/cSA8qAdi19JvjMVCEq2J6/tN3/SfDfi7yHEcivL4YviKa
kK43tT4OTXxajTSR7zanzT2Z8VUZ0ulabLL8COEDlfMIdA65dM5vxH2fkVhIKyt9atuw49yIeCkZ
q6RdqJ/xOLtJXhB8Cbxqla4Ck0rh0pLsrKMOCM6t4K2BzPpoEqp+83fIQmhLxUMpt1x4pPdEFlum
TjOFLUQBmzXokRPnMBInKg7R4j2Iv4J33rhY5DCanG2RyPR4j9TESyS7cRJxWLcRI/vcgyytUeDK
lMIcbf47TfAEqkq8VAnSH7S23LjJQmqDaWu4GItclzl3z/FY1qBb0M1GaU763jCr7maswfFthMAi
GKCC/v33iHg7291DmZVGOykRu6sbJl3Chwsab2UuZebELupx0bNSvvmoygCUdCSiaHWqBICBabkW
VBWxg8yGpZwztDquYF+/yZ+BijsS0hLHPj+wsNq5evcziEMBhKTpePTs7NrGvYCTAICwUv2ymaPT
l80flLjHAzQdB7OULfvRauLsnQxnyEzPwtZUckchKb9gogoo2ZbW1GlBYrLmcLVuMIQqRb+6cBUQ
l/FkENpNWgfPRzg+i3LUfOR7ewD3l0crMMWpHbhZs3pUtDlWVCCpk0M0h6mnorwK8BjELy15hAfw
ed9YTJB7EbdI1aR4ogy3FswxmrgaGYfZVe3w3NFhmVsPS9sSFUaFvs6ce41aHK4sHQUrMT05kvJA
4HtjXWJtNtAE5nKq5HSsLQnQflAI9bNeJL4QqkgsLNrQbwiZJ/Ty9FfFYj/E+7k/4dBjJkZQOgV7
vMCkZTJ1R7aUSe0WB+Zt8/9U3RDfNszm45yJBsQFVWvjeLIXn/hLaA6C8Mkf8PMn7Bt452p81/Rp
EmIGvsBMLfdLZQ37w9/ulvdfC4g2/o5jIsMSMY5EDWZMVPYhm+tlkG/TV2Q+66SH+DDKLqkPPc63
ha2Tg0QeLJZOrA+9Qc1RO67fEyOYYw0nULw27IjMTXyahRWuhMKZfanh3S9HWQzUrEDNOv8vDsan
EM0Z+Pc00xZ+rV788gH9Zx2POhZDTXKh34hoQXksHz709JPEvXyjceFXAYPUuldhDC2B2ONF/S2L
6MN8A2tE+eAgeUv/PR7eQNnMZ7ocT2tyqzUYSapTFguGRYcqXH8CHdYJPmZUiGHm9UeyRpB9jDKN
QUNN4jJKhYrp7Oo+VoQ4cw0uyz9e87+lHVUML4Kzdp42ZcGrdvPDSGQrq2nmnwViolrloJdsbBeA
YlsdYLhi+nKlUZsMkhuI88yB/t1EZOSaGlx0OzA9iXvSolT6d3F5mjjXVdADOaOTRdYUNo+Kxy3h
T3p1veItXMm1SOmhbTcemGDZ3RQqLzns7JMG/FawGgvpXCOpP18YMFKyylMhD8gon9ovzWCTRCsh
awC7yOv6Ldbw/8Go9XXnJcof/CydycCY3IULK9YfF1eCw+28w9QSc61P1zGSWCwcE4MN1gaWafeZ
xDWAwY0oVEzgnY8Du6rSltIpOObYfW2YXGTZZ+Xhes9iLc52SD4kGoY1zuXNKOR1v1sA/TPYdIvb
7wL+taXVNuz7Z4IlTdln+7Ozau0/yXRsBpEb7Gn9ydoVyIuC4/Q/tLED9vazrc/yNaHDnZ3nANAj
HsUlFuA8CcOSbj/xZ1EHGZeiLpLNsRWPR09amipZ83ZMCKoW7ELPZfnHSJY4v1m7qztNWIZRAgPJ
Cod8pXEszYbfsPGuod1a87gouixORjEn1vhrONCSl/p2/WpnOt7NzMnCVggFhoq+pJnVX4w0Z80l
3CvIbtLbw1UkMILPWgKUn1Y0tGzQkHaam+zUn172sFW2Av6WZWyFO9FGQfzn4Fr3JDHFRbxVzdM3
S7pQ5IdL2+M5cFOpdei4g5t5Wtr+I14stEsPJ/uohQmlTj/pUkoOVnmKbTaCBjXX5hw2FIjqeUnD
qt/6ogfDP/2kulcwMovojH8+7X15T8ZjvrP8xYbRIcFk27ZAgyx+pHyqr6k8ypBwhZQkKo2vaTQF
DmbHmUWV5XrOXSaIun2/UiDt+L4FWmmlsaeWuR1xsoUIALUCAxKK8uyKpVbyxaGgaaM43cx0nb/m
rdfuXd9hFxfHv9N+a6iGj43RtEkHNSM0pafBi2F8zxtFClNncYhFnSnhAgYQnfATvGE6LwRRGlKN
orsN75RA0S8hGpUY+cNKXmtdcZyBTFig8ePFuH/RKkoXrJh3Yw75HVufLQ87emaDf3hMFJ7H9vKt
YVe7zvOBUtABOPrb5tyJc3exVhtAXhajWdEnW3R2g9leFs8Ac4oDbUY4/IXUYSNdkB9xzpZIRIrz
sPI1DNroF6Qfuv/JHxmoNdRjrffvhPe2kzohjD4qsyHKOoKF6ILnnXZWDu4bdGMTNVhY+8sg9mvx
QUVrZ0uw3VPX9TUHP540oZ+c35iNAoe71laVc1CKB8zBiMvsbEHMix0bosZ7aK9m87HHKpx/TOKU
TrTBpZyS803Mv8nQ2IhLLRJJw76xSuHI2aj1Zaw/IvF/S6RATZZMoYSHzDnmy45ffu+s11cS/Snu
II5gLKr/zuiV+O5HQ197TnKMNtAXy5/CYrWdIEiyKabAUQvZdbnJeOoT5Mv/xtKamzI2/WXBTbnJ
U/e3PhzONajcaLEJ1QU+E2dsoZbOhQvOCRlDK5K0RHobexqpktif5+nGkuLRhtRfeMUf5T87NkKu
OYJp9y6Nr7ehbebtWNxJ17opdP7LJmMnJyoq/NVxATDLk5YfJUpd7YvKubxvcfmP/IBg3bOJQOaW
F+7Zgi/eAGSQzwIi0h2zQD3r4H47NBJWX29f8M0RNRPdPGx5Eys3WmQDOAjysqAGt/fgsSaLksxQ
ZKQaylW+457/x27IXgmP5/of8RIYLFjPjM1Yok+Q5t+i8SHJaLJ5uh9Lj5A/WGIMI1wpsul1qow6
gAni28VWf5X8Cn7R9otTqfMmhZ2OrR3Ap3t5o5B8FErkiAng0n99W3csoZEQLHPIsVK7M2l1N4lk
t3sVGwJ2Z8DikMvinKHt1PXh4/RiPOjcWgUDqDaz023rSM3SzyS02EmCv/mJf1uFYQ2xbDruZxDD
gSUYIFy1A0OWhzI/iiLVrH1CbgSsiApbxNN3SoOF0kbbSD7baO6EKI1dh8K8R8aNNj7gpSWinsoz
46/MhSqHA6VYtLAuZkECK8ZfMgitDEEv5ydC3u7mR0lE1LtbU5D9gnZ9PwIVWJAb2+pcISgBXcLM
nj8Si9siVdumgF2/l0LszggfDiTlgjnJoeQbyEKhur0nB4LSv0DhSpnAI1oesw4r943yfwBusdjZ
v9RErAZMqRxUGfO1224PvGHQhDQY0w8CVqj8oT4yRDbUv5f7KK+KC5ZAlfDbtSWJ437KGoFGOSSI
ucDq6r8+NcF9OX3BFBamO+kxyELlxqc6Z+QJSi/Ze5xwSKFXqbBHsrXgCpXl+Etko8/HrS3mETEH
1X1iL/KQZQotGQKhMiqZLT8/yDUPHfb2hgKJGUKuanUkbsmIRL/QJDYbznjXCj0f+pbrFuQGhseo
t/Y+xX/BSGiJV+wDGJw8qbfMJGZTnkdU7AWsEevpi3wWkwUaBSWaOJBBqQPUbhUgh3HszEnst/oX
TYVaYQBDor32GPN5xIh8For0lxI4Gh/bpvn/SWqzz7V1yADRXCDyq7QUXvugNldGgEmKAEg08DNc
sBulb79JcroEa6Nk/WEUOaxvI5LKWtAVu1tXgEQub+kh5UobHoPssBN8qvWOwpT0CJsj26Dmt9Oz
CbQNScG6IcglgDjHC7jzFDIMjYGAJ/P6/D05SqwC8CRlmtyEzCMaDGa4SqLjj8cMrVNRv1KSWmDC
opZ+ShzO0sGRdTMIwuL4SqjfDSrq9Shd2pDNUzkoY6XXJ+bQu0tMcuz2pADaC9IXdCodEFKNZneK
X4aEZdB8UuRxOhCnrTuVO+oGHoB6x2biid7tYQiopfHTtxKw2GnitwpctYh2f+1SiZw/t+6NFGTP
X98vBWWqM/7cqKfE88wP6pLYBQyTvvs2dzXRqAXfIrFtho1JBb7hpawyCt4o5Uke6e2GxWpwqzvs
9Xij58LWDtaoX/8H8+na4kdm0pxmZPuQBKPI8iJYyWgDiClZZBYU9puUqN4CdlLU0bjvJihPWI94
GS5LRtaaaP/zjUzwBv+o2Z7ReguNvd3ZQ7+jddNSvsBriGKT7uqvvQ82fuFg5lb2v+q76aSvowU5
WFjNosmUqh/Oz+b82GlNbdww0zi9vJK+OEdYVxhm5Rgxgp2rCxzJqBDx0dQs0aNlgvHMevFdpx18
0q0oKQ9I9oAapmTjhbsKxHlO+xVJ6Fr+qdo8e+y3XP36+vKRVeSDUO9T3ubVBwuMC8Kc697kT2GA
U0Y4nVsLJAZjU6bUR+YH6NmhGix02fHr+pzehtoJc/0KZHNpkxpI8tFSa4NxMcRJPGshuGXFJs85
M//doATimpXgKEtBQHPdZEUBWDtIuHS6uMSDyKg9fFScQBCKi189Za5N3PtxmJf6nslvncIFjCDQ
xpbHJPdEgBqL84Vxa6Nm7bxL+nZtOkjawqY0sfu9aCgTBo//bHDbnaoe5gydWzxXnei8cepJLkrb
yNQL0AItd+bCGKeCRAwCKzqqVvOfTZTNr40gTeGkNEnqLFeO8h/ySWLaex6ihC8sVmDUYuf7QHSP
9MZX+zDxvhKxJPrNc16ENdtqK8UngKq1zpeT7edRNErk4aG/i7DpNQeGVTSeKMLPuDmELsfWRMSv
Pm+QxwXLZSZ88FzRqU+GrC2SAaYLPCBoxuIVEUGCM4Wov6kR/ZLc6Gs3xgQSwH2j0l+D1zdtjw54
Irk4RTRUAORYEwIHg1mK0tyEqzKVERF+vpoDx2yDJAIQ2GYIOpuOA/34h4rWrXFfV/etDc5U6y/U
elr5EiXO4T304Lvc0XSs9BXGnISAw8Eef4oC2pnD9BJxXDhxKs4z6YwA8O2qyBUVaxdaJt8WurFW
4921XDlFfpINJLgB3mxgLuNd4nl+UAf09hrxuFX7mu0/QM4gaT6H0okIB3bML1v5PN5aCkPOvpk/
PTBmbSiJ9ma68+j8Q++aAmn7eynC1vWhAhduWrBJmFGX79iUPZPRTF5e5fjS185YfizjhMulXi6/
8x7OdBrXDepFKgRMf0rjo23yXjbM+RWtr0Adt9YpV+OdV602Dur969FJYZ5zIiU23E65ZCeM6k0/
IrRbb6xWuD4aC51+Jrj3O67YRdAvZMTbC76JX7hXRMcWG1T6umF/3TK1Q+AwDyGG2kQQ4VAt0xui
5FrEcJIyIgh3AFlB8wXWXAWdowzKKfWY1ndWo0FYtRJRu+4UrB9VqHRztqX4ney1NYE3mO7lFr5F
jwLMEv+a5JDGS1guMjstPkr+xD0mzpqSK07Bb4oDE8X8LtjznRWr9dJDMNwiVZBzZJzzi/VeuXPB
D3PFn7O0DdlniBlqaw6krLCIzrWygm8C2ymNdEGc/CDWY4E5BCjGv6zMEnmD6+Fq/xp8Hw55ztkg
OH241QhzKeOKdrZk6CeFbPpVL7vwkA8oSe3+4zE3FobdaWRNMBhLs6YpWmU9e6uO06N3BW8gadyY
XFKqPMxjOSopaJ8332cARjU42kw+T8ROWUiB7oS3CO6o5Sl0Ua5bt1o1YkT0irHza9hY1GdRR0iJ
aAcPcjmTQd+onYtfMAxX85YHsAo+7tajaQURM7b5zYh+XzSfs15bYR3IcPfwHqDzCPHTvaHAT2RS
26Mo0BTnDOPqV66Ca33EYkNcDYsEDAijY+EpQa41U08tuQgj9nINXNuSaHJiNq3XXzoNA6srvBMn
qQzBOZj0pFXg+PU8rkArMlF1YFl/mGv2KlZbhMD/Ga8bb5dPuopwV7rnqouBgFUDc1bfjAuDypUi
FX5/4VIMLTYZEr64RnuOzuQhBXdoh2EIXsWcYZen6YV3uTxLdAW46BA7ElPdEIiz6ObgmS51yf4D
6zJ0ucvd4117wnIRJ2yzImA6e8KELsWTz3wSaHfP5TI/xVpaZdcnlmIZ3Qn3LhZTgKBxvKjJrwDD
t7bfpvepxZqi1bPxv4fKS8VDKvvkPaXlgc7wFVF5YV72APUnGQ1f4QJRZIqnkjTnfBpuH6q5qclP
NrmfM3QyrQpCysqOWBJqGtejeBE/z/wM9SRUXyxbdfY3jbsQqrCollnHixoa7pXwWYXwNFBcQw3F
f9Gh9f5lkcLg7lfu5LDVWHAGQiR7uWJhgTUw0HF9gCvXfdluvXG1ziCIDt/x0NAEGHQ5NOeirWyF
wS1TXKiPm42CU3kt4GEJuiCG0xppb9HL7Un+ctFGyamkJOLGWS4PJAYkWZec31oKfSvR3fty4I+4
VWpCkI+h+EV+wNoSpSWU2cvK1AVIEBC8Kfb6SZKHAcYhFRxAFEFax7XJEf8z3FNqm1ynWSU5rLDG
5UKxpow6lulU6h9svL0s1Fqyx8YVOMTXprdrYSuKSa044ZLrCZkoBx4WaGP7f1MZV8qq37dxvcSZ
dkd7GmsEMCOxaYZ9lJPAw4IxrooOmIzpNy0yiOHVIu5zz+mPgET5qOYlJwCZxvYpebSGOeRQeDvp
g8w+YkImYrS+/vgazgL5XfmeRl6fW/wdZxo08uTZ3sDOhOwL7a/3+LGwos/+KME1xN/zzAW0YJXX
X8ojlMv2IJXUDTuU2Bo0FwVmNetkbBdYt7xfCihOazV0KHKkgz3JoIJmq90TZrgsFysGRHbNgwai
s6a5rz3nI04LRwZCMLh90jCf94ApK9uySH2oaEqTr7114ltCeBj5CmhZAIRN4Sbtfcu/OQOhOQ7W
fgTJN2a6nmH0RyjRZigbw2871gxW1na0QF/0rsykcIIw4ir3gOCmr2Lmqq6S/yRLkYYO0ee0RvyH
6sHOuM0SoFQ3OuTIEKnaJK80LpXZfGhZ7/UApo6Yi/QP0VQ3tonn+Mr73GwWnDOCvhhQA4mvhumQ
cW4X0MulAy57uS/hnduX/cSrN9b28bvoHLHaoxSAiv3waHjcv7HpbYhYnl/uWh+pgkI++Au+WQpV
DJCsq7IolpCzaUbOjIJFJ2Yo1NzaOrkNORdbycti/XKlJ7qsmxtlkPy1f0qWT7EibKfOiDMPjMKt
VbaspklC/5zuW30wfF0kCtPWbPOMT7UOavh9yxwiUyQPuw820JeLgO4wyAMT4TQuAX84k6oRJoHI
tn3CFpENTOitb76RsGoMs47jHIzGpWsan7trHNFdIR0mYkkzuTTb7nHNQgKfk7prn63OnBVWyr+t
fFhr+k0AcwHW7AV+pwEtSvlzHZqNdB+5BZHyK5JC9GKgk7VKUBJ5i2MzQF9qAEP8tgUPao9+83N9
FwN0+KTEpj/2ZNz95/K0ggJC/096nQk/dbYAJW19O2uIwFkHfHRdCvTzZf6Iw7X14u3xj2iQcqmd
bJshvI0FBB7GCer4HmmOzZBe+0jdew9Mve+XBHWQtNg7yXFQwQ/W2i2aTWXb3/KaHOIqaJypVma0
c4DfnNHm56oW7j04CB6jYOti6RXwo0KSDzvqUVI6gmV2Ww2T8eE+6tPTujiB2z7VhsF9sT9tDqVs
2ZTVweuLHgpD8aBjsGNEMuApd5RtXwPD4rbk1d5AuWhASvN4Mrz7daVX/rdJCb0FflfnAw+VC4LW
7kjMk36wNnCZsIgdYO4PkMRAFGeDMDPuKLX61uPXPH+BEbuNKH+IKEmgQD+mmVJiHbT4TdcM6A7p
8OXWy6IbS/XSNLnZ/pqZDJ2p8IB2vPY7F7RXPerPt1H+R6PqxLBLcPx+/fGN/Vr+wdMP17PU58/Y
mFVq5H4qA0aK33jLFp4kneJOPVrfPhTUrgSIj9TsTjuJYPo/VR0TO2bNxHyGXOvGjh0LYp9hp6Lb
oDiAGsMabWNctdYBH7oYRrFJKjmKUXPRIN/LPe+dMfGY8dftbqTKhfARUWSbxSCjRSjxE5wOQmEa
ISAURR0ruhMN4KKL2WSWb/SMriRfl1Htwy1R6cT/4qCPVFlmycA2M+2Ez0HD4psyq83tYFJ2/uh/
LDXE9ldR4T5xL3pyInkchxbYHhxOuKwah6RVd8/dL8zMuq4UBPhwZs5+sTDR5ntmsUqhcaJzCmfP
ijjwMjPtPXk32YdbDJyuIfqgBIuvc8ue84AC4xdlTU20vetuVhIV2a8Te+CgaJo9aSmG4AUd+tah
uJgyM04TJZLiJ9lR7x8fLJWZO5BdRM2oI4CzuwA/OXyKAWejM7ly9U07PcyybBy9assHTSbLQjz+
3zBNzZmQt81b1yWQqDKndDarUbx3iADPX4fBuBNNmzgdD5poIGQ/sBdDzwtoL4bt4+FNwlKxUUmI
7MkeV1dYHcz0Peb/G6tioYkAU5RyYImFpUivhNJl5d7O23tHH8+rf990soi0GRdEuoKLMcFgwPEP
vm4pZGjzOaEyGFM3/n6tXd1yhzBjWOQY8yMQ44xKXM3nIRciHuz6Ld08pVyIqIHtaQlYVMCmwrT7
beDocB47dM0Ujf21tbSYesR5aWrmN4uIJbvUFEc3ifggujJjwppoguaOHtDboUQlZMQhFhdWsSOl
kpKY43Mi1a3qkCcXfCGNH/ZcboI0MFL4R8bKtBw+2CR6/f7VH6EaAEEJX2ZFfFlUGQRqE9Nk6cCF
1sEZb0CK2Y9RLH5HhcpP9aXei/bw5RaosRQnqwkWS8q1nXNF2wSqxXN933R+cCdmXWZwfDxCdo0O
f7FlCAZiVL0K1ee7/d9Pidwk/81loQ+5An5uV4gxmHbCYhP2i/7thf7KMZ59zFjYBQGyj3/7OP/k
waNSpjNz3AwaimRAmuVzd02RNFrZ/KqhF+e7MoqRr2+CAHURyYWUWkqK6Bfjw5Ei4V1pCQmxTOZe
mRZ69RjxTYQpo8Qpi0SzU+1RyuLroeiEDGfNGxqQW5QcTqW72teYp1xdhlecs6C9wkgODOnvDlRz
db8GVH2Z0B8JJpfPH79YtwB5+Bi9nkyI3rznPVF0sqrMkou1pbfckEH2rAnOV8wD2cD3FoIbX0cI
X1V1DpsdjznV8A1/RB0yxRAw5OMzlQZUjgGkc9ABSo9FlCV0GDuFw9WlO3Dqs9UXvlKBnZrMmoVQ
maqwnFecnuqi6SoZm0EecWvLLGwglyPTNpPTmr4Ay3OEAHL1D9K6MDvfW16j3zIh5HOaDck0Vzjt
PYD07Xwdp4FwmUQoH+oXu404BE2DR/I5XCjsfDG5puw52vBD4mAQTP/Oed0fMJPG6nMosDJnVfFx
7sR8Ngh1+Gph+FJVQ6OJ2croCJTr3oqKza3YmtutiGtkjRbfyO5xYnzqjFxMj5DAb1G24sjE2ajc
Bewy9D8C+bCP7oVew1aYOLcd/MMKOOlcaY2tshKmFnYJxy/gfVFRP5GVQYm8V6RbA8st/onN7IZl
Xt8qJk6ClDhxSiOt5d4dUmS+ykCiHh0oY7dKgfG5Hd4V7NP5xxUbtgYVI7kJJa/DSYidvfaeFxQZ
99XkAf7o78qwcQHGn07mEcCxM5+rMQXHQdwGB3w+AbPSkVcpgFadig4B/+npRUS+n5zz5mMv9A5T
vajWJvhqSd683rSWvjnA22qwCL5eVjxAum5Ocg99feWXJywJcovJ42p/QxGr0KWLUV3K62rHcw0o
XZp1pzXb1LCGKXyjrVzNMN+XuTr3nu7gXNjVzomShed7I2PrXI39jcQHX44R8BdSfkZ9VPY0b/oj
VQmDCjYpIV7zC/uz0y6nhVFWbWNWYjk+d9oSqpiPiRjTqQNW98VKTJf203MygorgRfml7++MIcpb
yy+/g80KlLJEyXq2hajQGKDNgb45SA5wb0CobBUAr3tXAZxN9AqHDcsty1etDr7RLXV6iEVvYicd
mQGNKTT9n6H+5eczsAf31IYgXCACwtpef3azqOABFVq9Q15zVjvGUkbE0owrhitZgTFtpLEkfaRO
h5u+3WFEBIKYUAk/OJzBR6SigJoU/n93oHoafdAJwy7tCaG2EQGi2pJHu9CWTw6wGiWKB3g6Hpk5
ddkSRilrClhfU7L0/dEtcsDyrcXDyzaho1aGOmiHoY8TZew+naYHkQOvHLF0E46OVObFTc39Ogeh
gfY80w/RL0BYVeUsgbtn+yR7GMYE3H55UxwwXO85WiieZobWps0SPPK+i97cABiAghEe7HpnVjoH
HJ0j4j2/S0hTaKvb8S9S2e+U6npK5ga2QqaKvimzLwL7FOsq6SDz60buJr2SFq9gkO8ZxAJACzzz
LHbufQMkBb+XjONbulejjJjRQiG+iwN3RwNEY9czumeK5YFQQwrz8IEvTqLXxn86xJ2vhxfRqwvb
ERAR+tqpY/3MUjFZk1eYPxIsUtM44XtaAZ1XK8pdpRmyGorKZDxF7P1jk/fqjlkjUSRNDmVeIUem
wh/DBkSk9wrgHk0+r5L6Ofj8xr6h2Je1HYglpMFevqcLE9+4fsiUicJDpNHBmYESTWlt5hQFQmbG
LpTEFYUEMuAVHXV0wo7oR8HNtRzcYhZFzMANaDOMDmYlMPnwxj6vaFipvj+baWC63x8JtNz9Kkfr
emHxegp4mT0szVlNN6hoSM6gcVny2Ni3rYWXJw2Hlhi81dRp6khi/l5BPucfGd63KqwW+80o/9wr
g346LzUdjC/r70p7D4g9q4udgXqateuQ6IuMjHdr6q4RTx/xf8A3atNA7iKVh8MUE38v4LHF6ZJQ
pfgelXmgb+4u6dCgm2x/TGbaWMII3Ac1iQC+w/ANBt5gr8UeXpDUmJsDN37dXNQ65/q2LS/B4bp8
YeQwu+Rs6wBgfyHeTxHu3k3zzx5tw+wYqgWGX+2p2PJ1Qc3lNxM1+whhBjKGQVc6n8Pah5GMDe6R
GsuLUfI6PiKj1w2oauIGLeqF2u1MZnu/uGSGkdbQLPB+6WFPQZ3ZExDl2Gz49UANVkwg2SIEEuH/
PVmcVdGXsTWJfxRcaJikznsjgmRe683ipu5xaUC3inM383fnyDKanBYfepwjpcQ7kMFpi8yxuN+b
ACARc2FkqBc2mSu3mT/D5oC0gO+F+zcSofoblLNAX1TxyJbUHOPPP/wbkwdZWiLUOq9M4xa/lTzl
40Hkb+WLIzXgS7XjBf4HgKRJa5OCnZ+liQ0GvGHZZhmQv4aTcSj2pfnx9V52tRTWg355S7ge4suH
47vDqVLyqxI03it6DjCekE609THCvHbI1dK366xkX9HbbLkviIdleNEUcnTlqFicp8HM0hb3+/JR
Yu6BJXuvODoWcPNFyxRPAkgv7vG1Ns+uQhfElYuRrJ8Em4rjCZeamZkfhG1kMSjmGbTSIlVYXsSD
LNfP+gFawiFXJqdXa4x5KhtCoh4sPCuOMwEqiL3i6OcDZb8gHyKqEqIOFf9/1LFVlW5Xrl7bKgTb
T4z3fQ7ER+ZxaxRQyJCwfUpMKT1ZzKMHDrNV/PpXJJtFWH+tvmEPveoflb0737NQQ1OFxSWce2Q5
RRfr3+pQPKCjAtl2GwOVJJ9HcGlVg2Ne9lMRGFhRV1vEu7ZznGEQb/nSa5S5ZmxyexCWjel0hPqt
Svv4+6XekOPgmFuoOU5WvFPJESiMpF3dQo0WAO5J+R4P9Ak1Db3cqZWXpWtklF6QOxAp2hqNgRFx
y0zAz1AsBWJb+2QM+6KmbmSVSPRJrbX7KT2Vf3WR19ICj6QAd7Y8TaA1uZDfvd/oLOH1Kz9S/M0z
vZcUAT9Ga14ftZdw/Bgi/w7RKIIWauiWuRpD73puqFhh07ePld2p/Hi9dN6QoZzm/Bfh5WrwZs7d
KbXGyBl95Hlv2qJd7V+Y85u9O9ykMLfnceippKor316fSIJqtU4ruFPdIg2JN1AB0WhXwmMkNZ6L
4WiTF2WYBIhykNedsbZ/X3Qb2JIurKjDVf1mEJ6iQ9OgIT08CkHxb1FCRvX0qPBbFRD+snD4RcgE
0pfT5+1kYc5o//MAoFHaI/HL/BxSHyXcuZfhIPGgVvU5Sn2zerCCczBWrzMHP7Ef3Fl/50VN8GQN
pw7brk5pcUWusFSa42l44rJiA/clJpukawlP8fplqHtCCxmac9/pRiZFeI//f0ho84b7vF/1V1En
gyN3jdx2foATLW4jaxHgzoOUSkYBZNxZdr1rk8Pu0Nel7jMvmK5gxOT4o9yhIPQmDFoYQJwOGvhi
yYo53PxEpWbR3ddJ42KA60elF1C5vuL++nboTtFG0wWNPHsMzimhWtaVnOKpxlyWXUdIwTb3Ae/z
BrYEC7ksFYAhvc3Y5UrS5pU2yXP3Ks0BmiSRXpzXro9GyB1eml/lKGqqbQgaFE4UQuGljewXR7g5
qa3uLl6sTL+IStu76M62Tzk+YbwYstPnImkfPNXXLRg3HNSd3A85A736FO9+SV/WRNo7vneYTKVP
jF8UzzZ32pRPkV1LnHOPvbO3IppoiXw1maBTUpfSuf6CU52z04W3pZwcgLtuEZv2RiYmYVjb7pZZ
vFHxyTGJLrbEXIhIShS0YXDe+4AvQCKJwOh5Ap/M8ilx+nmPuJK05SN0yrr8AAWfspXVXRjBSKTE
chADzGWJz3wedBbJOA3RRM6WM7iva9fgRwyIb+xOX1f1fr6dvkLvyh/9HoQNSVIh7DmsboiXCqM7
AGmlXvl/1q55PA7JtXZpfbKN36KKgiyB6PJDY2mthAmTtz4YkwyA25NsqTmKgUILhtSXG6BntWoj
2wu1UHzdD+ltRPZcLpAZrQ98Pk6hi6GuOUv66j6oUdlQqBFPDyE2Tu77SSM0Y/vhl6vW+99dSq/S
aIzm5GKAjIDWfY84ggFu3xMoRigW0MCcsmQOxOdRrhMC9ebBlakTloEdaOaHQfFcU3hUzssF88UG
ei2GKUiNtMbM6GhN7u9k2LY4Y57rZmtR5M58q9rR0IV8GYV+blIT6CiGBH4g6nSiUKOjLvojZkqo
h1TdFweX92PCXjTCT+X6F/1J5Um5QXYkTnofNFJC0YxCffNknQ/FreWZvfRUVOwxPIbw3sYo/fUj
yU5LwG1is3/fHuL/Y7XJCFoAe044+qcS12eaRJbLd36gX1RZXEYmrhEXrlbCX5wN7qO7iZpSTAe4
wfTnAt21Y0w/cf01vnEd3eCDkVv7SH7FyfonsdVrL4SjtKB6Calxwe3iy/xT7rR6d0DcrnOybtRW
HnwPzllWkpSj8JcepSWoAonl4sLp9rSRR2my30X8wXSmhGT5fI+mQb+g2fhTerYhqLWv1tX1GzdE
MGrPhA8cB2TQU18a/IUC3f/Nua98RM2q9jVFUqK6O2OW1fzIfTR+jvJMuSgZFriCNE/yMA0wX2rJ
vGFBEUt+ii8f0bxHqZxxAMhkQkzexoQ1u4w7+mVYBE4LulvZNJ2LCEOB1f8d0QE4IdpordZI0HWZ
lcE1Gtv9pDOjYVKlKc/7CbSjZzXgAv59vk6TeJpmVKjMzoq4as4cPTlWjaEHotM/LkkHH7Nbz1Vu
by3qYcQ+IKW8eX8Jo4y6nmEttIuB6VXz6n/55s5tOxcLd6Cavv2JN6dt37NzkiXMyVqjgY/YtPgR
SlqbNE1NwfhHPwG5shGx/yAYXgbFhHMRlA5jHWC/stkxjFmzo0wsc+9luGrytJnirC2mWXXRjTVj
s5S0aXI95t23oHiJwyUimwYaVSgJtMWv1PatJDiSBIudZk9dKNq3TUAVQN0G1pAtqUJQWNfvz4ZM
VxWR6A5CUwAIQ4FPv7vOwhG8z3U33dzgWYVC4QAEC+MTWX7f1z5KHuMQBLfsY99QIDIWbp1szpdl
/GgjvskdgSdu+K3ErHF5hJhFxEjMdNmYq5yQg00FjjKxxXxSghDqXBv+8yjllknZp+aPFs/ZqSE5
3I+SYMsIrQahIrG7ujzNp63bOGn+qDbcrJ9jpimax26sekqQHLSOybU594Z/pPJgzvxp6dTYbfPQ
/ryF2u2U3pYcGQYMvO9gIUlX1wXTiCtbpdRe2WlXYrI5DJEe/gOMPfuPnpJASvJkTIvW5hAGGAiR
YMRbxQ+pa83fNG90HT6Z62T1bcR1z3wCVyb4mKhvwkx9Jq47ivpsyS91vxEzltQgP3aIwbssAzoi
NBYyMOqc40VQR7BfW3wpZRv65XJLOa3PrTT5rTlsfmbxKJNBUbvTjspHP52ZMZJ0/ARxQml4MBOi
JiSI6ndKiAqf3IZuQfdgJB14pTDIsVZnzpHvFNgoVHZDDHpqxCKPiwpAtHAVABBOwGtbH9VYaO6b
Js5Xaf74MNuWWoBW32+vVp1DYhYXaNXtdqqXZEQZdDw2hm7ze0BSNbJcAUuid/MZv46k+mm56nO0
I0eH7zlQvXt09b5w0MARZMyD+f1Yu0nOYI2LUqexeO0Tf5jAWLjXZrCfSHdzXLKLc8RipXbsmKms
eXgqFGlvECkbX3rsvIIm2Lc1DrNuziflHNQzy7gKrJh1w3ly+YGVE7P0U0UO4wpUKcqeaGiQKQms
3zM05LX/IMyZT7AYr5EJBCPlZxyeifveeK5KKbiM5kI0Fb5ZaeJlacwKW6f+idowlgq1lypjRsPI
gqKzBGOn7CpLn/08TbOVhRzwJpolSZyZEXXwAp0gLE8aITRwVv8e9XRIoo2tRPoCH0jOaIfSwGBg
a5WS70PSKHKr2OG8yT921TgPQQm0A+pz0PYW0gIZdQfpCe+nR44vDFYInccTVc8rjibgiSbKM95H
/DNlhSIaRgLC7aTMJZ6aaL8ugVyYvTsFad25o3haZsVxpvOy6/xb1/3PvkCFgz65OGccEw+OurJE
V5E6NlvmHXVy8kDgZ++u6ehOt4RHxt/rLCbphWZrf6TT0hxyZHjsMJDwJL9WjwfhqEpoNigWKaIN
mwUNlPjaFGIALDTexcdIixRWq8YmUYRc+y4Z9dCRKrevDj+Z7BK2/brj6F9OzZQrsgu68Q3+raZn
IqTnvVhJ9aRMgLNjYULotqSAryi0YxrlljXXEqchqPjdj8GZCOIjEAneAIaJYvPi+zPQe5JxJA7E
vjlGMLu4OVjqAh4LCiNfr+QYBKi2RZnRQ2jWk4ZwaBJlUrSPotzE9Fi1vmm0wGqHKFJbZBPgYBMW
dNEROmpEQaUUtDDU+kvl7V4p9DYiDk04Kslca8hPxIjROkOYWXeVUa7c8fewubSVuUDAgmy21u3x
kE1Ro7DB1NXoA36yqUP9fJAiHB4n/9zYNTJcI/0+P600BFsQcU2wnC4G11wKT/MI4SkyPsmnb6Ok
9iPXT35/IclnMvbs32zvNzjrTNLRbQyY4ehhbnhztznwq+cKQzaPgFQ+fCBRrlNn0MU+gjMWaQM+
QKhVC7KAZi1Wn8QZW9nY9TitX3vbWtlR3hKsH9+Cmn27UfFLqDOn5UXIMajggJ2EZNfeUPKWSMMt
HHS/skSSS6WAGWuMDQJb2dPf59as6g+S0WcQxhNCR7gowqYwJgu8vtiOJZDZ1bfd4cfD5ig1TFkO
65MJ4ZwFrbv1cFhUFDECwei0Cxyov+E/j3iRThckNabUMIkuOYA3aY8N5tKkLvUlwfUFvAO0HIxJ
AdVpDZuPft59b2bs9TaJ3e242P1DQqvDt8AgHbHzO92He1XAP4I2cxDIzghnUqWx37M8F6MWuyVO
88zV2yZRi9+AKh+n4aMicuqt5ZFang/h9IpMP15OmZR5mCnMUq3D4ZrWDUXT1XjjRnuzSlmYLuHO
R6Sf4pwa+7IBJW2j83MDjzQeXgK7iZ1K0rBzSVi48nVt0VJxIlrfjbIiTRcbJDLPYRRab2NsG+L/
oDkWd+dtCjWf5XqrTk8iXotHZszQPLEBf4fIVMFOJpXyStWOIV1cLdZ0K7TOKBBQvbNx/SDS7CKp
Brgm/zzt6OtWKwHiFGS1YrZLAk3kIAUd2Kj/xYu5T4H3cNvKJvQHLh8i8Ld5gKUz3OwhcOURaxc8
msaNBM2ww/G7ulX+p0UhZ0/7Hisq/LmOhPgvPot0UAfUnYNxyKP+9irsMZPheuPvnC7858ViHW4l
4OcqR9oO3eq98Ffurc/tbJTpi0lk3GFlt6CLHLVGIXkhgZTfpKD7wAALkVl/IOr+ifZuYEVnG2lH
g6iTYCPuUtefhRrTy/9ipGRuvuBpQX7iU4BMcuo3ZTFpUEtjzlLDW0nCdfFV9FO932YZiWn0FLlh
DXC6dqPNOYxzgoBgEm8wbg8Mhs6BLVwIIJHejGB/v92EKOVFwH8fWtiYkJ7Bg8RXl/MB42N/NWQF
Fk3yVWFW9e1wdeeu4czee/q8BalI+OGjIAgId21kdJYjrch9eiuT3R60Kin12hBLaD7EcnxxuUvd
9xixueej59Akzb5zSS3Ea5rYerVwgu0q1pEKP7qbvKsyVvU1/C6s4z2C5M82x0waifEPBI3cO5Ud
5u6+YB/EsG3JFhfd1pCwJJyXYlXU21RPZpiplpSld+dK9SYvyMlI165cIXZd6pM1lS71HQ1VSIRj
e90lywH85j8gKwXI1DKOc5ZAKoN91ljho27IXYz7s5Z7jcRwit7VEzVOCLuF45VeqCHuX/FYcl33
zJOArdfAugvS6lsx5jjABxE2JS1UfJtY8nG8L6UujrZuyZDEg3D9ENU/nwve2a5FP87swQJKVbbW
Im06rLDPjeGLw1gadR9VYbg+qzEzG562Ew3rP/vHAFf9Br/Q6L1HyO0LS+o3pZSclYlQv8+EogEo
NfvMBFfWzUHqJBc8M2eaYAUPSbQeM5q4PTr5ScuIRQfQ84W/lkWlmq8lAeA/HCbw7Npa5u2x/GcX
DCZef1v337xJKNZ/6WCfOZ9JdxBaD3cGxuvgn+Wcs3Kpk5mM4n81WacpCfKelG2lagkg8G6T/5Ix
0CsNVZopAIJculAH7UV0mP2wmdASTCRI4fGFLJ6JSvc1gMLPKNHC/wPVBJi6ny6dkCIAT2KCkm+p
za0POZMpUWvY1NTh0KfvTbS2xGfAW9dNaR4XF2Upc7D+velTzccNS5Ny1UdUOXxc7JdrnbbuPotM
rdlQkl+/APisSNpvRIWb5gQu3pC0I0RRs3AvtgizKD8ZeX2P/zTv9tSlK6F8ccUBG/84ugQuPsj3
NAl4shlLDLYh60wxnit6k+4+Db4rG0yvcaoNb/8nSBZOTuYvi4N7gTzETnLK0i2FcJCEbX0HIIEw
1VkVuk5/faI6AYFJegL2O2bSgt1t7vnZ4AxOUM7TJsqoOJ+10EkfyPBOX9jNI7A8yEKgFFnUSVDN
vlzLAfYEbxsn4DLU+8cLbZdd1ZZYKvEGv31GE2wy/1tbLoUL5808pqUAD+rurecfUYZhNNjFag3R
uunWPZgD8Y9R+58ynHzC6JLOyZONQKeGidGEDKCf/aReiOk25E5AwJACx4Ou496ipInWWIBXjvPX
LhOepM5jH11vBSqFymotZwQTlMW/qb2JrLeIXhLTfFmTmIHLSYy5T1p0hhBXPOygLFZd70k/5I0b
kfZEO75J3SuieHhUoDH7wzjdsMnqKSZ63ERTpmEDAH2kRojfRJ/u9KPCBVD5oq4zIr2al84YfyQg
qWemlyegvWLGluop8MC9E6PmVe/b/QJTxkLegRwvUH1ntHH8zpIzPjMYhGJonMedl5lFj1D2K744
L+dTgxkOaYtNWN28RwJQHRS84ooCzdnR4oYHGv8ZA1ISPlIVISfDaWyF6r2U1J2XjuG4h0M8hr1+
ipBMnA/aaT77Zdu7sgM/t2B/ML/+RwMaApPE5/sr93PIXBdC9BCcYQdtyEgZNgIx5LZ8CiyD5CSf
/K3JlEiw/83PLkXeOBfeLTd519q4ZYAHZ1U/gkhj+Hw9IQBGGO4E5jb2Qmz3kE4LYhfxnX5yzv/z
GHqZHXerXdt4XoL0kyyZEhRzAqE9hjy6CZyWuFj0C+I6J0ZPPbCv+9/12UhSZMXy/gksaEO7s/W2
NXchK+1F9ybTSlmNIF8E812dVpSuxARAypdoa41LiRoeUVayzKjbTD4BP7VFal5BeV3Nso0Ohg1N
HL0svchyrJqVUL6PQ15toZTYJ3wk0upUynM9hukbaUQe6Rd9NlyRUlmpbhbnKdR/FDVPlyLdLaVD
Tt0A1tLfrwfjQrDe1H/IoxEzNI85lhnhp6jghGOVZAdiO1UKOXcudsFqg3J7wPNw+7g1ICgi42De
ipXM7yD5xQpHq9NkLa7+jUTOVjq/s5ZS72PaPMDGUN7RP7nNl7zVw6xWRJFVVkZVzTZyjjt82zEn
by2hFXfVRb6WKv8NnNfLjq7tw1pfzm3GBnWzWxjUmfZS+e49j/X2zWAX9RzczyWZ65YVF1g8essq
xLtbO7CJH0TxJ8IjkwbNMJKds45CP9phWdZY93MCOKOGQ9Ijtu+nIradxt87qHn4XwNHzZHSd65t
D5Z0lN1huzKz1hCLzXqUOOLgs8YPFQG0Pv9DjnBP6wjkjCfr2FaDu3J8R5Zl4q//JP55KfcLnR8V
iD0whM0ulfUkwM92GwKg50J9j+A+qidxf2bwMcdFVraf6MhEEb76rgi0Bn/13dGvfr8wSiYYP/RC
iU69ZmaKEpob/LfzxnTZk8RprFIu2GetIM70451bkSv2vY7d64I544GN+DjB41genVRAbp+K486+
C0VwjGUNezBGm1gQcsxVYmUXPK5bP1QHvwOz9EB0SC3j3uPQJ9T6O6Kgnla9WrkTDUyFBqpQn1WM
0iH7dHdr4hWWRF4ngPkXY6HiOBOVaRG3XcFjLOkk7Sh7+nVTPZbdjAVRaEf9TIg3J1UrsNpzaYze
jCWQ5ZLmGPdFpKAge9A5kiHB9qanSKSF+AuPCNcFJFSJCABx8Z0ZXgIR51XE1l+W0QgGo/eFiCzp
fwWGH/CRrOt5QTFVnpQSt01VlbXeZGaiHtCuG3jdeRvs87bjBNMZV4lTxdpkcOU1M5eNCojGZ1sO
PYSDqc/tAU7V9o5Rm5f9NMFmMgGZXi4R6dhoucxRfd4nNcKWvy2/vJpt4IsZbcjORomgywTx3XIq
EPUTmkPb51MjHExcW34op9sRLDX/G69exHqyHkp9DCX57+bF39LwrYwKVn0ugvFbYjxnqv2HabPe
9s8B1A55Nxk1+EZcjLkYgM75dHWTWpiRrcGBZZ0GexJbdTbVCESb/6NSGxTuTkB01IBOC1lWHGuT
D8t5KnaoPKeY5LvAONWYOK4Buet4gkzqQM5eKL31QiQxAgC2mLqmcz3CbX2g2D9qjLK8qEpy4hxo
lt/6At7B6/9wO22vdFwPtJJHbrAgCD84Dxaf95G4nhHlGtRMD3RWOfZPEZqdNMb0GGCp4r46eEkp
vZbj598A0hDNQ9DGUJKhRmexyEI/ss2F0hNHShNcU1YQcQb1VvSrjwskRts377XTR1X1TRLSMj7L
4diwc4/BNitgyFJ4ftjr9ZMxxjFiRdX/163yiIi4tHLusTeNZILsuSz00yfSqNbHX3XMs+HMVl2Q
op5otW6xLDI5pxYw7OUprTEcCjVNzxBpaepmmJUKQAW2k5fOPCt5txrTF97eGaeAABvSfZJkYQp+
Bx5v6FRpH5R5pMVHuAgQTNcdIVQB1I50AWtYaYh2WLohe0csPyFfA8qKvPiw4xUUIq2+N3Ij4fY6
x3XsQw808Sgq1IBXFGM73R/ugMZYdWrNc3iGtYj7UZjlzwDalXzZ/ag/9tEpn4sCRmMeJPjm3TAV
+GMaDjbmQ6uFu4onC0eBCjpbj1A99Wx64fMzny3/gXFpNhjvQLfwDyGleMHXuXmcDNTSoXquMGUq
R7bVohRz+qRXJDI4Px6W630AQDqE9WiUtDfzbSkBnkJ0fPVlsX38j0pcX/KnuIVxIjkbmj/rTK0k
tx6yan0Fhybds6lcXC1llQJVgBNGh13m1H46Zos69i0XYt06ERYU8YEO+akQ1/WPaz+eAG/0O2ur
f4F/QLkVsQDRuJ+VT1kB7iKr0hxcs6VLXng+5i0fV3rIfN2086/yPTgFCf9pwMleIX7pALyUqV3z
Kv1JsA6yNrPnXhVQxCFVeN9fkRcEjXQ1yWNN/fZ0/TFDPRQXor6NENa5lUg7sC+NFtfZTbNoiQ7r
egNuZCniASF86J6JxPMpzqU5hHSgeKR+5LI2QI/r5kKDVBOT2ZYA0FiFJzTxAt6tTESDpNOyAjJm
RJMf9Tg0azlZDZxBD8HJosYCApXfWLRZd9wgNiz7jCFkqznLQGW844QCIPM1F8pNcH//btLg5HJP
s7cO+bNs5KeQc4Tg9ERFYZlXCKVx6b28PQYafgPTjxCJdKW1f8dQS3iOb/v27VoTqKE1y8+k2qrz
475eQeEr8ReMjGWmo5IdE9Xmd2QAx1G8y+ozVAlBn2yxAS4XlqTNcj2OGZSaw5J7+S6fBkuZx387
vzsB9Y0D/cJLfYyPOlOPpyINgkTAtiClEIvQtk6zgvEJJij0s/4kzpBOhxuwYRqTJqsu1m5irgSk
Nwv1m+5YsdjxmTLKlm1wKuJY/+TAhh0pzqzsjudVfccm9xeODnd0NHh4ATC8fopmO38tz2OJ6HQZ
h+G0rLXhdpEsv/irBbo981kgaKKUUwrUJBcVmiJlNPp6HxmiwvCfxipOKiiM8f6qR0wrVfrz6AbZ
NuO3YfMkZDMHnQwZSqg0fQFL/yUY6mXGXZ7SB6oaaPeHZUu/xWeAMVDIe15mX3CiFw/I8ecp/jtV
tYeF+fMMsxfkzr1g0IIe87oIBYFB151oUSmaV2HYoX/SKBlpECrate4PJCE4KnJtjT99l5ZtW7fG
r9R+qyWCgLkuIILlNiC9/p2ubakN7l7OCbz6EZFBbZCue0TOPbDwOAUD3mZx8spjg9tsnwe8JcG8
H4odVkr0DhBi86ffQqFKew8gkfGP6qyz7mQKQ3PuJMCRCcedeAp/7lufrvcXelK0JiEQNOcfxVz6
Ql4+gvXBllLhPvzo/asc0hclIz5EHjmyz9fBCgOAvdFq+P/uFuM/8I5GEWaCPxbhqyOD3BN0de1b
jvFiK/2EwowLFcwZCInXGa0/cHFcGpxqAn5ZrG/Y0Tztj61U9evUXeifoRDOQGeziWqHLnW/j+rE
bmr2Mlipv54XTaPMzeeLMyC8AnWR4BqEZ/ffeMBjB/WJWY+mhsrGqBtxDXZ7+PQvQoGpVY648Syy
zcSMgYWhVt73UWaioNTVtbu7H9+PWQY8Z72u7UOACEEleMbcTY3cJMrke8dEKRsyxT188D8a67S+
I50BgPr5VAlYOlOmkqi88/UaAz/DVqwJ/kAVqkWuaMwyR7WhuhdqSIzKhjZSl6YPcqwcr0DWwxv3
3M1vuU0S+A2TmZf5wusU5TzJqYqhKeK+amYHj8A63+U5+rNC/KyZnDxLD63jkNN6Mt/uWmQHYmd9
ZB91RMLAc1N1Ms8qKPOa06tm7Yip1W7vTDJ5Qw67/yhTy4nyc39iIwaocb1/zcSi1jyJPBN6piCw
/52jQW+B2yn9BC6rOnJrZpb2f+eqdhS8T45kxaKk1+jaIbl2ykAGN+wa1q8TJmQuiMxeOf89/7Bw
vYxg90h0/PZNstKE3tzYKBQY3SGkVOhny2WzELxAA9Tjf48bGKQ6fLDvBC3WiYgPMq/6Oud+FtHW
7RWRLozBRnKYKICnosAdWB8FeQ5sXpQQPqsRgzU868cO0fI6hyNsQrpjIPucwVZF7JSx4vbh0KHM
M44coHnkOkng63m5htic8tFnUgLFTpc19awwAKsFF9+kxdyNMFhSG5nlUp/3JaUkR9tR8By0YK+Q
ECrWtB+hvxflwJeJ06sWsHpWYMrXE/J6kIYJfEFOBT3H4WtSC5uiRkG+iTMu+PNelw9vcBVffCh7
F2fi/Z6EoQX3lBIQ1dvtOGDbEHm8nkj+Fiw34i8T5UsxJb1eeIGgME9/gvBaikWkPV7zKgp8YEaJ
Ngfxs7qRTX2JW1UNvIMxGqMQNSK2nr7mulyb2VakwkjMjrxVZQsjfP7RkoYH9Zyf091wHzrIzABd
3CO2Bav0VqJTOcO/DAZOhjKyIi4kiKJY3yKjpbwzXz2ottykcNKLijRKDuKyrhrpTX0jTe+HDeQu
8w2Fh2Fj/Iszu5vUDPRhEKhfHwVMQGkAgrX48Lrd4MFJNMYAEWqc1Up0sD6nRMDgwArAOIFke5l2
1F3rHVgM52MeSGCEZ6Cm8Hmcdt4damCTFEsdAzOLpJFDqIJMEoFLHAwUPaQmW0xDOAhE3KUOECsD
pXQhGRcfFHVsSRl7dU+xJ8uUfwIKIeiG0dDYXJGx8KwaPGlqpuYlivb7R+R38ifzA/iQEpA0xQRi
u0nD304vpoCiHPx0njN1jxc/iH0M0/EYo1L0KtXVajI6Cb0Fxs6CMZgV2GHX4X9faKe9RlQIiNPb
Yp2YJ+GJZ+PNjXHwDleX0UhihUPTnaJc5+kWvw9rjvDt5uAZCIi+mbuERHtpVaQgjZgY6P0VowZi
m5upcfCYlekS6cBs+CMCSeaS7fqJ3USPE3lKMvxUQn/PNUT9MVSMquQz4IkgQAytGFnjvUBVYa01
ImfBFwyrgjcatVpgRwI6nXw54eRT+4MWaOTDvB1fw79Hz2wB3d65y4biKTKCifkmR5s6FltM6pa6
Txyp8KO9bjg7b+AhmKCXS8Kl9aUUHwrP72ORESTkMV26hkuXfgbXg+7vhUbL0RsI5PmcY2xWssli
PFljacZ4oOx/Tn5myQ27nJWu6pHfCuvKeX/oM6MwReAAqFLN5bDbRUJrpLvEuxreRT/D66LRWbVJ
gWC/fpQUQQoHhEQVqYaWHZqIMxm816jHT+gU22fnfCTBJCuepZEGM3eaUNA/JzARPbsU3ap5oMIe
KpxODDxPMRxQe5a5sW0L6kPwAxTPMnkE7y5zD159pv7HQOS9iN5dO1rZjFsH/xFT+u8RgXOsc8f6
RtLjdAbQZpqobuhbowi+chYiCGmvOts5z3ZS08uLElX2XNqkFxtxg54P7rjbAowGE0kqOqgPNqAM
ahoaSCE34JVNXiB1+qJFc7lv6KtdrsBPzjGkghtR+drQTu22AcfaUmS3qJnD2yHkkz8r7/N5/W9N
v4v2RjGDdXHZub0JTzMN8za7Ip3CKAwRf2XefDItpwRCj1BDwHpn3eDje5VkjnfOiD6db1xZ/qJR
WEogn0EwMZ1b+IBphS/1CrqcfplWfVk8ox/QYT1JkNzCTy6Ka3DlRWZ1z9RdYN6PNNoIy09LyQCj
s1Q/3mULH4J+JpAfePZ6IjwgfwRzwkOeU1cFg45clUd/D45thBH38uBu2t8gqKmQFfVdvQlXUhna
ESIj7k8tawzLE2SDkVlb2F/kB+Ne2nedDBWUwlOlgRe6n0/fwAb7z54IWtBCL295uOY57KX5JqVH
h5mS3bLsKVW+asreSdceSskszT12yzxzD3v1Jcy8HogmQNQwX+xVonaozhhrUB8mCSgbSpu4w6v6
OlG4YDHQA+9LoMQVsw0Mu/K3zMS0JyPMlIh/OKOz/9Aw2FHR5KfFuZmGdDAvzoHQjrYvfi4cVYVh
WeSdDnGFnb6hAe1SA40EUeJe5YQHtsw6I/hcXQxi+kgQOK6CJneJQlU557YXgl6LlUfGMGYns73S
bJGgxHiqjnIjV86haiZ6cUln7pglfV7GPB5raBfZsqTNYONCkaQLq2r0qrmqbvnv4u5Me5VsXZRQ
z7yshGNV/h1s4ueQd/mr03XUC/0uXYfwV71AZAuLwblWsNfvKigJx7Er/3WFe+cBnaSvI+FyZkRr
kPx8DJK9fNbDKjJJ0NYFD47S00KVmxZmg9gU/IpFTolZ/WTx4/ukHca5GKuoJVY0acyqQjc04iug
t8+TJPGXhqNWPsVE+8+3p+TaZ3t0yYvc9dncufRiGy4N5XFzZws0yuAI1iN/RVkywDn5uzgaNJrO
wdZzm4vFLJPb5qQxsWn5Ayl9XuStyUzoyH1SPuB4h/bIVFS+E5UxMRxl655lXl1FFDYMc/ur+NJz
jdVabkHmPDCpOal9m9oGse2n++lijQ4gSMJ4EuWXfUiJJYplD9uaGUkBiqKDaU6L2+irwbFvaMBG
SIp2zzSdGh9Tih9Vha6jNVBMYRVdPbF1ccmyVlBpxDmf2eGAfvJ7kMz7F/VNcOayInhITQtTZ8e/
SV1i+b8psV1c0V1qiRpRXiSEablFhu5Q99D6y1CttNuHuNOmTIAYOmmakknrB0vxToTIMnv9xBRw
3pQNwwgb1JD15/XoHWFr0EflAwJBqBW0uK8rTU02sSmyhtS4A6d2YawhoxTui0ULeTkYLSCJ3hm/
yfibfO3n67xce+e+bVY78XDPKaTruZ8gfJ110tACIvkYGmrpG88MuHvkULVPeqMvgk9NwpBfyLer
hbJ/S1dy10hObZ/nyTElbHONsnX+zPgYmC1X1mSd6NyBymfsWqA9nVIXsyPqlxZc53iUXoNUFrxE
L+MWQpJxFNnjS052YilpLSSGS714hQPPKQ+jgx9RnGKCcPUv/yEJQf1t8A8T/a/rTLc8FoeAM3vR
RJZdEzo16ExlW4RaFnnJN1XQ6KgDmBQ3sX70lC5YBQxUAR2FHs4FI7K9SQpcuQBpM5QbZ3TTaNBU
n+1iq/br8hNixYVHZ1+IvshkHvyfbLBNlYNkJjJ0k7d75O/fKsecXsQbUcK8OivlC4bvLD81t3uJ
A6lODc0NlR0NOiSaHU95EPtk1vGHy43oLU7/WGPnr5cG8nnmg/RNH4NtNo7UMSNow8MDjMKZp3tV
2gPGCWzA1jvf881YoXPFv9Nzf9gN1kV62pLNGvNBgC1L/C0nHcMkT0UhVsMEdESf2FWYKr34Q2XU
tAaSuuhdH5fJhtLk+z3QNY+hFvKe3z2ad/zGqM+6gbKphYOMi7IQHMJsrCgnPh+RXf+2Rmr3eDKf
qWAZpjSEkfy5gZQ8fmGpP6pa2iH6yVsqJQl4Py7Cs5W8qFQHrWAMtwnpU7qQS9q8TqDj97AlaBT/
gjMcDrrSkY/7c9RQB4tQVeEsZcZ47SaFxUM9Dt3gw7Eiw9ZZJQ1H/bUsa8Ro/1ikq2LoZDEio+0L
0fzxnCm6uOQNmo+MFM2NJ1zze01fGV5Lne9GCiSvlF7kpSjnK5A8B24Y0pa8ZzIS3sTwuO4kOyrI
NnkPkVlXmJ4DTzg6g01951R886zwkvySyXG1bOejHJq3fXtnzZRc/qraOfojGEz0YodyY+3IlViL
P51U1fNIjECydGaUs18W9pSfVvOJfiIidKvd8Oj9T9hAUTgstWn8Y3Zlq11Ytl1ZJKuPgPvxqeeM
IW3BsZNz4AB2ghjzaNBfyfm7pjopGmuKWKP3l5WWgIqy54fFCLnZYdu/6K6YpsegnonuMZ93e8hu
X96X7Gx7+wMit9djVVE8pWeJzkwpJtBRqN1h2mujQk5wW41o0MyJRg265xNKoMGmUsjUS5rsm+ak
tgkT/o1TszTGooaG12wsft1n8n79516AMzDrj5MpnvDGo4ubXs6zbItIKBwo18EidHO/1Hx+K/Fh
QRkndW0Cgf5+MVOJTd/hoLjAlUjzidwWidqOEsDHzQtcystdUPGxl3P8zcpTsmN83S/UOY/V9gkf
ywRhGw1yxHpoeJb5weNFz+pZMmLfBNftpRqF2tLeoQ4b1eM02O0d5sUQX3a3EOHXgJil0DVBzcve
nYK0iUv0IAx/qoT/YDj2xq42UYLuiMAP+dVv3cp4HNAwHj1wsSagI0R83ueN3DNrPOqLgxOXZ1wL
zw97f9KUz/wlp/7gaUhNhDGRsm0EUhtZWX8vjK6Qd+Bvw6+4KBJzL8FvSPsDXR4sVdGPADRt81rE
o4vqrF2l/ht/dmFUhZsrHtethIfISSklpirQbSxWWFQL2+pU1YNi7RxJbVKu5d1bfOJrwVJ69Ncg
3JJzWvBdZSuvdmMB9fKWw6JBi1IAiOJLAj6yqhv9ZQinsblUXIIN6LPFEstSQg7WfLmWtsJqdllb
v9q0CUSSt2lCjPAgLl2WdjebZ/QJyOWgKGmlNe75MmS0zxvJPZDLnJN2/tM3md6VmY7wRo4S+HAZ
fVWWLbRD8v2PkX2Q4xoeCqJXTb84/P4QGGe5oa4kFl5CkOPPxHFdiToCxhriS8C37IENO7gf3fmJ
I0U/7kyt8GT1nGVrFYxTIAV3V06pb+ZNvYMzmMsGF6VKke5da401nF8GpUtXJh8gzwWp6DM6TJHr
NCnXGrcXDIu62YmR+4UOki/rQsajqftptLK7Jf6yGFRz3HyC9chsGmfgqeJxeLVsZrzH6gwLJG+1
4t3Wdj9DUnrmEBA38evCDsNivi0bFeiYEkyNqWdKo4wK8ahll9RCT5dHdQQMu6l9W2/PX88Mb53m
7I6rkIxG9SW3bBywfF8OuF1+SerCCfbEXgGAKmWL34mFaq0lTIlr/u/dVxUrxdEVFvuilCSmTDnM
WVp0sDCgghMv6DXrjvbW3byda1MOyvQ6+GTqfPYsolX9AkdCC9L9LIMdSJuOASfyStDKBHEnzHvZ
rgm33jn/E99RH5yETnj8ACQeIpxDznv4fV8a8e60uBXignEqS1+lcWrhk45MDeTxPt62+5T9PquR
x1DAhRirODDT1JvEckqYOARgQkCzqQdHzj06MuiQ/MT1iAOnEmLe/Jlme26xTgOLccdoNVwzRz1C
sOfkCtzNM0pZXYi/WQRHbwybiimBsZoYWv7psRs8/X8Rp8wVrS88/O5+SY0f2UliAsZhrsMd2+fs
rLafLJ+bo/PovdGSC62ZDtigRXqsxM5JZwtQxkqSixO1ZEgS9d3mYUUyzZb4l3GcIG5bitrmpPLM
f3rpDzyXGCMLSAb1de4IySlfuA3ww8aU+0nkygXyZAjX2DxFLf8NdlXaEqOLJEi89QBCSI7iU5To
UvlLmVONFudqlWEvSc7C8rd5nEacoC6tKCwYj+e217BuAAM1iGum6dhkNywVtW5sgJ94eMob5i7B
IzdODh0rgLLdoyDz64EQ468IgY5w6/8AyBd6qMBq6drVzZICoUwYTNuPCc9ncqfP0Ft6Y1vOIQmy
+HkKUgshmN3DeVNn8ffNtGiSQc1ebvW9cjxi1av3ABxMC0N2t1xdE1zQlJ9CV1hdR38pJB5o7x6e
UHY+3Dix6TqYB9J3Z9XaAMbq0mTaQwk/HPV5fn+qT8YFTa1VUH1r09nDNJ/M7VmMF+HTly4uN2hP
9ZT1RZh505w3edTDhmIA9p9UMTw5YQynwmmSNJXtTa5mZ7i/RDtucSWf2Ak478Kp6XmV0y6CCAJ0
80tewfPpOSPnvgsX4OyOz0iHF18roTGlruq2k+sQGJOxDs6vL+TeYBDRRcIpJcI0pe5XlMcdonld
CihwLRMpC9zijkErjE3LHs/no63tlesM48HMoNvblG4qQ418GZq8qBXv1uaUFnPFOhZSBGqdhQjB
Wf9jLvZmhQSLtkFc8TQwRFyhtaXb3npskc+3XuiQrBSX74b89i2c3dJWm0tavh0rAcM84EsfCXev
ezfOOwsdGEgiGlzuljv2yFI3Il9vWAsCGYhIctKtD30bwK+OELA4XVG35P/AcX5t3CZG8morNoRt
mGm6fVKQRHq0D3MYMpCeYZAGaJG2UbgIgzCEeM849XzgM29NixqEH8Kgh2ocQyyaKxCAL7LCoYlg
qfFafpDVy8mwCdCzzhcyPO22tO3Cqnxtgh6Ylv2aRooVtPlmCTgnzoNJGV4efmN07lW8LNs30jE2
rHWib0jyILCtGMl6zbcsSScMp2Pp6SzY6mxGxrR2Mwr7m3pBqk/eF7TBrg7gipQnaWfYpnPP866e
vAZAW4tVoxSKka8/JcJuaxXrk87MVb+D9h7B1ppx534JeJ20wWWYArzofSdLrK8atHnU5qbzNp73
PgwyyT0X4RfIKObN2gNRXAjn58kuezGGfKu/Os52h4hPbunwv71mexEyMGUbOdBvUUL8sMQaT0C5
5NVk9W5K8etAjQLYEZX51d/iTxXKErR5PB/iWaMUMh+5HRW2nvwOuI+FaIWU6mM9O9TkeNuaQDDE
9M3oQHpMzYeY/AMQl27hTXnBrjWcJYmzh1IdbIxNXRylYUYQfhxZBVeqP4WkGKCaF5EPgDvxAauQ
X4/6ilk9/csCUS1asd3Mz4LQT756uqxwlM0xJbCBLbkZj3aHYxabhr0/LoZBlegsXxwik3VZA4wL
q6iXPf2BT8x5hhrTMA81rF3aWamjr1barJnGHl17sre30nkBca4QpTDRlxyHiN0IjUzHhDcYjai5
5zbIBL5NjEc9WUx13w1oYpsNaWVjcCEdjZFH7/1K/vOv/YhuDrXR3QTl/kXNxS7am0sQP1ra+51H
C+gzSE0m2L95T90v14u8SzHLqG7VLx2KO6GCxnElRAJ7dCjRz9XiG1edI14CD9Z+R5IcdT9hn/ro
Rz4VxyHyWrqmXF2/p+JvJZDpRwbe5SwcOGICP9Rbf2xAEPNyelLK5FPwdj5Z0kKBZjPoBzkYv0+b
dWahEnVFLQsi9mzheNqLqelEJsYbVIuJuiv0mCMt/LSGsSYd5H0Dl86fernu8w3OM6rUpH8Zydw7
U1sTcgIz78iEbf2Cv7LBOKiXJ11NQ7dQWHCWmYL5xMOlEmDAxdZ4pMXpjvkHcgTAce9DOweSsP+S
zW58NRiUWJBbpj4d+0M16k9IAe3f2RqRVl/ZxrR3+WAJMElMMwG/y3fLtBrZrzBpj4gdmgfi7JcX
C7TQ3q85FDK9RLb+eVKEDqxWBp/qVJTIXf6502ZCG2uH2Rp6ApPq1K1I+SwDUXVrMMyq1HKECXFq
YCjBbzWbNrhA9f3bFAjOMBsISfKiySk7aZondZFYAtfsCn+a9CW2bSV9uiVkrNXzfS4RAy8tbPkw
EgLq1zHwbFtVlZzvyqyjOXIqCADQm/419pzDEoSuy0BrNLgCjbxPlmdZJK3phRYnn5t8K8JyOhMw
s5xBA5pAtNjcoUeuKlMNWemoS0Wdl+TJNZ7t33no2SaKU8iDQ0xXwtdoQ0Fg9ULFjUAp20GyFdVw
GiRqV7r9F827UB53nxE5OK4+U3P8gvVF+T3v1BcguEfqTt+x3G3vJGKxY+fXuPsTqVEo+dCPuG6W
bnzEECrv5Rrf3lfJIHZkeWQx4N3RQoJE8hUE1p/Xxy8oWKUJXvpC+q/Ur8yROvTXQ1DKncm99Jio
nl59SVxCQQGiD83afxMWK58UdPxBROqPu2klVOKexFvyL58aZDw5tx3BZX9MNSmEgRYy+LS9TTVR
Gqtc0tkrhIZqW9UE8Q/lr7U0TQ5GFsWbzmPiBJs2VU6WkL0dqwL+Dpn59Us7o9w+ByfLTyrwAF3D
kPEQTtf8HeuppLaiPmnK3s7wien8J6CEx6eolbowD5P6lA1rKyYYB61NQ3lAnrQtXlILk/8IxOZ4
X7soBKrUL3R4y4b2ar7AMyNMkWFUj8diR78AJ+FBqQskEDhM36pPkqslak2+gnFppBUMkmnHT9jY
KDZUdijq13LVOPkUCZWFse86cUDfZuFdR3z3NOgwZMF0M3l3YOKYdROJ9PcWLuEC4xMY+pfVEGxE
iNhyUaFejAZnNlggPruwZJm/W4X9zRrClw+yw6iwJyLZYSkEpL37vokkXAAc0chjHqL1Pla2O9+T
YN7Pp6ABco8zdLgLLAoTmY87JHuLjHidnh7PQhrexkCsP1BaAMTeLVdKjDjsLGQcWF8Ny0Y3RkBf
iSoidyxfUBMBdYpfYtHOPPBncbosk75QsIOF8zsFj4g0DTHm6XTE5Rz893P+5rYeeIecOaEfwLdv
cfhzVHe+Q8ra31zwCCknqexGBHQ5TSg7A2W23LskwnYX9vmkJ0lPScoZ3B8qf/UnSIuZBIDrcR3f
z3XZIpjoFE2Jhe+7plxATYIvtLBbZUYnpmAen375kN1h+pFN107hIqZaKxMHF+4DS+Qc21zwm2ir
yDKm6pKMcTF9Xlke63Ab2THdogcLAaZMYmtUPac1GikDMGydW3VVH3C1VWLq059wzqT0vrRAZGXN
/gbsHeY9igAGUgJTa0zAsfNYkNj9wYnDBqUMbL0AnrVL7eJQAatVMbMqbggZ3sKXRovhMBCkDBaL
KRKS6i8zNUXYo4Knzp4MnPB0f3hRav0EKgaGWfwCrJw5ojWY2/PDb0RdGQB31Ie4BiBhryZdGH/5
AljGLYMvh3a/NpXzvBgK7f419WTz1EFrF4V5gNzUIAnoOeZ7i30NhPFbK86kyPN+9voHJiJWz4T4
NZVqFxmQjC0WM7jHWA5oEsPwoTXsvIq5o/l+GOoKRKATbkhBL3b/vlOO9QlV75+A7QtImrirnT4M
6skDePazzQBXDc0LbzsQA0rPVwCg6gjYxXMmF/miMu7QxKjKvQlZYZR7uA7ZUcVLVhurhceW6YDd
dS1RzcVvrPXsURJnaKizoo/N7WpJhddZsupvGywsSCNXwwtapFYIrncWKCy3uYRTMKlOMcSSEr/1
JI3wsGI4mM/OqX1BR6Zv6DCr5tIB1zKyBkRNXRFc0b9Fs0c9xxMHEmoH0/fMtYO73BsUcUVC+okZ
ov+0s9bT3B1lbio0rXsZAy2gDctrvDN1kUSFd3G3IObT3jr8ands1t5K0uZSGwN0NMqhM+fTKdMI
TRvDO5Gz0TOOn7NyB3FB+fMnh+FsAU6c6k5KdVqNQgAtXDvlflFxqldzqqxx2aAfsXvQzFR+KSa5
NKptkNVT/E0ny+W5T8bg5TaMjYOHssdANEt7aB7OIMgFvgAkPvAroblCGx1c7Lv+amkC6LWD0X51
HZwDh+qGf9j/jUb6WAdDC+lAC2tu3Fp1LZPzkrDSyXwlSkSPvGRIw48waW3ErqFmjaqeisKe0oX1
6jnLbWvHwFDTdoOknmmDXWSZdYwMtrHWtOprFxBHRBaGT8cY/P595woqF89y93eeg+UkRqNoPZ5X
XfqlOV4OBB1HdQxywp4zf2BeZ7wfTT6kve5cmOWxOF5Kzv6QxNEvO7YZew6Jpg6S7H5RxwgDbXGc
Byi7Zy0wACIwN9V/RCCvkKyXtJPzjnt0LP6NpiV+WNuYC/V0M53sQUoRebkViA+LY3NIUyHSXdte
BYDSkps5nOL7px+/SO2svnFWocaXyZK+he4CGC3Jg9bVch6ft4JflLGtPH6WXLz4WFP54bjPRppK
eJSVdNjamLYmgv0sfAhKLExnYFXtx+g/dsDmaxAk+nO03UJ9qaLT2LN5BIa0dXvBlAzBOSp+xFYn
IFcB0Ugd1bA/ew5bZqt5VkgoW+Jj/eN+5ORrFDQb3MgqpHOqLPM/nE1jXjpB3W77pjicmareurYx
4z3jQX0tFxOJVavWa57d2sL4f8iLiEnKLy+bngrQDPX2HwoSvxO2x6XSc2/nA/deZn52kIwlc/9w
4NVyaC1uZuYsqLWH6YrAjaCZIdaqYV9DkPZyUoSe8CdDFklvKFslzxN2++995eR4yj0ES+/nMGbJ
FZhEkyI66Nvyz3sgkA1yDcDOSF0GRdLSOSTz3GxEqbfZdJz/EyzfUhUdMQgMcX8mqLUWk+RGhCns
70FsgmDY1L8aeKOGm9omgyVCSv/g8w7gsvFbdn4+Wv8W+bvZZx25HlUuRxp8GZpV8dLI1mU3zPSo
lvNAm9gHgrwy9tflAmkt9j7+dVJqn6/fnZagtax7GIPGGbhsektscIoACINUeb7GLeZrD5Flqo35
qaB20xCHaU5h7+P5wmkHqxJ7KW0dpG5PNeDTxlJ9yUd6LulmPjTdUJHDPhbCBG51p+sBsVEJMygt
Dvwfl2OXmp93QswSDDemyocu8iSWyamGoJ78hN5qaIEYcUEPAuEnHQFZBSJglb3b03jOH7wxKCc7
IsUxouPLtYvD0vlKS/2+Il5i70/wBBzEYY7H0Lih72V2WpK9KNQR9dBMSHi7RTsxv5F/2LpPVQnO
yugjQYbwLeGlJ68ce9zUAj++WSih6PUrP6PbETj7cQbD0+Gag5g15pmtU7J8v2Qk7DC4GrCpxewF
8GeXI+zwSlkvGG7YjohWYRFYIxDt2GFBC5oE4K7KMMwQ6P3Y53xz1tlpbgRr+uXGXQ8/dB9DepXz
ByKnM9O8BNPYxlBAZ8CjunKW6tzhNkAVnwd8AEo+KG6M9juE0MlsGPXDSvOXCSdfjrqw9r6+V91r
1DdUYsj6X0BGfrzHf+b08CaOWrrpCM3hvW+Y2fbFvkzXo/+q6LkpoAGBuoHDizZiYkgfzlKIZpVz
sWbvVPUYdJoT0/ATvVtecc3KdpS0i/IdYkVyZvXnns6WVpIgKPYNqqPKpuqPp+4BQV/57vOBzyDU
Vt94HuAUP49r2cOD65cxmSIsdi9XqtbOAYHo9si1bJnnxYAWr+yKfBiepiJM5kfMK/+r+sJPnxTH
r5ykfsZhX7wbKCsSFbSm5mvjERYEOORDkeAoDyRDmmWjg6TyiqL8X4mQ2gmmGaj0Hu3fwUpF8EH5
q5NTwVSrTefDGE1Wemt5UtAarY44Qsh3m8DpJW6L9yJGZ7i50FcUCHGm1dNRij8j6YuaSZ3ZJSVa
86l2I+iEl5lR5TW5Fw5cHkb+gGLJZ1DTFd9XArlbFr/IsJWRtXSp9SGf4Hmj+bxtErqnppgTrKfL
yCVtj2xgEDMACL9TrDCVNxgp5H1QzveMDVeY+GKw1Hqla/aMUpejdge846ge0mLHIjZL9ioZVkJ0
VsZFJxfzKiFE3L+Y9Dd2OkkQvffxS+L4kuQuVKvB0xb2gVXYqp+Wz7WYZ2flWHV1OQrR8gHh+HOl
0XFxsuBNOj2ssB8+THQRUvUioq2BbXuPg38dUcvBJ9hiaNanJkm9EtlB32Ji4ZvQ7OuvZ0Jqmj3i
CCEKry4YWjW8m1+IFyK/c1qwHAtowPr72TJgieHI4524hXh8j4Ac8Qml0bqCAHJ4wUOTGQnJwmlE
kVbp3cZHoq2bRX1ZGXZhSNGvodBRNLSG/U1b1TE58ZN1F0V1MLG+wuItayOOG37QXnIJekknCp1h
EE4hR4vVSA+cjlvDR5VUELX5XQ2Wk5Rs3K+o8YW5cp51YlArhzdzgmu3oD4RN6MUS7JvUW76zwYS
ij7R7vcywfUmMe1bD+nnED/87xHzAOPu+jAo5PKC20pEnVInJoMaRLaV4h7tFx+SJLg4UsY+mmj6
9zVhY+RQ5hi9lKYqu6z15/GAfEj+B+7ZzCp8V7mJXJVUTFhxGcD9hQHJTwSOMH32jw9c+9QFGkZU
0r8zcvdN+raHq7OjExo3JOPmRbBBKEllCFX+AojojIYwv3grDJIsUB/cYfYV21ahNk1GaVvvtBqw
w+tzfEBZB3R9WC1s1LGnaniPjT55Sq6Zl5/1/uniFeGtVXvo5lfSZOBPktNDWvixmqe1xGU6GG0r
DrrnqnQrNl6U4nI9qMzxM9oGybKkzdA96ccAsfSb/vD3p14urhWNWk+tJJqwZ/NINbg85gX0lCJf
/yAf1ljAaYyLI0DiNr/1YptmZUxxjeglJIzDMtBEEHNMIqDADBBJePqA5U8QZPLsE8I6mkVKRjg7
2tP5G+oPrKLNZL3LQlHBZGywTACh8OXbaIp0w4E0naQu8QSbCb3gvnki1d+DA2PZmeKbDTeaPfG7
Edgw0mOqNFB7enuXByaoF4zTFc8CFlu0zDuJNHl4NEOBEjbFS+wfiRB7Epvm3yKAqAN4FMlpZjqH
mT9hgJeo40sMhviPqj5WA0clK3o/pQw/Ym1Tl7kXNIgcbad4UDbvh6RpwzG/9fgzdm4x6jnEaMmD
B4KtZQCaE/3vTyEUq86JC97UhE1urE417747CAM0QXIHn1QlNMB05ab3SOEP84STn60WQAG6bCW2
XicvLBlU50u4QQ2Z1JGaLZiW7XHUsWqExrrx5Uv7tVU3lb/YXZR+VpmAcFFvAFzfjv11VgGVsFLZ
OkJsUPxAWDoT1kvYWxbV7+J97JKbn/weNohlJlzyTyRiQYQ9mHqJsinhGHKkWdfPYecWQWKuV/2A
OqFuGSKngDNcv0a50OMWIzDRkgQWMSM6xUPlGdKUlvtoOfK2UnUBmyWzly5N3Q6VnQi0NtqsY349
0v38QVGpdpWu6XnGY5cOQoX7z56w0RDlrdA864AEGfso4lhlcBRyM6ApwQKgHHTONGZMCCNqTLwy
ypgd5wDqpZ7eIS89GOKe9YwLeCbYuEVnU/b+DgEfpD/8YhagjQQnkSkohbsY1O8jBBNMcboqyxzk
ynKaRmjgZX6hx4FOnIo2DjO0FDwFiykg9yXPfWD2uENSAUW/CQXJ2A8Wv3g1tfJ6fOX22F8hItqC
u5a8muKB+HC8RGOB3UAtVuB6952K01BZ5QoCrg9GVpFKZU0vQi7aN1O6Se28f8gnSlsYMCbwJTD4
tlF6h1P3H51f1m1GKJ/rG/psoXTGq6/48TdzDqXqCg/T4V4bqqNNvmFtXHwNHjEUmZSatwdqu9Tc
urkRSkv4hkm+ypWrC714Zx01V1b1i2RjLpPME9bkcUPuwF7m0bv/4dlO/wbpY8LcXvSd1HI9kGR9
6xvR3WVkJxp9AvJHodcoFkT13eJFmOeVcbk9+tsW2SblkO/nNalD7mrgFoxQz1FKcVZcgetsCXL+
191ygZqXg7RRP05ncssRJ1tjwly+Wsa4JvUH3+MxAHLoX8UkC/EsSnOXM9cP5g2cn92d52AxrLUB
mUDad26vO/b1A47lQRs+ScqTQiOjEj5fPKgSTLtHFB3yHqgkLhFRBb0V6NDFyAvOAqwOrmumHE/Z
ynwgnC/PUBeIEN/3VakIGQZYQ9mONtHjM0elvCJeEYwFrS5j4peXAxKhfrD5beUYzH+ZEhDWi8J1
Pb9d1PDBlMyHWI0p8zItOM+lEZX20CdrVwMPJqTuDSO2U2bVoNqHu0b5N7R+u4jx5fI0QylLCUJQ
lLCoNbNHdBRqlOXFyEXR12p5dveHCEG+TgVO+Byel6Wx6bslPn8ICQ/NXysfanbr5KGYokJK5flA
RXn+4iUS2pqStk992nxQkj3cdtmDR7HUz8Q+t+9o/KJcMsqOFkImq4UzJmGaxp+7F5wT5miP3khn
pLrcdN3O2CmGmDRuzR0EJVzS9MwqYgzRqAHJ8Ucui0WU0NGTuWY2zVL4srnnkTLmPjMeWigEO1Qv
CDHSMSo9fkwTs97nOCTTPAURsW/Ug9TdA8LFzq83Lg1O7quFD2w4XBGffxbiUEAYcsBmkdIaxzha
EtLZmHWlz6rVtjj8EapVEbcQhj/ijFS3HNufZRMMpkIXbDE+Yg0BBaskv1KJeOUM5+5NiqlVA2uR
OJLKOcGw1WWmLEjKTScDKiRuUT6EVi51DrYMevIr62l4YwtGyP/QA/sOY/khySQpXA8HkOPf532s
ElEdLvtpgpeRKlj/evNuKWq8IYdjFqGUXOVPdy35ElrI8tmzXfsXt3nUY033O2OQfypjxekI8JNR
JolX3dMLlOmparMhd3Rbr4/2m2ZPrhZqjd9WOOey+OU56NEEKcXpGHSUEUu5bhnRSn+nuxIo0DiU
KhqGD+thoSx9t1fy0fDS0TkkGeAnh2fgkZCggogFHGR3vqvaEaD1DLG4xKeaOOIY3FPh0lrXv+Ml
/FgCA3qoA4tO0Zs3o20emqlql3d0qenhO1zotXyP5uVN3YtallX1i32ErLmz2BCMikmuSdEAOtlP
JdBjh7TODBXYxthbJbyhCQ/eOp1lv+9TjTgnRoCK7ZD9YaZ+vVPWv/Jlb1grbXHwqR5E71+kpg7+
ziD7adVvC88usNnkiZ87GvRQwqR+pLDUS2DTvhadOFQ8f1jK95rJlICdKf9BXiQjAWO1R3KA1lpK
/eu87sMpv2r/SptWjAY1Yhh7T6Nh1m/6c66iP2tlpIAi6DMmusKboZ/rwdL55e4jBNco62hrezqC
KKsDmmwZC3jnpLBFOLEh0oOBKeSSMv6VuIbZkR0hKyBlnc/Nmseaz9saNUQkCVzcVsHSofoldvHO
UQvWQou8M4vlJF+3MxTUXp6Bs9JsCdwP/mmgrvAPRciKgla9400Yzh21j1VCheZlOq/vxUfu8Prm
+4mjHzJpsqx97rft+ewkudapHb/gTTw+oi3tvXQiG4kfd4UflPcuB+5ExblIoYADOhMNYHtV4Yzd
QX/mt1s/2D6ME19Iv6OKwyjUSKnPssh/DiPDx0kbKspd+Y2wyZZ9W+R2Wn0wpfrViyusXUr6fNiY
G8reGO0psGyTM02hU6lbdt3y1mFS0Wyawf+uFoXTeuD41Hr6GQt0OpolzD9AFdQIMr8vHm8QrXkh
0rbcHi43yLnCG61UuHIbPyumtpviRtsY5D5FVUCqr8Hp8C9VED/sjccYleZamW2fSxvNJvwr71co
HJ3c66BIm2bk9dUcY1XeDjmLl0nfoF+AjpKhZ03UKUlIEqJkk1ydLS9H34ROly/5feViWmY5SEbW
FJAqtgrWFWMUW0wVd/vAAKgGZgME1kbQnnYxI79VjOW1waKbFaPpEKe0R2mNtAF9fVwnEAW/pwZ4
hXZ/jR0PlsVUW84FEzfD3Lu1MITOOlCQU/FaFTxaqdw79yhkfjJFs2AVqUD6ADWyFgtxuVc8OTp0
LZ59vgWNwlenL3qqcjCKZD4OJsng6DDFopyuImZ1nUANQ4DfsK5+cD6Qt9EcFmQ0p/Xz5opZt4d3
nJHGDVL5JF3PuIm7vdUTB7soeGUGnDY5pQhuh5psYsAxZc+SPehp+t3hOR0N5Rsf1hwGGe6Qx9mE
NcsDLpwZedf29bGb+xrVq2mG/mO1rsuGvG5eseXZX5TeewfUSKDwYFhj3BFX9b8/9seH7lgP9YKg
6JPO3+RdPPh8yxT/PYbiIviuWDjW9boQ9y4lkB6dmZc2D79m1MwdJ8FWZyOEkPLad3CtRv2ddUG7
NsH+AfXL7gdYxgiwUypYQ9IXRa3vwobP/TF2UhtlT7P9DgFX57CCu3I6NKIapSBnrkbWDs1V88Ru
LdVuShBIFrLSPPq8elSD2Mk0bWJvz9cACDQ2XKyhUStHMC3PLyg3di23YQfQ0m7KEQvr2IO/BMOJ
MKohOGJh3NWjDDhcL3pBzFCC/yacIKYa+yDxdyPrwTPzTogF0qB/1zJ9xTDDELYZheds4ck5NVBI
VkoIsQIUF10ah6JOSBVCUfdfOIgXTlz/gJBFDOEmOUQnjEKPBjyIKr5xGFvTnBbfv0OmlgH+sMSD
VszbLjlolJ2WDxgoqvDp2Wm0zaaQ6Mqg0pLDJMvg0mbeDxE/mk+knY3+MRqplPLWkOKo8/MPmEdQ
zQ8bq9xvccrYo9liaOIP0xYCRTdTVl866tAEXK++mdm3QzO+8SBxEJKSsoinVSEV4bhoDWVTY/e/
lqu/yVRLa8hYSmX6nnrg9JFj3KvrJZQCShjv5LNFhy8qS9Y5BigxkeEMDzeezfCodO313gPx+FQp
OPa89RxkfVq6H8eVlGUrP1SpqirUtE3TGCle1YQT4hRhf5ra8bMTRhgj1h+GkTx0UoFLZkMuB15h
e5Wz/KhT5qv0afq5S4nHg80Fjr10LzEGG8hssDG2efrbDz1SmkAI6HjYYC3cp+dDgu10K6/+Pcgn
MV/TwPefWE+qOmlGJA78LTtjBQhgDkcaE5BjylQgkR7jtMLryQEgn7azURLzMPMspf+ulT4sm1Bi
CG9MQMEMtex8TWCarLV36Cg2trT+7Urspro/CvDVdH9bnEvz8Bw4unExJ/zjefxL44jOhx+aOtUd
SjUVaJwlw8JVfFoEMF5ODUaiqBySmwXm+jr9Fwa1khCaeYxSxLpYEYwqzndfX5Q+Bex4bDx9q0YE
8v3n9viJXBEpdgjVCJDAs+fMRJ1PgJBrYBPYk+6ORbBP5BxVKSH+4ZK4OxpjAXE3q94IQVlG9b2N
5voq5NZslrhKwGcMfhK7SwhoWqgUZtJZQlhkLpJBHefhNyMyucSIkBRG0bwty+N5Til8inWr24w5
6iKAhsNGpRCW4+JJCmlKGeQtDr6k6pBumtbhSU6aLiKHiqBMtLHm5TcAdEh0n5l4U+SwoPWCFdd+
1ErmUnqN8uQ498w24itPGeCa8G/8nc/fC/LVTfOcsuOX9Cc8g31Sxp8Fk3TUQDelGLqr7e3E1/IS
eXn0ek8HUoSt6PKPFtjGB4v7+kMR638wShUAuv7Bb7ZYX05hoT+Ei+gTQHIp3ecy+phPghQe2j7W
CxqIED/oXiRIoRW6TQ6EdiLrghvva7NQKcvlEbijD0r2ohcuvWG7wsWVQX7lvIyQs0XR/E35y19l
V04MLdfbtr0E+BpyWa7SbByfUnUzYjGPCNFXtAqhUFr3T8vZayEeZogk6bDCJwWBASxyf7Q793vD
1mowECMKdwaANW2nk2de+7SaQkKW+X7IOlj1/jxWNgE3K0f2RaXXgUG7pZIkos5q4FbIrWu/TnR2
BKQcPNNPwIBMmAMNLqm3N8i5MEwIZ5Zmwjj8/1ntCQS330YNM87rb8bfApSWe3a0BC5buLZNPABk
HEE9Uw2yYn+FfRvBNEhFbQH/OYm0tquF9ZzS8Av5ycB/Zev+XQcCA0gT44RrPhUkZFbO1/YEYupw
7kx6UcJC7Uf+m4JXPfZPK08syWEfdCh7BO6Q/xim/dUxvlK1fqsf58JrGe+BqhjleE+LBGy0vOF6
Rj+n6+nSQWJXOsEfvm09f9Inoprb70/MHwCEQD5g2Sfotxg8Y05x+nJDYXiMIyqz0YZz5jh/KgrQ
//dnGJjarKZDtMmAHcOiCTVmobSToxGTwQUFChrEFjjXEUg1TK8c3nrZI4GHzmdHTDYS8BxeX1zw
8kRzA9w6HZMI+0WRjeAO9o1jeYshRXapF/TS1pLyfUL+idlCWSXERPT+P4hOy+mDzWSSlgChLeu2
pizxblCTtnLGdAm+xkL/I82nS+lv85MHQcCE2nH6wiBRAxDNXZbcEnekpM5rIkzTba4udPADbgoO
KlzM+a+kaIKCRjfpK7gtomYLDdzSIDIQ+yBdnkWjLC9PxVW2FAyRg1CrM4/hZM8zaCAe06VK7JvA
q8n3qyPKBwYRm9RS9kXvtiM921drdupHdrSwuFiUSgkxyaKAXXdUuHiJJbAA2nY2MwanRi6rkHmm
xoji1/lad+PaHCoz9gc0Q87uz1rVAZA+27RZQ6j3xHpCX0zaqPLrI0dPJ/8X7DEl0HZokKtAvIhp
b6KvyXMHS+zl0oajyu3Ll1CoAH7S6PE9PrycBraSa3PoCR/Gcw0sDj2Fnu9FfK2gugcqWzqzUlvG
2fl/M3d9Oa2/gnGtpaoq0LPaW4Rbspf9GXaOa3AdbCYZmcbPkZo5qu/JmXJN5K7p1wwN9wdasH1o
DiFC6TNKaguej/plEeyj0plSKPcl5R1xux9jmg4avZz8NX97tA6zpHgwRaXVUBKxabvkD7KwCEST
Y7wcr7Cxk2qvOE29dnCjG2C6op3pZhBLA3D2o7SvS3iv8hVF+PoIIK1PzfiCL4Q/ceiM1Tw2B0Ig
m9rNQ1F2An/xg9BzCTJMot4oFFVT0EE3zK7y1beAwjUhdzg05cEYUY4PE+GLay2PbxVjPOfv/jn6
jcV5Yn9eoyNaHuVPQp8iQ7YtiuwRG3oDf2HmW37LM5Ln7BfRW+VYawYuUlMNo3gI6tPcbIu8jtiZ
PMsShHHIEyYfLTcCbkDpJVbQk0mHDJs0Vb3jCGwUQMGsxOGEkI61WMWtOPJ/FFgZ3Gxk0RC0sX1e
lGBnLNYfQycLiq9mgKf7KHEPInAPsjcUQ3g/FcjcynVJk47fa9fj45XG3REr8FnH3UsD7WdrJV3Q
rdqUob3CXoL9lm1KxKNCfvDhHYII0dWnlZclo4gEEswxldI2K1dJsahNbabUhKYxz4kl+8+NiHta
v1L8SffFPxKP6i1dKO6MNof0LfgsPOicZei2CEfD1/T+euUA4piPrxdSTDXaUX7T526fCVj4/0A9
javONc74wPF/lwW3UP2FcCbWrQkG6hQtMHYzPaXht1biOxLtwV3rUtYus5+x4RP1B0tKDKxFvDT/
T3yc+dKGbzdfWvfcQ949q2Ehr0YyDMqkRc7W996Z3FH3APA6AnWmbOoIBUjGMChtd5Sy7/UaJ/nk
7M8eas6yrOcCo2+5EAdvCV6yrkUNmyvO0rBJurmd2usKN/CfKiQQEcuUxktQpayztdUjyPr4TqMC
wmAjoJwxc9760rQfBTdO7gaEaGnDoSA6WS8oxNfFocBBvTwElJS+boCpa29/hsq+LC+ELDHJQR4J
1TiAekz41QfHqj1JIj1AVGOUHkPSxaBt0yoelAEUphmoGgWaqkZvyjUqCk//BoT00MdqznyYMZUO
T31eGxsf2P+Jne9AWONYAjdtCMAS2chPYqY9xY5L23WPz7W5PDcwtnmdDayKfCC1q+vfS+f7HwmC
9CsnN4HaSSJAet45ttX6ULj7m1jBO4BKMlv00VDU2zHmL2lpUV8e6tvprVjdNGeBWTbLMqde9dMB
Tv2V+oDsGR8LNJ9rgi8Q3/xmT+pnuytavXJpdgzZSFukpVylmrgIb2RB/0M6T+d2yYajpGahTT9E
O6JdHR3S1o0xy71RqD0rhhgBacDlLuAp0hkZDNOwqyOhyHO8/1qS68kLYJ3sqBbma4Fv4Pn7kSgo
RHDLilzQAp2XB/Jk8yc2JP4RLOm+VzSCjKZWj3DJRWeiLsS0dv+2TDlqFnLleGc2N/yvMnu82Tev
ro2GUl7X9dKagWSAuO9tQLd5rWb+M+yHxYqnVNu4ZFDzUuThUfTaRZZukf0uw2CZsN/a/XQgGD1C
XcV0LBqDIFAVNqZxGPkv1vdt8ZS9Ys3zNxr9yr5Q5yNRfdIxkpmzIqAMgzFKhUrU1KG1gYD/513o
ihZCdUC7XflJOMl5Rn4MpIn1Vz2uoKNtn1DBcBkzy8rC7s/wCcTPjOVVxcuzqO0X9sKl8ofU4hYL
OKZ/FRjt6kEaqn0xUYkvw5Vzu3zganpiYOkAQ6UhaHliRbvKHol5+jDe17PYqUCLGL9YrjbG1Qx0
4Jqaj8zvVEfiSv4p5W/jBpc3fjE5XkU5/iUNqWjNk75H40XKAt6R0pcSOzPcRYrUUryjvH9BNREG
JzMoRPYbgYnk9mj+yMT2dIGHI8f3KJnt5rUVdu/SsBHsbg7poXOy4WJBef2UqlQCbR1DHq+CtayB
8r1tH3Er7+k9M2FFTDgn1cQiMBIzCFZHHGM+gTJmIZO3rYDpJ8OrHmGxI6SG864gDS1n+nkA5vz2
TANImEiiH2LJfXX4kzqa+qJX41nQU1gZRFFqpK6AMiA2PKCaHDU3PHDMr8rViakzzn4CQDm45wOF
ANiKtOaIc5mmrU3t4KExLKe5EhM+Sc+hKunj+vTDAj/NL+UfmRucvibXIVPhXlFa3CVhlgLtrWM0
GAjn0epBmRYvogxWuiHZMLnKE2x1od7k9FPdYdWuvFRJWg/AD9R6QyGmqyCy8oUpNaQs3iCzeCw9
BlXhV4K2JVhCdjzcPZ0wkpSqz1ZRvC9RMju5raI8OIZA3nSEEHD0bu7iiWiMq3x6NEPFZCAH1n/H
dN9RXAj4OESBNq8pb9uf5TzNB70OHpbJSmKw8T33RcTE+Maincc4Nwj4CTl6SHTIiIfA5vEsHBJj
ZdO6rpqahHnHlGvTkTa/ZonwBd/WwA+JxGyUJEOYcZ4RRC7NYbnD9Jkvi2s3eiYVfePV8JT093UY
Q7LJfYg2gYPiUaqtsJPo3PvplvOVn7R3+WAJEbFNaWDNIeKLUS4pPMhAibwafL5u44bB31oaM3tl
kVG9LNPL//sWx732O62rLwYKyNWmZOTBFhlRffdaWUiwE9TTBBoAig6xmiVwdZgU+6eD6NEVmBW8
uXlZ0sHwVAujCOKYSmyD+kx349J7pT99cdhzhLDW6rtyDlSogwTiQuDxRBZ3RqoD7Q6UJ4xRlXZE
vbwbN6CWLglCCkXBmnxh5ytnEoaR6QXmXHZ49HRYuLVQ24lGAxM9QrTctimnTLimt96hq/rjiVso
JKc3waUIDhNUFgQQ6w/B4X8+uRodvgKxr+QYc1Lmqk757tM0tlX6J8oKq3wh5nRcC2J4WblSqiSD
z7PwdM1uLI+MXwq7xlUfjJdOxll+k2jk7/51hrrA5bPWTdOeW1bGWD7Prk3ixL32pVSCZIYItNT4
xtAzl+W8YizpDMhpsfG91ijyqphW+Ua+bYWoxtU1u4KWWBPp9avutAIPIwVUB7rj/siXspl0UmVQ
MjcKK4VulHbiQ/o0t6om5IrHkSWNDP42Gix8roCG37VMj5rtMvf7xObq+9Er4Rpdc8HObVpnhuHw
juAEuCs8o9VqgJTgXcsN3zHMEJQTj8Rbj3LUZDm4bY0iuhPsq28o88+tl4AyXWqA8LOPUuJKJwUh
SsdauLTag6FTwpvUPgO4d45iY8q0PXXsFS76KebaMoVA3t4GFoL2FiLCzu0w5mlfirUMn+OIUaFC
VHWWgNcqE7YbMRuQdnkGtzhZIPZqBQ3r/J7WH6vS0pLjAQb9h8ZM21Chh0W9uerWzJDRRhTGA3uG
nGfVVPK/B5MUwGPBECCn9vr2d98sXWViok69tYzjR/RG2zw8KdVSuIiE7mYHU/NLmAzbrU78wuFM
R3+4FkJ3bGZZXfnGDI7XayO3iZVej5RADH6CneftsTrUrGV2cC7sO2NNQhPmTX6hwuaA8M1TSLuT
QTgdcr+aKwo5p616J98dvdm2k3EWgfV4fbQ1i8cy7E5Dxvd1XVBv+giuT8DvZHfhkbp+Jt6yvhLF
X6WRO4gmgPj8t0CBzduGEpaXnf+APeiksa5T8fJGftbr6YHkI3DiT4HUpmJ29WzraqEuONKNqBxE
3kr0IRqOcOQcBf5QbN9A9o2zs4zEQNUepuBPHFnzYHD8eUET74hUwpt0XNcpk10ThPqCpmNzxpRo
RPYefgtjHJgZukV8TMy9su1P4R7QEv1xV9DT/6Aobpyfg1RjbpW5qK3irUulo1UgtPUEA6ajzA0i
zniceIYkaVEm5/p5ol7tIVARvBzfGNm9iI7nUg+UefYBBvOAQov+U7CfjuR7lzoOnGD2Rx1XtBcg
WG50mFcs2ImL0qVNGwDH79b4wOL17iO52OPZU1bEmCHx1eqaua/or5t57R2yGnoPHFc/f6reOfrh
9OL32Ookd3/EnfWtKs43OaO/oxuRsWWJm16RB/60r1OCEbJTjD7DJB/BX6F2qXG/xBv9pepS8Cro
o3rzOuaTtg4O9DGKGOOFCUqeh+HFdD/sn67rY+6FR8DLQszhcCYDBFSWvGwgT1hbH12SXyPGLFcD
ngPK7Nq9SSWBkqqWiyWUIHI1GrYuG6d9d8jwlxZ9DFy0+MoFwyAes0+BU6caaMiqSOX3oLPk/zGX
UKDQI+SLuMYcFC5MoyNbvbS5USS5f+yqImIh4+Mfxt2LCpkUR975z6AyPowpUncn+2KAqat2/bQm
OIRz90tscj2tjB+31KY2ZVGOajXy5DgBfxNb3QjgHXL6rAn8Zr12FoQfS0VJn5016Hya17ZN1bwx
TWh2NGhrsX6qUyQ54DrdAoAGAEImNYa4booyuHIqiTWfL6GeSZNv03VI8XGw4/x8p4B+n3tFulL3
mn7qEWVjnYQY/OSF1ohN6bf9fd/0Yx7hHqeSm2yq0cVy8w5eRupfkmpWYMqrQTG8UbsIR8mSfjr8
06URv46JI4kjr43i6VFAImonN5zgdFjVLgNRzcDrA+ENx3uZKx17zXp6Txjg/NWhp/1CZ7UA8vRe
kA/wOaUpOU7h9p+ptYoT4jirYlFJMF+TpnBOKEj01jJiFaSGJeTNWwMCFpETdYWNSzKzv8dLA4aK
KAz6JDOihP6v+fGfPKuytah05yf2Rq/rB53XYCzHa1J+Pyy4B4Qe7GtMIY16COkE+RhMi7BNJ6rI
sBjWasgDfFacFGBypKzf+Ci8cyfeIZSceh6b5PV2tuBQRnB9xWpwXkfCVsNW5iQHyutc6cdOGzaf
qjTF2YLoJrUme8pheEWuFYeQlXEApSF/eWSVs/vPLIkJAXczPhbqQ7ZOoJsAPBmfJaOYKN1X58wA
QKXhNtShKh/32HGqgoqYDZGFLerdRVi5hsaOAVHmMS8uJvDTUQdSlKsBtZMPF7367l0eYb0ZuEXT
gpkYrQ8GUFtr3Pvni2ALpY31NV8M9f5/zWbTJdT2YBdhrg9iH3IcMRyHBY0gdJWsBc9lnoXJmQ6v
RX9bqEylU/yZwSs5CfFLfSozub7zEiuFwCmxMRfL+JFy8vux4qaKXLGhzt+TdoqY4rfJIKr+bMrZ
y41eh/V3xsjb2AylzvKuGE99TTCEPWBp11z2FQ+A4Dtd+EvLdFVV9tvQ8eMvIJ5vIY7XRtmLtBJD
EB8DHucqXtTSXtWHTwDMqvXQV9YU2JIjKnoF+Ddkl0POLFaJzGgvohREND+i6lZHJGpebVvuGPQg
Vq4tCt83/hgA4JW3z/TGqYnipdj/OmVE2KRs9sH+yKCNqHji2O0Nv56czs6Hue6t2OORuUOrHtdI
/G1zK47irfQXJI59HgS6wvbOPF1BPjHoq2hPW9FwPBx+i2SuWGPGhKzPBbDTuv2u5zXMu9rWdgeW
ajG+hnjyY67Wpy88rH7IGaql4gWur0hrTXPgTajktfrzLnmjoNFS9zByBwuSFNeAHUYRkjLT3Cxl
O09GucYSQ2/Pr3qHmqt4OeifH1rejRr1vAeXgFCblFHKssCq/Ih/VFRMKDJvvRVi2WwZ3ysUe1CR
86KuZKI9Z+QL7dt7y0Zi62vtLWknMaSsiWZ+OmXxmFAdi2fC5/tbvdg8kruZiJSqXPG2JfBk+ebm
IdJL6EYYPRnA6qogGYMF0ItCVpya3Onn85Z3q6Ggoi24E9QVVR5KmC3KzeWYxvkVmZKgr1okxJYk
SZWi83boeoVWmqankVYrw6BWUb+wb4alGH5CUIRCoJAdlOKuggVLu8xeW/g7vF8ocMVK1BcOBFoc
r5e2b//2M4CZHcKz+QBSeAGcpNbrRzakdyB4xVJtYrVBR5omHooOX2bVF5hQD35wKfCmCQxdz9Jg
OS0K543irrAF6bEw7epgsSd4DwoPtv9QrrCE591IqHynFrF2W33vC/Ip2kisopCyDZZw40KDE6EU
P6ufoUYg6xLh43OrotGlPorPcp6Qo1uFeujsN/Y8IoWz9jnk2CfpBgG3uU97n3dG0ljWEQA2jDHz
HO0WwKpotnOzJEwxaga2BfkBDyMHJvKKIvDSWJXVDdCrfdPqYh00bL1liAiNVID0udUBT+OFFAvN
zU35tP7IrZk9cxFiePlItnur96Wpg8VOAjAKjJror07IZ3usYCWIrC73dYJp56ZdCJR4C5CG3s5l
ZSm3tfQaSJvOfKm02aI5eU+b+obuVoSy7lwhDRPwMpGYq2gSCp57kMqujOWeXnacWMY/YKePUrx8
TPij/LLEgGSqORw6ZDWQ8T+yQZeeuWQ1B0Q2Q21O0dmr2iEk+2fN9QUGWZ31oyZXEGKGtX3+1mAG
HyVyu6yHLMd2DT0fJVz+iYxUnluxzyVkKEWTEw9k09jams4aESwaDavQ1WmlZ6LCeNJ0ckhhKwca
D6+icd7ebKAaAet08lQMgXuoszov0OlzmD//GdBGGnFePma8jo5yuI3zdak3JRPLQjjh7fujPOBK
V4n1QVDOuQxOWqoM5CULudDDC6BRIm6eTpTqFo04kt3fgGw1O55gtFEHbEvabpI3NkiwlVT+h2ZR
MmYcK2UQh78E5yhZjw2hldIonjtnqc8IvtffNFGk6G5DDtWkt89R1qOEQuY/NHjqGFIWGpz9wdwR
AwTVHvFlfNcZJNU8t4g2VSuwC8JTpwtIASRfxysghXFfWMHhl493D3rCZ6RyB+gAZVO6d+2ClL0E
62ts6YoqkiafKnwb73nLFe4up1nL30tUhhtDNLJN2cTiRSGQVjuTgOoRuZ6icF+KDdeO/zv2VRF8
lvegP0frN1N24EMDLZUj7wcBxaPqufKnYa8FBs9Vpj5OwEojJGqyDxW3/hZienOy+gh4L84efMgE
nIh9e2Aw+jceEcdctt5JZxq5ZHDggBXpxe6ni+vmYFEub7+YHgphPBZtG+7DLKkNR5bUeQPiKQ3m
4tr/8WaVc5o+Iomc8WgjYVyvAgR00Hg9R0w8C1iVlTHLzln6QuSrfbXVwC2m8AFtWCHHMA1ksxUd
pDnN+LLxa+vkss0roWvd0YrlLewiB1fWOP+IF2hUbnTRpxh6YCJIUl5Gb9slZQ5ew0FA8WQ26D6P
BYyMrg2402GqUMYYi7XD/tIgBXd9o87D8gyi8WWBZ7Yk5AGEKA/qzzIPbNqdPXTFxIL9/B+SeETo
dLETbC5rAIsyIyQkW3PU0VEhh8ALp3yHtBwpid54BTx1lOAq0miiTLNKOGXIWAaL/m/VCw2a8MwH
eZA3bmitMeXPguIuqTihdt7jXFvrEdH0O7uoF/y2AEeFeWj2KlPwLR1QrWm06A/iWAdEY/rQzK7C
tHUwCiwAvknqp87KdvY95KHF4wTBeNEGbxId8iZ8grIfoerXKYERlKY/qcnzxH9aiid1dAYiZovf
H+NW0SnllOlzcYDKlAvGYpu6vh4OYAVD8EVIbgVEM2RuQUf2eUARmouMBZCfzhsUzPRZt4yygckV
mx3aSrsZzHfHCA7QdndbVJP2MB2srKAwSqn6/zjfc1KWm/CqKX3971KZC/NbaHXzVZXd5iQl4tCZ
LVTdB/r3s111tcyonVeQM7Oa6iqIO+NjF89RNizy4phYd+GfJvSOc8lDEfjpSXSsC9rTyZYrztyp
7ac14qiC+/8A2JJJbos4i9llySW+m35jpiji+vCwkL14438oRfrr60tnh+Il4s1esGoxZh9LCI/B
+zVFiwMIVSmyzjVsIM1Xr3nolOiOvjsbxfWffAyB4ike8T1TcgfflkJQ10GkBsLiI7zwUw4cinKw
siXo4FD5FoSISqKJYwIXEIN4TO/inzwyMGULE9DSZ/3fnCP4r80Gt+UurU9CBjc+nIJHJUGUQvWE
xsj0tgVMw4hkdfCnxb8Iu33jeCSNk4GC4uA9NhR+wpPm8llrXr/kXjO1OxxG+CFZJMdNunr0W2JO
9x3v2BvVYyzvnP68mU9iySoiZE8oFrj/ZId5XxKT7Qx/4XggFAhZavxHm8g3XwS4CRtOZuXf4QNh
y9XzJ82kd8Ki/uH9Sn1h+W2LMp8fqk0SqCef2aif+ZCCoarRjJX76BgwKPAQwxIaEV18fZ6FSeD6
0AVuBbo6kZOj7BoCaLg6k5oeT5G8fTaDCNKkquYXHoZCBesHHYHqyMGwXhMq5NJqOaiSc71Iadcf
L1iWdCpokBy6pe83OGo53jww6eWmsGFMQnymCIdvvt3oGQVUZd/htflpbFAWx47LqMARjyOPZ53V
fmGyQDcbIjESTP3wOr83jlIwyipl9/ITnMllfxyVjuhyq906ZtLEdIOtGWN2G/4vqevHPT2lHmXg
Ls4ZxowNTWxhlfv6ZWdABYjEyvoiDssOS65ojqYu6cdCBsWYP7UXXhVQQOwp4We8tJW1xmIwIEUk
wiKeDcB35eyOcZKCtbYukbDrHxZ2/NNfRMTvdhkql0JvNO7IbvI6+oBEcQzniRUqPV65YUenslc5
KVLMEkBOpeuhDbJ5wSbSr1nikrdQDt15cZQymw6+YumU1Cqj9fSv8evQ4JUUT09j0Bhm/8+hSg42
NpRaaJDgp4TuS3TiPTymGU87Q639wHul4nLLIogoEXtAGfr9Qz4MdFZHyyBzNgHEb8FfqNuhfisV
hp4nH9SQbmDPcT+oHruPW5YdEM9txwtX66Ag4rlvTGtgQ25wD5YvDT/uZA4a0zJ+hELQ9zwIKHwU
sXvkx+psz1UftGRq5MPGbZ5t+gdWnGVomZpBr2qlnFofHMijnG8JOmGqDCvcnyr3VhPfH7MDeLMd
M2/rIbnX4zLe5XwM8jcUkx43PDNowbQbdc4K/H98uO2CD9fDCdSqUntlLgbpKkxOgmiaSL0GdOBc
BEe5/X1D7DpyUP8Uc6SBdNcG/cA2yQ+6QoaG917LufidfregV6t1lEav0bXh+dsreqJ5kQ3tcSF/
KWrk6DDOPE47zJSpZwkEjSlux6PJrMMBAjVFqCWRQWSooyUCYcQcObliWJ6KYyecGYr2Chy4u2t2
lFf3rOzOZQwp5SVJamH3RGVZ+8o45lA9MDG/c72QWJDgUUOdj89Wkt0aGQMweh5gDjrqgfwvJeSP
VeOR5UOizFghBgfP9l/qLX7HNVhL1lWy1a7Mh4QczNFs1NYnSCCm/qN9ARQkPydhjgnHcBfr8Tk2
uJuhT3wTeL0WeQoOENzUAZ6Pb5ZnFyU+48tKItsaGdnPC6uu9/czN31lbG9xMX0IXtJBEKou0lZj
HRw3xU9CSc7z4C6PG8fVfuc3iFNBCJr1b+mNQ/F1L9VbSQe8c/0PQN4N7GGL19pAqC+C91mDoEh5
8bSkUYHl0W8z6oeak6dMQxMxYHkOA8yL7hV8TPZakpRhM+PBPpQ4DXy/SQptfNp+mjRRTOV39Gcv
Fo8Ub4j38pApBD22QR/j6EGYAqDbS1S4DxV3PBc2vXeFzP065CiSjXQajJWQHhH2YgUfVShzFL3u
3Faq5SN3ZvRN62UdyD+0LndgAgVy/NdTvtq0V2bohmPTkkMyOAeBq36lbZnIcm4oc+pYx40VVtw2
1ikgt/HimRYWYq1ymysSKtcH6rCPZBo30WMCDf/dqUHegVAP4HAg1f1i3KzJLqwRZK9cYLid2Up0
TpjQiWFbli1zCmB7hIxCnAYTbNpFdfgBC8PxocNNPW+wvvqltsGANeReRK3PzTXy1Hk5cqekXBjd
Wk90djyD7ifixQMTveJvHkB/DZMygPy3vevK+tnomyGuhI3+V98O+M2Gw4IdloNeLkqakwJHYBgq
N6s7dCh2F8LqMBpeOd0wxDe+0dSmTSl0kfjPP3gA6U5B0xkEsx+cGwotmPXbvDAnDozlGIU1MwJG
lfZMYpnMMSdveiN8qR6haEb3NHFuK8mjaBAgQhXtN/p6ITLaxUfcgK1a0NdZLeYN8prmn9e/34U+
mub9wd7hcG44bFksDwFGq7+7pMOKkDLedKoRFX99F+IuJ3jyc3+85folOlgwdO8Iy7SA9dIshcBe
qq5lsJPF4CHVEF+FaJcJ5ffVQvcHnpZNB8ph2fgRKrf5fN+W1543MMeu5W9vVOaMkHmOz1Y+tLFb
LGlqYX/HQidyO+kESOMq76GBPyfcoQUI9OS9k4OVby8Mvn7Jmzvm6AvdPMbJbB5zqnvVxLBSZKr6
bdUgZqVX3jnr1pyWf024pyucwq3ZiSQKIpx0f8BVCTz3cOsfW9ohiH1p6zB0wPrJQf1wO/ige6Qt
pfWp84vRWISkAI4XMKJ93QhIX8WH1+alXGPcHzKOAf9+cIwfquur4cZXVr0N6F1FPj2M8r+xDCrL
a8kQ3NZpDOjZk5VBoM/pSiYwtvjv8PYkH6GjTvzpe7EQkRLiZlXkZgAkmsCBp60y7i9a+39YNS39
1fIQnZ+KwL+f9ChcnSUFvpn0wuKwHtJ6PM/DRREFvaqx6kcfO0zCBor9dMmdgi6wwzbvR1QMko14
RWhG4guj/aBisPKlNtaIRDI59kk3m6Bv9tzNnI5Edfr0eytA2NvcswDySf411AtJmcFdHj7FkGyC
5TE065O2Rk7wA4fyFUK69rH4JKwWI0Vj6OAq5i1Bti9Ahu8N6zvxIluuqQJLg5pXAsvwp2IwKyll
mroE1Q1lnjQ/Mb/JDVegX5yfb95Ns62rL85jHzB6Dy7cA8Gq1+qGau19ayICbC8i7XM9IHYA8Y0g
sZEtuQ9cUps6iKnNtEDHmi6lrxo9Iof7iwhIseT5g8Ebb9HRbO/kK0vKTu10pDXbgoOp2VW2e0qH
l8XKknkFPupoBigLTkXkNUyJMAxx828FO0IKmZB7SFjDSP7KTbrpLAHCVfZf88DArV5EnkVDRz0R
IN7U8sn7rJS58fBFJmGjKXFjv0TwqvresVSXDeuesE3lIcTsnZjMKZHTcDoB65Dpa7GeW6ZVj5tF
GWQUeFvEyEWrEVfKEbAQI7H3+h8Ht2FaYWHqJOxmkJTyT8UnaPiSv4ONfyleWg/V24il2aIc3jO0
Ru45xzJ9iCa8YvFrus4cvEcqjl4dl+948JZOb/JQ7xIEuIXpR+YFozb1MFdq3IvYClXLEMkEvRID
MazslT3+emOB8rE7G0AB4eIRfWIaiVHEChgS6moVjSAVhE5liDNhmodl0OdP9zCkFWxzlyGWt/9T
cm5/pT48liB4gcE7yKMbiWXz2hO/erMewcG/YxCobpegqc7cDIPOzrNILxa0AtamgE8xyW1oI/ad
fjchDtVBksp5rz6Wk9q9Q4uziAQLxYK2UVTwwyqHCf0EXPhYWOm3EqtZ2Lbi7Hk9L7By9jx2LVnu
1EpbMyrpvHi0JpfRSbVG8s+Fy3Hk0qtmURI8qR9bv0NzXgJgbw8+MfjKVUiLcREHZyW8L0Isys8t
Q8QSOooGL5t2DaOO62FL3dLyTO4qJ3FI4oyYRKo5yixQz+mol6UnxGw5+/XCsMoNgHzo/XHXkFWc
bIQ/SvNO8MWAbl6bbqYBz8TYG6MGjA3dAYEfXa+cO//1TwPydkNZGKQDjMtqQb70JTlU+g4ijRQj
oX8z4c0iUb26AwARlgWt6zEljV5Oyq0UURVzsB3J88JAvRvUtApCkqdJL8RPvKnrmr8r/qvwFZHg
XFC3M6t/gPFEFo8mtv5HZvSg0iVazMJVelagr8J8cJwBVJKdNv1FfID69DUhLZovGXw/7oWYsB+I
Xgv3AUEwH9YG29OIVTppaEIUrEVY5pzL06RqjouBQejq8YezpnjOJDcKokVpeCclp/pmRWVJw2Q7
0x6cThGIA0a35BjaJDneHt/+WT+b879BPvjsF8rQVtUR37elZ0Bz6kcYPVAZvxGJ1WRIMkmPWR68
jrJdvdJ3jFCgO2jwoyXqAm9zDhLynU+kGEa4h/wlF7ukcvKTN9awu5Z+EW5cwfttMa8n1ACX/w5X
/dm0VyMjncno6pa2xLgWDFYQd4frBhVjGEesdhMM908G6AnLV8PE0ZuliMavas5uS6O4qOZpOFoX
cgNVlHi6wjvwzmsx/vOLkWvsDX2gdn1Zvi2EjnFYyJDGtg1YyLiLpjHezfU0flKKYVsPqD+CYlbm
sYIDcOsWxqKNX/6m4a8ly8CXF0NTsz9IZVQ3FXlLTlu636wEyDvhlbtSlgECTcz1py+tVDCHyFa4
8KPJ3X0nnzrQj5lAYDC6ogu/F6KJsrnQDSeFyk9ppUszUKhQO7A5pnr7E8WnvgM43JcsxzciOo6o
m+LuWbFaDAMED0BJXCdo3smakKttTeS+gP7bmnNVm9mTaM6G0Z7gsMl8h6L+/WLUlKQLOjyLE1TD
GipsZde19gnCJvhGwWySWqBUimpB2z0/FVQHfY2hIxD2NWkCCq61kKKi7cLX08rn/XYuJ0soH4I+
NewzN67gABfiTq2ICVrV8CAf2/qiU7M/xrHb0ZdqLhhSUCyA/vtmW2nqzbT6RLRuSSgFc2AqNPvF
XGvabcdd17kuVn4gGJbgdiHqUPv72oz3LaQgxu5rxKnjH2tdV+PjwofkbqaubYLpDXwFECPBESpG
+a9Fm8LX1zBV7elI/8r1f6b3W5Kj6Tji9CywCIICBeltk3LlcUHqcY8GIjXSAotvTuHFY1J0Gk+I
f8dOKhKr73GfTvOEveTFXfFqQoAi2H94Nl32Qg1MLVc3rZvHHOCB53j8XVR1j9Z9aAvVe+CCVdli
nm7wgThcB4SraTZ9lhRMkkK/9ngHJxF3qL/IN5TVDvHljnzNQVnB2ATEqm0ra6RP2LavK3IoPycz
6SAHybk5RKdV81hu711/hQTYLH57d3Yg9zl9djndKDKBT5/v8QsCbHdvSCfselHmPf7cMmlEOFWQ
XmuVl21ESmtuaZQaam4Lh55jjOt6cajprfcgl4yr7ArB3VGXmPblvBJZ3X9vbu7O8q5KzJOxAw8J
ePolvW2OK1wUT7b5+UuTwRFcJqcxjuGGWZCdEoIVrU6NHDPSxHiLT3Qj2muPgDZBW0zC9Jr2kw3H
USB3CLTn8vnkPSLEUMPRLnCBs8cj6i/2sVyV1BTIXcUeZln8AFatNDNFOpO1KaW4t9HFvq8HFVQB
/K5V9WJcSkH6kQuubyQIZTFuDb11SUP2NlbGBUElScMSm6ADC6b4+VM6kuFjLgAjgCekqL3+U0nA
CmhtO8bcUY3s3BhKrxY36qv0d6bm/H5ScDx1TVQtC70I5seG5GEwLTVs5dqorBWxz9o0QsPIE4X8
cDpVtdtQJ+g6VXHB+C8nEILrixlCoSB/8y/ytQc15/wz4UHn7r5x1U3kgKVL90uhbql5YCROUX36
+XBXKkRTcKr+S8Tczrprz6ZMaxpUAy2VP1RXmaSxuEKODbp8079MrMwLLhoNuK8PtabefhzTM0h7
LzIoZtyJgsxmU81pBKbrZOpnebxy4kgWUzwmTjyYz/aTyP2j4sGdpAsFnE4UcpSjiTrFc4SECqW2
hG5NBOcl1dUhCdpZqasitYuZ4y4YgTDBBLHR0smxx34X7zS40yJHf0Ke4A7Sh85y0NqPz2WHSsIW
kl18BLJX+Ji2/nXv5w==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
