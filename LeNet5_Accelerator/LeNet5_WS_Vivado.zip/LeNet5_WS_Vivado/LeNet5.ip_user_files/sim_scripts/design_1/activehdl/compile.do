transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib activehdl/xilinx_vip
vlib activehdl/xpm
vlib activehdl/axi_infrastructure_v1_1_0
vlib activehdl/axi_vip_v1_1_17
vlib activehdl/zynq_ultra_ps_e_vip_v1_0_17
vlib activehdl/xil_defaultlib
vlib activehdl/blk_mem_gen_v8_4_8
vlib activehdl/axi_bram_ctrl_v4_1_10
vlib activehdl/generic_baseblocks_v2_1_2
vlib activehdl/axi_register_slice_v2_1_31
vlib activehdl/fifo_generator_v13_2_10
vlib activehdl/axi_data_fifo_v2_1_30
vlib activehdl/axi_crossbar_v2_1_32
vlib activehdl/lib_cdc_v1_0_3
vlib activehdl/proc_sys_reset_v5_0_15
vlib activehdl/axi_protocol_converter_v2_1_31
vlib activehdl/axi_clock_converter_v2_1_30
vlib activehdl/axi_dwidth_converter_v2_1_31

vmap xilinx_vip activehdl/xilinx_vip
vmap xpm activehdl/xpm
vmap axi_infrastructure_v1_1_0 activehdl/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_17 activehdl/axi_vip_v1_1_17
vmap zynq_ultra_ps_e_vip_v1_0_17 activehdl/zynq_ultra_ps_e_vip_v1_0_17
vmap xil_defaultlib activehdl/xil_defaultlib
vmap blk_mem_gen_v8_4_8 activehdl/blk_mem_gen_v8_4_8
vmap axi_bram_ctrl_v4_1_10 activehdl/axi_bram_ctrl_v4_1_10
vmap generic_baseblocks_v2_1_2 activehdl/generic_baseblocks_v2_1_2
vmap axi_register_slice_v2_1_31 activehdl/axi_register_slice_v2_1_31
vmap fifo_generator_v13_2_10 activehdl/fifo_generator_v13_2_10
vmap axi_data_fifo_v2_1_30 activehdl/axi_data_fifo_v2_1_30
vmap axi_crossbar_v2_1_32 activehdl/axi_crossbar_v2_1_32
vmap lib_cdc_v1_0_3 activehdl/lib_cdc_v1_0_3
vmap proc_sys_reset_v5_0_15 activehdl/proc_sys_reset_v5_0_15
vmap axi_protocol_converter_v2_1_31 activehdl/axi_protocol_converter_v2_1_31
vmap axi_clock_converter_v2_1_30 activehdl/axi_clock_converter_v2_1_30
vmap axi_dwidth_converter_v2_1_31 activehdl/axi_dwidth_converter_v2_1_31

vlog -work xilinx_vip  -sv2k12 "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm  -sv2k12 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -  \
"/tools/Xilinx/Vivado/2024.1/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_17  -sv2k12 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/4d04/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work zynq_ultra_ps_e_vip_v1_0_17  -sv2k12 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl/zynq_ultra_ps_e_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../bd/design_1/ip/design_1_zynq_ultra_ps_e_0_1/sim/design_1_zynq_ultra_ps_e_0_1_vip_wrapper.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_am_addmul_5ns_12ns_14ns_27_4_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_detect.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_for_a_Dense_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_for_a_Dense_2.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_for_b_Dense_0.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_for_bp2D_0_loop_for_ap2D_0.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_loop_for_fc_1_loop_for_fb_1_loop_for_fa_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_7_1_VITIS_LOOP_9_2_VITIS_LOOP_10_3.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_14_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_29_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_30_1_VITIS_LOOP_32_2_VITIS_LOOP_33_3.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_51_1_VITIS_LOOP_52_2_VITIS_LOOP_53_3.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_55_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_59_2.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_CNN_Pipeline_VITIS_LOOP_64_3.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_control_r_s_axi.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_control_s_axi.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_conv2d_1_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_conv2d_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_dense_1_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_dense_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_exp_33_17_s.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_exp_33_17_s_exp_x_msb_1_table_ROM_AUTO_1R.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_exp_33_17_s_f_x_msb_2_table_ROM_AUTO_1R.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_exp_33_17_s_f_x_msb_3_table_ROM_AUTO_1R.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_flow_control_loop_pipe_sequential_init.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_gmem0_m_axi.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_gmem1_m_axi.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_max_pooling2d_1_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_max_pooling2d_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_9ns_11ns_19_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_9ns_12ns_20_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_12ns_14ns_25_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_32s_31ns_48_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_32s_32s_48_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_50ns_47ns_97_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_mul_50ns_50ns_100_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_out_Dense_1_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_out_Dense_2_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_out_Dense_RAM_AUTO_1R1W.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_sdiv_49ns_32s_32_53_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_sparsemux_11_3_32_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_sparsemux_15_3_32_1_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_urem_9ns_4ns_3_13_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_urem_9ns_4ns_3_13_seq_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN_urem_12ns_4ns_3_16_1.v" \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/72cf/hdl/verilog/CNN.v" \
"../../../bd/design_1/ip/design_1_CNN_0_1/sim/design_1_CNN_0_1.v" \

vlog -work blk_mem_gen_v8_4_8  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/09bd/simulation/blk_mem_gen_v8_4.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../bd/design_1/ip/design_1_blk_mem_gen_0_1/sim/design_1_blk_mem_gen_0_1.v" \
"../../../bd/design_1/ip/design_1_blk_mem_gen_1_1/sim/design_1_blk_mem_gen_1_1.v" \

vcom -work axi_bram_ctrl_v4_1_10 -  \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/14fa/hdl/axi_bram_ctrl_v4_1_rfs.vhd" \

vcom -work xil_defaultlib -  \
"../../../bd/design_1/ip/design_1_axi_bram_ctrl_0_0/sim/design_1_axi_bram_ctrl_0_0.vhd" \
"../../../bd/design_1/ip/design_1_axi_bram_ctrl_1_0/sim/design_1_axi_bram_ctrl_1_0.vhd" \

vlog -work generic_baseblocks_v2_1_2  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/0c28/hdl/generic_baseblocks_v2_1_vl_rfs.v" \

vlog -work axi_register_slice_v2_1_31  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/92b2/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work fifo_generator_v13_2_10  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/1443/simulation/fifo_generator_vlog_beh.v" \

vcom -work fifo_generator_v13_2_10 -  \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/1443/hdl/fifo_generator_v13_2_rfs.vhd" \

vlog -work fifo_generator_v13_2_10  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/1443/hdl/fifo_generator_v13_2_rfs.v" \

vlog -work axi_data_fifo_v2_1_30  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/9692/hdl/axi_data_fifo_v2_1_vl_rfs.v" \

vlog -work axi_crossbar_v2_1_32  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/e9d8/hdl/axi_crossbar_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../bd/design_1/ip/design_1_xbar_0/sim/design_1_xbar_0.v" \

vcom -work lib_cdc_v1_0_3 -  \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/2a4f/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_15 -  \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/3a26/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -  \
"../../../bd/design_1/ip/design_1_rst_ps8_0_99M_0/sim/design_1_rst_ps8_0_99M_0.vhd" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../bd/design_1/sim/design_1.v" \

vlog -work axi_protocol_converter_v2_1_31  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/3c06/hdl/axi_protocol_converter_v2_1_vl_rfs.v" \

vlog -work axi_clock_converter_v2_1_30  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/80bf/hdl/axi_clock_converter_v2_1_vl_rfs.v" \

vlog -work axi_dwidth_converter_v2_1_31  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/14b9/hdl/axi_dwidth_converter_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/ec67/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ipshared/a317/hdl" "+incdir+../../../../LeNet5.gen/sources_1/bd/design_1/ip/design_1_CNN_0_1/drivers/CNN_v1_0/src" "+incdir+/tools/Xilinx/Vivado/2024.1/data/xilinx_vip/include" -l xilinx_vip -l xpm -l axi_infrastructure_v1_1_0 -l axi_vip_v1_1_17 -l zynq_ultra_ps_e_vip_v1_0_17 -l xil_defaultlib -l blk_mem_gen_v8_4_8 -l axi_bram_ctrl_v4_1_10 -l generic_baseblocks_v2_1_2 -l axi_register_slice_v2_1_31 -l fifo_generator_v13_2_10 -l axi_data_fifo_v2_1_30 -l axi_crossbar_v2_1_32 -l lib_cdc_v1_0_3 -l proc_sys_reset_v5_0_15 -l axi_protocol_converter_v2_1_31 -l axi_clock_converter_v2_1_30 -l axi_dwidth_converter_v2_1_31 \
"../../../bd/design_1/ip/design_1_auto_us_0/sim/design_1_auto_us_0.v" \
"../../../bd/design_1/ip/design_1_auto_us_1/sim/design_1_auto_us_1.v" \
"../../../bd/design_1/ip/design_1_auto_ds_0/sim/design_1_auto_ds_0.v" \
"../../../bd/design_1/ip/design_1_auto_pc_0/sim/design_1_auto_pc_0.v" \
"../../../bd/design_1/ip/design_1_auto_ds_1/sim/design_1_auto_ds_1.v" \
"../../../bd/design_1/ip/design_1_auto_pc_1/sim/design_1_auto_pc_1.v" \
"../../../bd/design_1/ip/design_1_auto_ds_2/sim/design_1_auto_ds_2.v" \
"../../../bd/design_1/ip/design_1_auto_ds_3/sim/design_1_auto_ds_3.v" \

vlog -work xil_defaultlib \
"glbl.v"

